#!/bin/bash

# Build, tag, push, and deploy the CX Migration Engine service to Cloud Run.
# Usage: ./build-and-deploy.sh <version>
# Example: ./build-and-deploy.sh v1

set -euo pipefail

# Core configuration (override by exporting env vars before running the script)
PROJECT_ID="${PROJECT_ID:-tgs-int-genai-vertextai-dev-01}"
REGION="${REGION:-us-central1}"
REGISTRY="${REGISTRY:-us-central1-docker.pkg.dev}"
ARTIFACT_REPO="${ARTIFACT_REPO:-gcp-genai-in-repo}"
SERVICE_NAME="${SERVICE_NAME:-cx-migration-engine-dev}"
CLOUD_RUN_SERVICE="${CLOUD_RUN_SERVICE:-cx-migration-engine-dev}"
SERVICE_ACCOUNT="${SERVICE_ACCOUNT:-lee-ackerman@tgs-int-genai-vertextai-dev-01.iam.gserviceaccount.com}"
ENV_FILE="${ENV_FILE:-.env.cloud-run.yaml}"

# Build-time variables consumed by Dockerfile / React build
REACT_APP_FIREBASE_API_KEY="${REACT_APP_FIREBASE_API_KEY:-reat_app_api_key}"
REACT_APP_FIREBASE_AUTH_DOMAIN="${REACT_APP_FIREBASE_AUTH_DOMAIN:-tgs-int-genai-vertextai-dev-01.firebaseapp.com}"
REACT_APP_FIREBASE_PROJECT_ID="${REACT_APP_FIREBASE_PROJECT_ID:-tgs-int-genai-vertextai-dev-01}"
REACT_APP_FIREBASE_APP_ID="${REACT_APP_FIREBASE_APP_ID:-firebase_app_id}"
REACT_APP_ALLOWED_DOMAIN="${REACT_APP_ALLOWED_DOMAIN:-teksystems.com}"
REACT_APP_GOOGLE_CLIENT_ID="${REACT_APP_GOOGLE_CLIENT_ID:-325784336727-oq1kno1j5ak88u5vr6ar90o8n6e81v9o.apps.googleusercontent.com}"
FIREBASE_API_KEY_SECRET_NAME="${FIREBASE_API_KEY_SECRET_NAME:-firebase-api-key}"
FIREBASE_API_KEY_SECRET_CANDIDATES="${FIREBASE_API_KEY_SECRET_CANDIDATES:-firebase-api-key,google-api-key}"
SECRETS_PROJECT_ID="${SECRETS_PROJECT_ID:-${PROJECT_ID}}"

# Runtime variables consumed by server.py
IMPERSONATE_SERVICE_ACCOUNT="${IMPERSONATE_SERVICE_ACCOUNT:-${SERVICE_ACCOUNT}}"
TARGET_AUDIENCE="${TARGET_AUDIENCE:-https://cx-migration-config-dev-325784336727.us-central1.run.app}"
TARGET_REMOTE_BASE="${TARGET_REMOTE_BASE:-https://cx-migration-config-dev-325784336727.us-central1.run.app}"
ALLOW_INSECURE_REMOTE="${ALLOW_INSECURE_REMOTE:-false}"

# Optional env file support for Cloud Run deployment values.
# This is useful for local deployment config and keeps the runtime settings in one YAML file.
RUNTIME_ENV_PAIRS=()
if [ -f "${ENV_FILE}" ]; then
  while IFS= read -r line || [ -n "${line}" ]; do
    trimmed="${line#${line%%[![:space:]]*}}"
    if [ -z "${trimmed}" ] || [[ "${trimmed}" =~ ^# ]]; then
      continue
    fi
    if [[ "${line}" =~ ^[[:space:]]*([A-Za-z_][A-Za-z0-9_]*)[[:space:]]*:[[:space:]]*(.*)[[:space:]]*$ ]]; then
      key="${BASH_REMATCH[1]}"
      value="${BASH_REMATCH[2]}"
      value="${value%\"}"
      value="${value#\"}"
      value="${value%\'}"
      value="${value#\'}"
      RUNTIME_ENV_PAIRS+=("${key}=${value}")
    fi
  done < "${ENV_FILE}"
fi

# Parse version argument
if [ -z "${1:-}" ]; then
  echo "Error: Version argument required"
  echo "Usage: ./build-and-deploy.sh <version>"
  echo "Example: ./build-and-deploy.sh v1"
  exit 1
fi

# Resolve Firebase API key from Secret Manager if not provided via env var.
if [ -z "${REACT_APP_FIREBASE_API_KEY}" ]; then
  echo "REACT_APP_FIREBASE_API_KEY not set. Trying Secret Manager candidates in project '${SECRETS_PROJECT_ID}'..."
  if command -v gcloud >/dev/null 2>&1; then
    IFS=',' read -r -a _secret_candidates <<< "${FIREBASE_API_KEY_SECRET_CANDIDATES}"
    _resolved_secret_name=""

    # First try explicit secret name, then fallback candidates.
    _ordered_candidates=("${FIREBASE_API_KEY_SECRET_NAME}" "${_secret_candidates[@]}")

    for _secret_name in "${_ordered_candidates[@]}"; do
      _secret_name="$(echo "${_secret_name}" | xargs)"
      [ -z "${_secret_name}" ] && continue

      _secret_value="$(gcloud secrets versions access latest \
        --secret="${_secret_name}" \
        --project="${SECRETS_PROJECT_ID}" 2>/dev/null || true)"

      if [ -n "${_secret_value}" ]; then
        REACT_APP_FIREBASE_API_KEY="${_secret_value}"
        _resolved_secret_name="${_secret_name}"
        break
      fi
    done

    if [ -n "${_resolved_secret_name}" ]; then
      echo "Resolved REACT_APP_FIREBASE_API_KEY from secret '${_resolved_secret_name}'."
    fi
  else
    echo "Warning: gcloud not found; cannot auto-read secrets."
  fi
fi

if [ -z "${REACT_APP_FIREBASE_API_KEY}" ]; then
  echo "Error: Could not resolve REACT_APP_FIREBASE_API_KEY."
  echo "Checked project: '${SECRETS_PROJECT_ID}'"
  echo "Checked secret candidates: '${FIREBASE_API_KEY_SECRET_NAME}', '${FIREBASE_API_KEY_SECRET_CANDIDATES}'"
  echo "Set it directly, or ensure one of the secret names exists and is readable."
  echo "Example: export REACT_APP_FIREBASE_API_KEY='your-key'"
  echo "Optional: export SECRETS_PROJECT_ID='<project-with-secret>'"
  echo "Optional: export FIREBASE_API_KEY_SECRET_NAME='<exact-secret-name>'"
  exit 1
fi

VERSION="$1"
IMAGE_NAME="${SERVICE_NAME}:${VERSION}"
REGISTRY_IMAGE="${REGISTRY}/${PROJECT_ID}/${ARTIFACT_REPO}/${SERVICE_NAME}:${VERSION}"

echo "=========================================="
echo "Building and Deploying: ${VERSION}"
echo "=========================================="
echo "Project ID:      ${PROJECT_ID}"
echo "Region:          ${REGION}"
echo "Registry:        ${REGISTRY}"
echo "Artifact Repo:   ${ARTIFACT_REPO}"
echo "Service Name:    ${SERVICE_NAME}"
echo "Version:         ${VERSION}"
echo "Local Image:     ${IMAGE_NAME}"
echo "Registry Image:  ${REGISTRY_IMAGE}"
echo "Service Account: ${SERVICE_ACCOUNT}"
echo "=========================================="
echo ""

# Step 1: Build Docker image with React build args
echo "Step 1: Building Docker image (linux/amd64)..."
docker build \
  --platform linux/amd64 \
  --build-arg "REACT_APP_FIREBASE_API_KEY=${REACT_APP_FIREBASE_API_KEY}" \
  --build-arg "REACT_APP_FIREBASE_AUTH_DOMAIN=${REACT_APP_FIREBASE_AUTH_DOMAIN}" \
  --build-arg "REACT_APP_FIREBASE_PROJECT_ID=${REACT_APP_FIREBASE_PROJECT_ID}" \
  --build-arg "REACT_APP_FIREBASE_APP_ID=${REACT_APP_FIREBASE_APP_ID}" \
  --build-arg "REACT_APP_ALLOWED_DOMAIN=${REACT_APP_ALLOWED_DOMAIN}" \
  --build-arg "REACT_APP_GOOGLE_CLIENT_ID=${REACT_APP_GOOGLE_CLIENT_ID}" \
  -t "${IMAGE_NAME}" .
echo "Image built: ${IMAGE_NAME}"
echo ""

# Step 2: Tag for Artifact Registry
echo "Step 2: Tagging image for Artifact Registry..."
docker tag "${IMAGE_NAME}" "${REGISTRY_IMAGE}"
echo "Image tagged: ${REGISTRY_IMAGE}"
echo ""

# Step 3: Push to Artifact Registry
echo "Step 3: Authenticating Docker with Artifact Registry and pushing image..."
gcloud auth configure-docker "${REGISTRY}" --quiet
docker push "${REGISTRY_IMAGE}"
echo "Image pushed to Artifact Registry"
echo ""

# Step 4: Deploy to Cloud Run
echo "Step 4: Deploying to Cloud Run..."
DEPLOY_ENV_VARS=()
# Start with the shell defaults, then override them with values from the env file if present.
DEPLOY_ENV_VARS+=("IMPERSONATE_SERVICE_ACCOUNT=${IMPERSONATE_SERVICE_ACCOUNT}")
DEPLOY_ENV_VARS+=("TARGET_AUDIENCE=${TARGET_AUDIENCE}")
DEPLOY_ENV_VARS+=("TARGET_REMOTE_BASE=${TARGET_REMOTE_BASE}")
DEPLOY_ENV_VARS+=("ALLOW_INSECURE_REMOTE=${ALLOW_INSECURE_REMOTE}")
for entry in "${RUNTIME_ENV_PAIRS[@]}"; do
 key="${entry%%=*}"
 value="${entry#*=}"
 case "${key}" in
   IMPERSONATE_SERVICE_ACCOUNT|TARGET_AUDIENCE|TARGET_REMOTE_BASE|ALLOW_INSECURE_REMOTE)
     DEPLOY_ENV_VARS=("${DEPLOY_ENV_VARS[@]/${key}=*/${key}=${value}}")
     DEPLOY_ENV_VARS+=("${key}=${value}")
     ;;
   *)
     DEPLOY_ENV_VARS+=("${key}=${value}")
     ;;
 esac
done

deploy_env_vars_string="${DEPLOY_ENV_VARS[*]}"
deploy_env_vars_string="${deploy_env_vars_string// /|}"

gcloud --quiet run deploy "${CLOUD_RUN_SERVICE}" \
 --image="${REGISTRY_IMAGE}" \
 --region="${REGION}" \
 --project="${PROJECT_ID}" \
 --service-account="${SERVICE_ACCOUNT}" \
 --allow-unauthenticated \
 --timeout=300 \
 --memory=512Mi \
 --port=8080 \
 --set-env-vars="^|^${deploy_env_vars_string}"
echo "Deployed to Cloud Run"
echo ""

echo "=========================================="
echo "Build and Deploy Complete"
echo "=========================================="
echo "Image:   ${REGISTRY_IMAGE}"
echo "Service: ${CLOUD_RUN_SERVICE}"
echo "Region:  ${REGION}"
echo "Project: ${PROJECT_ID}"
echo "=========================================="
