export type GoogleUser = {
  email: string;
  displayName: string;
  givenName?: string;
  familyName?: string;
  picture?: string;
  emailVerified?: boolean;
  sub?: string;
};

type PersistedGoogleSession = {
  credential: string;
  user: GoogleUser;
};

const STORAGE_KEY = 'google-auth-session';
const defaultClientId = '325784336727-oq1kno1j5ak88u5vr6ar90o8n6e81v9o.apps.googleusercontent.com';
const clientId = (process.env.REACT_APP_GOOGLE_CLIENT_ID || defaultClientId).trim();
const domainHint = (process.env.REACT_APP_ALLOWED_DOMAIN || 'teksystems.com').trim().toLowerCase();
const authEnabled = process.env.NODE_ENV !== 'test' && Boolean(clientId);

let googleScriptPromise: Promise<void> | null = null;

function loadGoogleScript(): Promise<void> {
  if (window.google?.accounts?.id) return Promise.resolve();
  if (googleScriptPromise) return googleScriptPromise;

  googleScriptPromise = new Promise((resolve, reject) => {
    const existingScript = document.getElementById('google-identity-services');
    if (existingScript) {
      existingScript.addEventListener('load', () => resolve(), { once: true });
      existingScript.addEventListener('error', () => reject(new Error('Failed to load Google Identity Services.')), { once: true });
      return;
    }

    const script = document.createElement('script');
    script.id = 'google-identity-services';
    script.src = 'https://accounts.google.com/gsi/client';
    script.async = true;
    script.defer = true;
    script.onload = () => resolve();
    script.onerror = () => reject(new Error('Failed to load Google Identity Services.'));
    document.head.appendChild(script);
  });

  return googleScriptPromise;
}

function decodeJwtPayload(token: string): Record<string, unknown> {
  const parts = token.split('.');
  if (parts.length < 2) throw new Error('Invalid Google credential.');

  const base64 = parts[1].replace(/-/g, '+').replace(/_/g, '/');
  const padded = base64.padEnd(Math.ceil(base64.length / 4) * 4, '=');
  return JSON.parse(window.atob(padded)) as Record<string, unknown>;
}

function normalizeUserFromCredential(credential: string): GoogleUser {
  const payload = decodeJwtPayload(credential);
  const email = String(payload.email || '');

  if (!email) {
    throw new Error('Google did not return an email address.');
  }

  if (!isAllowedEmail(email)) {
    throw new Error(`Please sign in with your @${domainHint} Google account.`);
  }

  return {
    email,
    displayName: String(payload.name || email),
    givenName: typeof payload.given_name === 'string' ? payload.given_name : undefined,
    familyName: typeof payload.family_name === 'string' ? payload.family_name : undefined,
    picture: typeof payload.picture === 'string' ? payload.picture : undefined,
    emailVerified: Boolean(payload.email_verified),
    sub: typeof payload.sub === 'string' ? payload.sub : undefined,
  };
}

let googleIdInitialized = false;
let activeCredentialCallback: ((response: google.accounts.id.CredentialResponse) => void) | null = null;

async function ensureGoogleIdInitialized(callback: (response: google.accounts.id.CredentialResponse) => void): Promise<void> {
  if (!authEnabled || !clientId) {
    throw new Error('Google sign-in is not configured. Add REACT_APP_GOOGLE_CLIENT_ID.');
  }

  await loadGoogleScript();

  if (!window.google?.accounts?.id) {
    throw new Error('Google Identity Services is unavailable.');
  }

  // Keep the latest callback current without re-calling initialize(), which GSI warns against.
  activeCredentialCallback = callback;
  if (googleIdInitialized) return;
  googleIdInitialized = true;

  window.google.accounts.id.initialize({
    client_id: clientId,
    callback: (response) => activeCredentialCallback?.(response),
    auto_select: false,
    cancel_on_tap_outside: true,
    context: 'signin',
  });
}

function isAllowedEmail(email: string): boolean {
  return email.toLowerCase().endsWith(`@${domainHint}`);
}

function persistSession(session: PersistedGoogleSession) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(session));
}

export function getStoredGoogleUser(): GoogleUser | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as PersistedGoogleSession;
    if (!parsed?.user?.email) return null;
    if (!isAllowedEmail(parsed.user.email)) return null;
    return parsed.user;
  } catch {
    return null;
  }
}

export function getStoredGoogleCredential(): string | null {
  const session = getStoredGoogleSession();
  return session?.credential || null;
}

function getStoredGoogleSession(): PersistedGoogleSession | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as PersistedGoogleSession;
    if (!parsed?.credential || !parsed?.user?.email) return null;
    if (!isAllowedEmail(parsed.user.email)) return null;
    return parsed;
  } catch {
    return null;
  }
}

export async function initializeGoogleSignInButton(
  element: HTMLElement,
  onSuccess: (user: GoogleUser) => void,
  onError: (message: string) => void,
): Promise<void> {
  await ensureGoogleIdInitialized((response) => {
    try {
      if (!response.credential) {
        onError('Google sign-in did not return a credential.');
        return;
      }

      const user = normalizeUserFromCredential(response.credential);
      persistSession({ credential: response.credential, user });
      onSuccess(user);
    } catch (error) {
      void clearGoogleSession();
      onError(error instanceof Error ? error.message : 'Google sign-in failed.');
    }
  });

  element.innerHTML = '';
  window.google.accounts.id.renderButton(element, {
    type: 'standard',
    theme: 'outline',
    size: 'large',
    text: 'signin_with',
    shape: 'pill',
    logo_alignment: 'left',
    width: 360,
  });
}

export async function clearGoogleSession(): Promise<void> {
  const stored = getStoredGoogleSession();
  localStorage.removeItem(STORAGE_KEY);

  if (window.google?.accounts?.id) {
    window.google.accounts.id.disableAutoSelect();
  }

  if (stored?.user?.email && window.google?.accounts?.id) {
    await new Promise<void>((resolve) => {
      window.google.accounts.id.revoke(stored.user.email, () => resolve());
    });
  }
}

export function isGoogleLibraryReady(): boolean {
  return authEnabled;
}

export { authEnabled, clientId, domainHint };
