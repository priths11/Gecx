import { useEffect, useState, useMemo, useCallback } from 'react';
import AppHeader from './components/AppHeader';
import SessionBanner from './components/ui/SessionBanner';
import PortfolioDiscoveryPage from './components/PortfolioDiscoveryPage';
import IngestionPage from './components/IngestionPage';
import WorkflowStepper from './components/WorkflowStepper';
import OutputOnePage from './components/OutputOnePage';
import OutputTwoPage from './components/OutputTwoPage';
import MigrationDashboard from './components/MigrationDashboard';
import ConfigurationDrawer from './components/ConfigurationDrawer';
import AccountNotFoundModal from './components/AccountNotFoundModal';
import SignupPage from './components/SignupPage';
import LoginPage from './components/LoginPage';
import JumpBar from './components/JumpBar';
import { OUTPUT_TWO_TABS } from './data/mockData';
import { authEnabled, clearGoogleSession, domainHint, getStoredGoogleUser } from './googleAuth';
import type { GoogleUser } from './googleAuth';
import { uploadFiles, runMigration, saveApprovedSummary, generateCxSummary, checkValidity, registerUser, getConfig, getJobReport, FALLBACK_JOB_REPORT } from './api/migrationApi';
import type { JobReportResponse } from './api/migrationApi';
import { ToastProvider, useToast } from './context/ToastContext';
import type { DiscoveredProject, SyncedProject, QuotaTier } from './workflowTypes';
import './context/ToastContext.css';
import './App.css';

// ─── Helpers ──────────────────────────────────────────────────────────────────

/** Parse a project name from a ZIP filename.
 * Format: <ID>_<DDMMYY>_<ProjectName>.zip  →  ProjectName
 * Falls back to the full filename without extension. */
function parseProjectName(filename: string): string {
  const withoutExt = filename.replace(/\.zip$/i, '');
  const parts = withoutExt.split('_');
  if (parts.length >= 3) return parts.slice(2).join('_');
  return withoutExt;
}

/** Derive a short pseudo agent-id from the project name for display only. */
function deriveAgentId(name: string): string {
  const hash = name.split('').reduce((acc, c) => acc + c.charCodeAt(0), 0);
  return `ag-${String(hash % 9000 + 1000).slice(0, 4)}-${name.slice(0, 4).toLowerCase()}`;
}

// ─── Quota / tier configuration ───────────────────────────────────────────────

const QUOTA_TOTAL = 5;
const DEFAULT_TIERS: QuotaTier[] = [
  { label: 'Simple',  used: 0, total: 2 },
  { label: 'Medium',  used: 0, total: 2 },
  { label: 'Complex', used: 0, total: 1 },
];

// ─── Workflow screen names ────────────────────────────────────────────────────

type Screen = 'discovery' | 'ingestion' | 'output1' | 'output2' | 'dashboard';

// ─── Inner App ────────────────────────────────────────────────────────────────

function AppContent() {
  const { showToast } = useToast();

  // ── Auth state ──
  const [user, setUser]                         = useState<GoogleUser | null>(null);
  const [loading, setLoading]                   = useState(true);
  const [registrationChecked, setRegistrationChecked] = useState(false);
  const [showAccountNotFound, setShowAccountNotFound] = useState(false);
  const [isSigningUp, setIsSigningUp]           = useState(false);
  const [showConfigs, setShowConfigs]           = useState(false);
  const [globalConfig, setGlobalConfig]         = useState<any>(null);
  const [needsConfig, setNeedsConfig]           = useState<boolean>(false);
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const [quotaRemaining, setQuotaRemaining]     = useState<number | null>(null);

  // ── Navigation state ──
  const [activeScreen, setActiveScreen]         = useState<Screen>('discovery');
  const [lastActiveScreen, setLastActiveScreen] = useState<Screen>('discovery');
  const [isRailCollapsed, setIsRailCollapsed]    = useState(false);

  // ── Step 1: Portfolio Discovery state ──
  const [discoveredProjects, setDiscoveredProjects] = useState<DiscoveredProject[]>([]);
  const [bucketName, setBucketName]             = useState('BUCKET_ENTERPRISE_BATCH');

  // ── Step 2: Ingestion / GCS Sync state ──
  const [syncedProjects, setSyncedProjects]     = useState<SyncedProject[]>([]);
  const [isSyncingBatch, setIsSyncingBatch]     = useState(false);
  const [isRunningMigration, setIsRunningMigration] = useState(false);

  // ── Step 3: Output 1 state ──
  const [apiData, setApiData]                   = useState<Record<string, any> | null>(null);
  const [apiResponseMeta, setApiResponseMeta]   = useState<{ job_id?: number; status_code?: number; output_dir?: string; output_files?: string[] } | null>(null);
  const [isApprovingOutput1, setIsApprovingOutput1] = useState(false);
  const [isGeneratingOutput1, setIsGeneratingOutput1] = useState(false);
  const [gecxSummaryId, setGecxSummaryId]       = useState<number | null>(null);
  const [output1Edits, setOutput1Edits]         = useState<Record<string, string>>({});
  const [activeProjectIndex, setActiveProjectIndex] = useState(0);

  // ── Step 4: Output 2 state ──
  const [activeOutputTwoTab, setActiveOutputTwoTab] = useState(OUTPUT_TWO_TABS[0]);
  const [gecxSummaryData, setGecxSummaryData]   = useState<any>(null);
  const [output2Edits, setOutput2Edits]         = useState<Record<string, string>>({});

  // ── Step 5: Reporting state ──
  const [reportData, setReportData]             = useState<JobReportResponse | null>(null);
  const [isFetchingReport, setIsFetchingReport] = useState<boolean>(false);

  // Reset edits when underlying data changes
  useEffect(() => { setOutput1Edits({}); }, [apiData]);
  useEffect(() => { setOutput2Edits({}); }, [gecxSummaryData]);

  // ── Auth effects ──
  useEffect(() => {
    setUser(getStoredGoogleUser());
  }, []);

  useEffect(() => {
    if (!user?.email) {
      setLoading(false);
      setRegistrationChecked(false);
      setShowAccountNotFound(false);
      return;
    }
    setLoading(true);
    Promise.allSettled([
      checkValidity(user.email)
        .then(res => {
          if (res?.data?.registered === false) {
            setShowAccountNotFound(true);
            setRegistrationChecked(false);
          } else {
            setQuotaRemaining(res.data?.quota_remaining ?? 0);
            setRegistrationChecked(true);
            setShowAccountNotFound(false);
          }
        })
        .catch(() => { setQuotaRemaining(0); setRegistrationChecked(true); }),
      getConfig(user.email)
        .then(res => {
          if (res.status === 'success' && res.data && res.data.length > 0) {
            setGlobalConfig(res.data);
            setNeedsConfig(false);
          } else {
            setGlobalConfig(null);
            setNeedsConfig(true);
          }
        })
        .catch(() => { setGlobalConfig(null); setNeedsConfig(true); }),
    ]).finally(() => setLoading(false));
  }, [user]);

  // ── Sign-out ──
  const handleSignOut = async () => {
    setActiveScreen('discovery');
    setLastActiveScreen('discovery');
    setRegistrationChecked(false);
    setDiscoveredProjects([]);
    setSyncedProjects([]);
    setBucketName('BUCKET_ENTERPRISE_BATCH');
    setApiData(null);
    setApiResponseMeta(null);
    setGecxSummaryData(null);
    setGecxSummaryId(null);
    setOutput1Edits({});
    setOutput2Edits({});
    setQuotaRemaining(null);
    setGlobalConfig(null);
    setNeedsConfig(false);
    setActiveProjectIndex(0);
    setUser(null);
    await clearGoogleSession();
  };

  // ── Step 1 handlers: Portfolio Discovery ──

  const handleAddZipFiles = useCallback((files: File[]) => {
    setDiscoveredProjects(prev => {
      const newProjects: DiscoveredProject[] = files.map(f => ({
        id: `${Date.now()}-${f.name}`,
        name: parseProjectName(f.name),
        agentId: deriveAgentId(parseProjectName(f.name)),
        sourceType: 'ZIP Upload',
        categorizationStatus: 'Unanalyzed',
        rawFile: f,
        selected: true,
      }));
      return [...prev, ...newProjects];
    });
  }, []);

  const handleToggleSelect = useCallback((id: string) => {
    setDiscoveredProjects(prev =>
      prev.map(p => p.id === id ? { ...p, selected: !p.selected } : p)
    );
  }, []);

  const handleSelectAll = useCallback((checked: boolean) => {
    setDiscoveredProjects(prev => prev.map(p => ({ ...p, selected: checked })));
  }, []);

  const handleAnalyze = useCallback(() => {
    showToast('Analysis is not yet implemented.', 'error');
  }, [showToast]);

  const handleLockBucket = useCallback(() => {
    const selected = discoveredProjects.filter(p => p.selected);
    if (!selected.length) { showToast('Select at least one project to lock the bucket.'); return; }
    if (!bucketName.trim()) { showToast('Please enter a bucket name.'); return; }
    setActiveScreen('ingestion');
  }, [discoveredProjects, bucketName, showToast]);

  // ── Step 2 handlers: Ingestion / GCS Sync ──

  const handleSyncBatch = async () => {
    const selected = discoveredProjects.filter(p => p.selected && p.rawFile);
    if (!selected.length) { showToast('No ZIP files to sync.'); return; }

    setIsSyncingBatch(true);
    setSyncedProjects([]);

    const results: SyncedProject[] = [];
    for (const project of selected) {
      try {
        const body = await uploadFiles([project.rawFile!], [], user?.email || '');
        const jobId = String(body?.job_id || '');
        if (jobId) {
          results.push({
            name: project.name,
            jobId,
            gcsPath: `gs://cx-migrator/${bucketName}/${project.name}/${jobId}/`,
            bqSink: `cx_audit_log.${bucketName}.${jobId}`,
            rawFile: project.rawFile,
          });
        }
      } catch (err: any) {
        showToast(`Failed to upload ${project.name}: ${err?.message}`);
      }
    }

    setSyncedProjects(results);
    if (!results.length) showToast('No projects were synced successfully.');
    setIsSyncingBatch(false);
  };

  const handleInitiateDiscovery = async () => {
    if (!syncedProjects.length) { showToast('Sync to GCS first.'); return; }

    const firstProject = syncedProjects[activeProjectIndex] || syncedProjects[0];
    const jobId = firstProject.jobId;

    setApiData(null);
    setIsRunningMigration(true);
    try {
      const body = await runMigration(jobId, user?.email || '');
      if (body && typeof body === 'object' && body.data) {
        setApiData(body.data);
        setApiResponseMeta({
          job_id: Number(body.job_id),
          status_code: body.status_code,
          output_dir: body.output_dir,
          output_files: body.output_files,
        });
      } else if (body && typeof body === 'object') {
        const isWrapper = !!(body.job_id || body.status_code);
        if (!isWrapper) { setApiData(body); }
        else showToast('Invalid API response: "data" field missing.');
      }
      setActiveScreen('output1');
    } catch (err: any) {
      showToast(err?.message || 'Failed to initiate automated discovery.');
    } finally {
      setIsRunningMigration(false);
    }
  };

  // ── Step 3 handlers: Output 1 ──

  const dynamicArtifacts = useMemo(() => {
    const metadataKeys = new Set(['job_id', 'jobid', 'status_code', 'statuscode', 'output_dir', 'outputdir', 'output_files', 'outputfiles', 'data', 'message', 'error', 'status']);
    if (!apiData) return [];
    return Object.keys(apiData)
      .filter(k => !metadataKeys.has(k.toLowerCase()))
      .map(k => ({ name: k, type: 'json', apiKey: k, content: apiData[k] }));
  }, [apiData]);

  const handleOutput1Approve = async (editedData: Record<string, any>) => {
    if (isApprovingOutput1) return;
    setIsApprovingOutput1(true);
    try {
      const savePayload = { ...(apiResponseMeta ?? {}), data: JSON.stringify(editedData) };
      const body1 = await saveApprovedSummary(savePayload);
      setGecxSummaryId(Number(body1.id ?? body1.job_id));
    } catch (err: any) {
      showToast(err?.message || 'Failed to save approved summary.');
    } finally {
      setIsApprovingOutput1(false);
    }
  };

  const handleOutput1Generate = async () => {
    if (isGeneratingOutput1 || !gecxSummaryId) return;
    setIsGeneratingOutput1(true);
    try {
      const body2 = await generateCxSummary(gecxSummaryId, user?.email || '');
      setGecxSummaryData(body2);
      setActiveOutputTwoTab(OUTPUT_TWO_TABS[0]);
      setActiveScreen('output2');
    } catch (err: any) {
      showToast(err?.message || 'Failed to generate CX summary.');
    } finally {
      setIsGeneratingOutput1(false);
    }
  };

  // ── Step 4 / 5 handlers: View Reporting ──
  const handleViewReporting = async (jobIdParam?: number | string) => {
    setIsFetchingReport(true);
    const email = user?.email || 'aarakkal@teksystems.com';
    const effectiveJobId = Number(jobIdParam || gecxSummaryId || syncedProjects[activeProjectIndex]?.jobId || 37900977);
    try {
      const resp = await getJobReport(effectiveJobId, email);
      if (resp && resp.status === 'success' && resp.data) {
        setReportData(resp);
        showToast('Job report fetched successfully.', 'success');
      } else {
        setReportData(FALLBACK_JOB_REPORT);
      }
    } catch (err: any) {
      console.warn('get_job_report failed, using fallback data:', err);
      setReportData(FALLBACK_JOB_REPORT);
      showToast('Loaded job report preview.', 'info');
    } finally {
      setIsFetchingReport(false);
      setLastActiveScreen('output2');
      setActiveScreen('dashboard');
    }
  };

  // ── Workflow step state ──
  const getWorkflowStepState = (step: number): 'active' | 'complete' | 'idle' | 'synced' => {
    const order: Screen[] = ['discovery', 'ingestion', 'output1', 'output2', 'dashboard'];
    const currentIdx = order.indexOf(activeScreen);
    if (step - 1 < currentIdx) return 'complete';
    if (step - 1 === currentIdx) return 'active';
    return 'idle';
  };

  // ── Derived project names for selectors ──
  const projectNames = syncedProjects.map(p => p.name);
  const activeProjectName = projectNames[activeProjectIndex] || '';

  const signInSubtitle = domainHint
    ? `Sign in with your @${domainHint} account`
    : 'Sign in with your Google Workspace account';

  // ── Loading / auth screens ──
  if (loading || (user && !registrationChecked)) {
    return (
      <main className="app-shell">
        <section className="auth-card">
          <p className="subtitle">Checking your session…</p>
          {registrationChecked === false && user && !showAccountNotFound && (
            <p style={{ fontSize: '12px', color: '#64748b', marginTop: '8px' }}>Verifying registration status...</p>
          )}
        </section>
        {showAccountNotFound && (
          <AccountNotFoundModal
            onRegister={() => { setIsSigningUp(true); void handleSignOut(); setShowAccountNotFound(false); }}
            onCancel={() => { setShowAccountNotFound(false); void handleSignOut(); }}
          />
        )}
      </main>
    );
  }

  if (!user) {
    if (isSigningUp) {
      return (
        <SignupPage
          onCancel={() => setIsSigningUp(false)}
          onRegister={async (data) => {
            try {
              await registerUser({
                username: data.email.split('@')[0],
                official_email: data.email,
                company_name: data.companyName,
                address_line1: data.address1,
                address_line2: data.address2 || '',
                city: data.city,
                state: data.state,
                postal_code: data.postalCode,
                country: data.country,
                phone_number: data.phone,
                login_type: data.loginType,
                customer_type: data.customerType,
                promotion_id: data.promotion_id,
              });
              showToast('Registration successful! Please sign in.', 'success');
              setIsSigningUp(false);
            } catch (err: any) {
              showToast(err?.message || 'Registration failed.', 'error');
            }
          }}
        />
      );
    }
    return (
      <LoginPage
        authEnabled={authEnabled}
        onGoogleSignIn={(nextUser) => setUser(nextUser)}
        onGoogleError={(message) => showToast(message || 'Sign-in failed. Please try again.')}
        signInSubtitle={signInSubtitle}
        onSignUpClick={() => setIsSigningUp(true)}
        onSignInAzure={() => showToast('Azure SSO sign-in is not yet configured for this environment.', 'error')}
        onSignInOkta={() => showToast('OKTA sign-in is not yet configured for this environment.', 'error')}
      />
    );
  }

  // ── Authenticated app shell ──
  return (
    <main className="catalog-layout">
      {/* Header */}
      <AppHeader
        onSignOut={handleSignOut}
        user={user}
        onToggleConfigs={() => setShowConfigs(prev => !prev)}
        needsConfig={needsConfig}
        onSelectProject={(id) => {
          setLastActiveScreen(activeScreen);
          setActiveScreen('dashboard');
        }}
      />

      {/* BigQuery Session Banner — always visible once logged in */}
      <SessionBanner
        sessionId={bucketName ? `BQ_SESSION_${new Date().toISOString().slice(0,10).replace(/-/g,'')}_${bucketName.split('_').pop()}` : null}
        lastModified="24 mins ago"
        onResume={() => showToast('Session resumption is not yet implemented.', 'error')}
        onStartFresh={() => {
          setDiscoveredProjects([]);
          setSyncedProjects([]);
          setApiData(null);
          setGecxSummaryData(null);
          setGecxSummaryId(null);
          setActiveScreen('discovery');
          showToast('Started fresh scan.', 'success');
        }}
      />

      {/* Workflow Stepper — always visible on all 5 screens */}
      <WorkflowStepper
        activeScreen={activeScreen}
        getWorkflowStepState={getWorkflowStepState}
        syncSucceeded={syncedProjects.length > 0}
      />

      {/* Main content area */}
      <section className={
        activeScreen === 'output1' || activeScreen === 'output2'
          ? 'output-shell'
          : activeScreen === 'dashboard'
            ? 'dashboard-shell'
            : 'ingest-shell'
      }>

        {/* Step 1: Portfolio Discovery */}
        {activeScreen === 'discovery' && (
          <PortfolioDiscoveryPage
            discoveredProjects={discoveredProjects}
            bucketName={bucketName}
            onBucketNameChange={setBucketName}
            onAddZipFiles={handleAddZipFiles}
            onFetchGcpProjects={() => showToast('GCP project fetch is not yet configured.', 'error')}
            onToggleSelect={handleToggleSelect}
            onSelectAll={handleSelectAll}
            onAnalyze={handleAnalyze}
            onLockBucket={handleLockBucket}
            quotaTotal={QUOTA_TOTAL}
            tiers={DEFAULT_TIERS}
          />
        )}

        {/* Step 2: Data Ingestion & GCS Sync */}
        {activeScreen === 'ingestion' && (
          <IngestionPage
            bucketName={bucketName}
            lockedProjects={discoveredProjects.filter(p => p.selected)}
            syncedProjects={syncedProjects}
            isSyncing={isSyncingBatch}
            isRunningMigration={isRunningMigration}
            onSyncBatch={handleSyncBatch}
            onBack={() => setActiveScreen('discovery')}
            onInitiateDiscovery={handleInitiateDiscovery}
          />
        )}

        {/* Step 3: HITL SSOT AST Review */}
        {activeScreen === 'output1' && (
          <OutputOnePage
            artifacts={dynamicArtifacts}
            isApproving={isApprovingOutput1}
            isGenerating={isGeneratingOutput1}
            approvedId={gecxSummaryId}
            onApprove={handleOutput1Approve}
            onGenerate={handleOutput1Generate}
            onArtifactSelect={() => {}}
            localEdits={output1Edits}
            onEditsChange={setOutput1Edits}
            bucketName={bucketName}
            projectNames={projectNames}
            activeProjectName={activeProjectName}
            onProjectChange={(name) => {
              const idx = projectNames.indexOf(name);
              if (idx >= 0) setActiveProjectIndex(idx);
            }}
            onBack={() => setActiveScreen('ingestion')}
            onProceed={() => { if (gecxSummaryId) setActiveScreen('output2'); }}
          />
        )}

        {/* Step 4: HITL GECX Ready Files */}
        {activeScreen === 'output2' && (
          <OutputTwoPage
            activeTab={activeOutputTwoTab}
            onTabChange={setActiveOutputTwoTab}
            tabs={OUTPUT_TWO_TABS}
            gecxData={gecxSummaryData}
            gecxId={gecxSummaryId}
            localEdits={output2Edits}
            onEditsChange={setOutput2Edits}
            user={user}
            bucketName={bucketName}
            projectNames={projectNames}
            activeProjectName={activeProjectName}
            onProjectChange={(name) => {
              const idx = projectNames.indexOf(name);
              if (idx >= 0) setActiveProjectIndex(idx);
            }}
            onBack={() => setActiveScreen('output1')}
            onProceed={() => {
              setLastActiveScreen('output2');
              setActiveScreen('dashboard');
            }}
            onViewReporting={handleViewReporting}
            isFetchingReport={isFetchingReport}
          />
        )}

        {/* Step 5: Operational Reporting Dashboard */}
        {activeScreen === 'dashboard' && (
          <div className="dashboard-content-wrapper">
            <MigrationDashboard
              projectId={activeProjectName}
              onClose={() => setActiveScreen(lastActiveScreen)}
              user={user}
              bucketName={bucketName}
              syncedProjects={syncedProjects}
              totalDiscovered={discoveredProjects.length}
              reportData={reportData}
              onRefreshReport={handleViewReporting}
              isLoadingReport={isFetchingReport}
            />
          </div>
        )}

        {/* Configuration Drawer (available from any screen) */}
        <ConfigurationDrawer
          isOpen={showConfigs}
          onClose={() => setShowConfigs(false)}
          user={user}
          globalConfig={globalConfig}
          onConfigSaved={(updatedConfig) => {
            setGlobalConfig(updatedConfig);
            setNeedsConfig(false);
          }}
        />

        <JumpBar onNavigate={(screen) => setActiveScreen(screen as Screen)} activeScreen={activeScreen} />
      </section>
    </main>
  );
}

// ─── Root App ─────────────────────────────────────────────────────────────────

function App() {
  return (
    <ToastProvider>
      <AppContent />
    </ToastProvider>
  );
}

export default App;
