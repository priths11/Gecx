import React from 'react';

export const HITL_SSOT_TOOLTIP_TEXT = {
  HEADING: (
    <>
      <strong>HITL SSOT:-</strong><br/>
      <li><b>Recommended Values for HITL SSOT</b></li>
      Model:-  Gemini 2.5 Flash<br/>
      Top p:- 0.95<br/>
      Candidate Count:- 1<br/>
      Output Token:- 8192<br/>
      Top K:- 40<br/>
      Temperature:- 0
    </>
  ),
  MODEL: (
    <>
      <br/><li><b>Gemini 2.5 Pro: </b><br />This is a highly intelligent model with advanced reasoning capabilities for complex tasks, including coding and data analysis.</li>
      <br/><li><b>Gemini 2.5 Flash: </b><br />This model balances high intelligence and speed, designed for quick reasoning and efficient, cost-effective multimodal tasks.</li>
      <br/><li><b>Gemini 1.5 Flash: </b><br />This is a versatile, mid-sized model designed for complex reasoning and long-context understanding across text, code, and video.</li>
      <br/><li><b>Gemini 1.5 Flash:  </b><br />This lightweight model is optimized for speed and high-volume tasks such as summarization, chat, and data extraction.</li>
    </>
  ),
  TOP_P: (
    <>
      <strong>Top P:-</strong><br/>
      Top-p controls how many likely tokens the model considers while generating the response.<br/>
      Tokens are selected from most probable to least probable until their combined probability reaches the top-p value.<br/>
      A lower top-p makes the output more focused and predictable.<br/>
      A higher top-p allows more variety in wording and structure.<br/>
      For the least variable results, use a low value. For balanced generation, use a value close to 0.9 or 0.95.<br/>
      Default value for summarisation/context extraction/output2 generation: 0.95
    </>
  ),
  CANDIDATE_COUNT: (
    <>
      <strong>Candidate Count:-</strong><br/>
      Candidate count controls how many response candidates the model should generate.<br/>
      A value of 1 returns one model response and is recommended for this solution.<br/>
      Higher values may be useful for experimentation, but they increase cost and require additional selection logic.<br/>
      For automated migration flows, keep this as 1.<br/>
      Default value for summarisation/context extraction/instruction generation: 1
    </>
  ),
  OUTPUT_TOKENS: (
    <>
      <strong>Output Tokens:-</strong><br/>
      Output token limit determines the maximum amount of text generated from one prompt. A token is approximately four characters.<br/>
      A higher token limit allows the model to generate longer summaries, instructions, or JSON output.<br/>
      A lower token limit can reduce cost and response size but may truncate longer outputs.<br/>
      For migration outputs, keep this high enough to avoid incomplete JSON or missing sections.<br/>
      Default value for summarisation/context extraction/instruction generation: 8192
    </>
  ),
  TOP_K: (
    <>
      <strong>Top K:-</strong><br/>
      Top-k limits token selection to the top K most likely next tokens.<br/>
      A lower top-k makes the response more focused and conservative.<br/>
      A higher top-k allows the model to consider more token options.<br/>
      Use this with temperature and top-p to control how creative or predictable the model should be.<br/>
      Default value for summarisation/context extraction/instruction generation: 40
    </>
  ),
  TEMPERATURE: (
    <>
      <strong>Temperature:-</strong><br/>
      Temperature controls the randomness in token selection.<br/>
      A lower temperature is good when you expect a precise or consistent response. A temperature of 0 means the highest probability token is usually selected.<br/>
      A higher temperature can lead to more diverse or unexpected responses.<br/>
      For deterministic extraction or structured JSON generation, keep temperature low.<br/>
      Default value for summarisation/context extraction: 0.0
    </>
  )
};

export const HITL_GECX_TOOLTIP_TEXT = {
  HEADING: (
    <>
      <strong>HITL GECX:-</strong><br/>
      <li><b>Recommended Values for HITL GECX</b></li>
      Model:-  Gemini 2.5 Pro<br/>
      Top p:- 0.95<br/>
      Candidate Count:- 1<br/>
      Output Token:- 8192<br/>
      Top K:- 40<br/>
      Temperature:- 0.2
    </>
  ),
  MODEL: (
    <>
      <br/><li><b>Gemini 2.5 Pro: </b><br />This is a highly intelligent model with advanced reasoning capabilities for complex tasks, including coding and data analysis.</li>
      <br/><li><b>Gemini 2.5 Flash: </b><br />This model balances high intelligence and speed, designed for quick reasoning and efficient, cost-effective multimodal tasks.</li>
      <br/><li><b>Gemini 1.5 Flash: </b><br />This is a versatile, mid-sized model designed for complex reasoning and long-context understanding across text, code, and video.</li>
      <br/><li><b>Gemini 1.5 Flash:  </b><br />This lightweight model is optimized for speed and high-volume tasks such as summarization, chat, and data extraction.</li>
    </>
  ),
  TOP_P: (
    <>
      <strong>Top P:-</strong><br/>
      Top-p controls how many likely tokens the model considers while generating the response.<br/>
      Tokens are selected from most probable to least probable until their combined probability reaches the top-p value.<br/>
      A lower top-p makes the output more focused and predictable.<br/>
      A higher top-p allows more variety in wording and structure.<br/>
      For the least variable results, use a low value. For balanced generation, use a value close to 0.9 or 0.95.<br/>
      Default value for summarisation/context extraction/output2 generation: 0.95
    </>
  ),
  CANDIDATE_COUNT: (
    <>
      <strong>Candidate Count:-</strong><br/>
      Candidate count controls how many response candidates the model should generate.<br/>
      A value of 1 returns one model response and is recommended for this solution.<br/>
      Higher values may be useful for experimentation, but they increase cost and require additional selection logic.<br/>
      For automated migration flows, keep this as 1.<br/>
      Default value for summarisation/context extraction/instruction generation: 1
    </>
  ),
  OUTPUT_TOKENS: (
    <>
      <strong>Output Tokens:-</strong><br/>
      Output token limit determines the maximum amount of text generated from one prompt. A token is approximately four characters.<br/>
      A higher token limit allows the model to generate longer summaries, instructions, or JSON output.<br/>
      A lower token limit can reduce cost and response size but may truncate longer outputs.<br/>
      For migration outputs, keep this high enough to avoid incomplete JSON or missing sections.<br/>
      Default value for summarisation/context extraction/instruction generation: 8192
    </>
  ),
  TOP_K: (
    <>
      <strong>Top K:-</strong><br/>
      Top-k limits token selection to the top K most likely next tokens.<br/>
      A lower top-k makes the response more focused and conservative.<br/>
      A higher top-k allows the model to consider more token options.<br/>
      Use this with temperature and top-p to control how creative or predictable the model should be.<br/>
      Default value for summarisation/context extraction/instruction generation: 40
    </>
  ),
  TEMPERATURE: (
    <>
      <strong>Temperature:-</strong><br/>
      Temperature controls the randomness in token selection.<br/>
      A lower temperature is good when you expect a precise or consistent response. A temperature of 0 means the highest probability token is usually selected.<br/>
      A higher temperature can lead to more diverse or unexpected responses.<br/>
      For deterministic extraction or structured JSON generation, keep temperature low.<br/>
      Default value for summarisation/context extraction: 0.0
    </>
  )
};

export const AGENT_BUILDER_TOOLTIP_TEXT = {
  HEADING: (
    <>
      <strong>Agent Builder:-</strong><br/>
      <li><b>Recommended Values for Agent Builder</b></li>
      Model:-  Gemini 2.5 Pro<br/>
      Top p:- 0.95<br/>
      Candidate Count:- 1<br/>
      Output Token:- 8192<br/>
      Top K:- 40<br/>
      Temperature:- 0.2
    </>
  ),
  MODEL: (
    <>
      <br/><li><b>Gemini 2.5 Pro: </b><br />This is a highly intelligent model with advanced reasoning capabilities for complex tasks, including coding and data analysis.</li>
      <br/><li><b>Gemini 2.5 Flash: </b><br />This model balances high intelligence and speed, designed for quick reasoning and efficient, cost-effective multimodal tasks.</li>
      <br/><li><b>Gemini 1.5 Flash: </b><br />This is a versatile, mid-sized model designed for complex reasoning and long-context understanding across text, code, and video.</li>
      <br/><li><b>Gemini 1.5 Flash:  </b><br />This lightweight model is optimized for speed and high-volume tasks such as summarization, chat, and data extraction.</li>
    </>
  ),
  TOP_P: (
    <>
      <strong>Top P:-</strong><br/>
      Top-p controls how many likely tokens the model considers while generating the response.<br/>
      Tokens are selected from most probable to least probable until their combined probability reaches the top-p value.<br/>
      A lower top-p makes the output more focused and predictable.<br/>
      A higher top-p allows more variety in wording and structure.<br/>
      For the least variable results, use a low value. For balanced generation, use a value close to 0.9 or 0.95.<br/>
      Default value for summarisation/context extraction/output2 generation: 0.95
    </>
  ),
  CANDIDATE_COUNT: (
    <>
      <strong>Candidate Count:-</strong><br/>
      Candidate count controls how many response candidates the model should generate.<br/>
      A value of 1 returns one model response and is recommended for this solution.<br/>
      Higher values may be useful for experimentation, but they increase cost and require additional selection logic.<br/>
      For automated migration flows, keep this as 1.<br/>
      Default value for summarisation/context extraction/instruction generation: 1
    </>
  ),
  OUTPUT_TOKENS: (
    <>
      <strong>Output Tokens:-</strong><br/>
      Output token limit determines the maximum amount of text generated from one prompt. A token is approximately four characters.<br/>
      A higher token limit allows the model to generate longer summaries, instructions, or JSON output.<br/>
      A lower token limit can reduce cost and response size but may truncate longer outputs.<br/>
      For migration outputs, keep this high enough to avoid incomplete JSON or missing sections.<br/>
      Default value for summarisation/context extraction/instruction generation: 8192
    </>
  ),
  TOP_K: (
    <>
      <strong>Top K:-</strong><br/>
      Top-k limits token selection to the top K most likely next tokens.<br/>
      A lower top-k makes the response more focused and conservative.<br/>
      A higher top-k allows the model to consider more token options.<br/>
      Use this with temperature and top-p to control how creative or predictable the model should be.<br/>
      Default value for summarisation/context extraction/instruction generation: 40
    </>
  ),
  TEMPERATURE: (
    <>
      <strong>Temperature:-</strong><br/>
      Temperature controls the randomness in token selection.<br/>
      A lower temperature is good when you expect a precise or consistent response. A temperature of 0 means the highest probability token is usually selected.<br/>
      A higher temperature can lead to more diverse or unexpected responses.<br/>
      For deterministic extraction or structured JSON generation, keep temperature low.<br/>
      Default value for summarisation/context extraction: 0.0
    </>
  )
};

export const InfoTooltip = ({ content }: { content: React.ReactNode }) => (
  <div className="tooltip-container" style={{ position: 'relative', display: 'flex', alignItems: 'center' }}>
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#4338ca" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ cursor: 'help' }}>
      <circle cx="12" cy="12" r="10"></circle>
      <line x1="12" y1="16" x2="12" y2="12"></line>
      <line x1="12" y1="8" x2="12.01" y2="8"></line>
    </svg>
    <div className="tooltip-content" style={{ width: '300px', padding: '12px', fontSize: '12px', lineHeight: '1.5', fontWeight: 'normal', zIndex: 10 }}>
      {content}
    </div>
  </div>
);
