declare global {
  namespace google {
    namespace accounts {
      namespace id {
        type CredentialResponse = {
          credential: string;
          select_by?: string;
          state?: string;
        };

        type IdConfiguration = {
          client_id: string;
          callback: (response: CredentialResponse) => void;
          auto_select?: boolean;
          cancel_on_tap_outside?: boolean;
          prompt_parent_id?: string;
          state_cookie_domain?: string;
          ux_mode?: 'popup' | 'redirect';
          login_uri?: string;
          nonce?: string;
          context?: 'signin' | 'signup' | 'use';
          hd?: string;
        };

        type GsiButtonConfiguration = {
          type?: 'standard' | 'icon';
          theme?: 'outline' | 'filled_blue' | 'filled_black';
          size?: 'large' | 'medium' | 'small';
          text?: 'signin_with' | 'signup_with' | 'continue_with' | 'signin';
          shape?: 'rectangular' | 'pill' | 'circle' | 'square';
          logo_alignment?: 'left' | 'center';
          width?: string | number;
          locale?: string;
        };

        function initialize(config: IdConfiguration): void;
        function renderButton(parent: HTMLElement, options: GsiButtonConfiguration): void;
        function prompt(momentListener?: (notification: unknown) => void): void;
        function disableAutoSelect(): void;
        function revoke(hint: string, done: () => void): void;
      }
    }
  }

  interface Window {
    google?: {
      accounts?: {
        id?: {
          initialize: typeof google.accounts.id.initialize;
          renderButton: typeof google.accounts.id.renderButton;
          prompt: typeof google.accounts.id.prompt;
          disableAutoSelect: typeof google.accounts.id.disableAutoSelect;
          revoke: typeof google.accounts.id.revoke;
        };
      };
    };
  }
}

export {};
