// ─── Helpers ──────────────────────────────────────────────────────────────────

export const toTitleCase = (s: string) =>
  s.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());

export const toSentenceCase = (s: string): string =>
  s ? s.charAt(0).toUpperCase() + s.slice(1) : s;

const esc = (s: string) =>
  s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

// ─── Rendering decisions ──────────────────────────────────────────────────────

/** Object whose every value is a primitive → render as 2-col table */
const isKvObject = (d: any) =>
  d !== null &&
  typeof d === 'object' &&
  !Array.isArray(d) &&
  Object.values(d).every(v => v === null || typeof v !== 'object');

/** Array of objects that all share the same keys → render as multi-col table */
const isUniformArray = (d: any[]) => {
  if (!d.length || typeof d[0] !== 'object' || d[0] === null || Array.isArray(d[0])) return false;
  const ref = Object.keys(d[0]).join('\0');
  return d.every(item => !Array.isArray(item) && typeof item === 'object' && item !== null && Object.keys(item).join('\0') === ref);
};

// ─── JSON → HTML ──────────────────────────────────────────────────────────────

function renderPrimitive(v: any): string {
  if (v === null || v === undefined) return '<span class="jv-null">—</span>';
  if (typeof v === 'boolean')
    return `<span class="jv-badge ${v ? 'jv-badge-green' : 'jv-badge-gray'}">${v ? 'Yes' : 'No'}</span>`;
  if (typeof v === 'number')
    return `<span class="jv-number">${v}</span>`;
  const s = toSentenceCase(String(v));
  return `<span class="jv-inline-str" contenteditable="true" data-type="string">${esc(s)}</span>`;
}

export function jsonToHtml(data: any): string {
  if (data === null || data === undefined)
    return '<span class="jv-null">—</span>';

  if (typeof data === 'boolean')
    return `<span class="jv-badge ${data ? 'jv-badge-green' : 'jv-badge-gray'}">${data ? 'Yes' : 'No'}</span>`;

  if (typeof data === 'number')
    return `<span class="jv-number" contenteditable="true" data-type="number">${data}</span>`;

  if (typeof data === 'string') {
    if (!data.trim()) return '<span class="jv-null">—</span>';
    return `<p class="jv-text" contenteditable="true" data-type="string">${esc(toSentenceCase(data))}</p>`;
  }

  // ── Array ────────────────────────────────────────────────────────────────
  if (Array.isArray(data)) {
    if (!data.length) return '<span class="jv-null">No items</span>';

    // Array of uniform objects → scrollable multi-column table
    if (isUniformArray(data)) {
      const keys = Object.keys(data[0]);
      const head = keys.map(k => `<th class="jv-th" data-key="${esc(k)}">${toTitleCase(k)}</th>`).join('');
      const body = data.map(row =>
        `<tr>${keys.map(k => {
          const v = row[k];
          if (Array.isArray(v))
            return `<td class="jv-td">${v.map(i => `<span class="jv-tag">${esc(String(i))}</span>`).join('')}</td>`;
          return `<td class="jv-td" contenteditable="true" data-type="${typeof v}">${v === null ? '—' : esc(toSentenceCase(String(v)))}</td>`;
        }).join('')}</tr>`
      ).join('');
      return `<div class="jv-table-wrap"><table class="jv-table"><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></div>`;
    }

    // All-primitive array → proper bullet list
    if (data.every((item: any) => item === null || typeof item !== 'object')) {
      const items = data.map((item: any) =>
        `<li class="jv-li" contenteditable="true" data-type="${typeof item}">${esc(toSentenceCase(String(item ?? '')))}</li>`
      ).join('');
      return `<ul class="jv-ul" data-type="array">${items}</ul>`;
    }

    // Mixed array with objects → stacked cards
    return `<div class="jv-list">${data.map((item: any) => {
      if (typeof item === 'object' && item !== null)
        return `<div class="jv-list-card">${jsonToHtml(item)}</div>`;
      return `<div class="jv-list-card"><span class="jv-li" contenteditable="true">${esc(String(item ?? ''))}</span></div>`;
    }).join('')}</div>`;
  }

  // ── Object ────────────────────────────────────────────────────────────────
  if (typeof data === 'object') {
    // All-primitive object → 2-col key/value table
    if (isKvObject(data)) {
      const rows = Object.entries(data).map(([k, v]) =>
        `<tr>
          <td class="jv-kv-key" data-key="${esc(k)}">${toTitleCase(k)}</td>
          <td class="jv-td jv-kv-val">${renderPrimitive(v)}</td>
        </tr>`
      ).join('');
      return `<div class="jv-table-wrap"><table class="jv-table jv-table-kv"><tbody>${rows}</tbody></table></div>`;
    }

    // Mixed object → labeled section cards (store original key in data-key)
    return `<div class="jv-sections">${Object.entries(data).map(([k, v]) =>
      `<div class="jv-section-card" data-key="${esc(k)}">
        <div class="jv-section-label">${toTitleCase(k)}</div>
        <div class="jv-section-body">${jsonToHtml(v)}</div>
      </div>`
    ).join('')}</div>`;
  }

  return esc(String(data));
}

// ─── HTML → JSON (roundtrip on approve) ──────────────────────────────────────

export function htmlToJson(el: Element): any {
  const cls = el.className?.toString() ?? '';
  const type = el.getAttribute('data-type');

  // Table wrapper → delegate
  if (cls.includes('jv-table-wrap')) {
    const t = el.querySelector('table');
    return t ? htmlToJson(t) : null;
  }

  // Multi-col table → array of objects
  // Uses data-key on <th> to preserve original keys
  if (el.tagName === 'TABLE' && !cls.includes('jv-table-kv')) {
    const keys: string[] = [];
    el.querySelectorAll('thead th').forEach(th => {
      keys.push(th.getAttribute('data-key') ?? th.textContent?.trim() ?? '');
    });
    const rows: any[] = [];
    el.querySelectorAll('tbody tr').forEach(tr => {
      const obj: Record<string, any> = {};
      tr.querySelectorAll('td').forEach((td, i) => {
        if (!keys[i]) return;
        const t = td.getAttribute('data-type');
        const text = td.textContent?.trim() ?? '';
        obj[keys[i]] = t === 'number' ? Number(text) : text === '—' ? null : text;
      });
      rows.push(obj);
    });
    return rows;
  }

  // KV table → object (uses data-key on key cell to preserve original keys)
  if (el.tagName === 'TABLE' && cls.includes('jv-table-kv')) {
    const result: Record<string, any> = {};
    el.querySelectorAll('tbody tr').forEach(tr => {
      const [keyTd, valTd] = Array.from(tr.querySelectorAll('td'));
      if (!keyTd || !valTd) return;
      const key = keyTd.getAttribute('data-key') ?? keyTd.textContent?.trim() ?? '';
      const t = valTd.querySelector('[data-type]')?.getAttribute('data-type');
      const text = valTd.textContent?.trim() ?? '';
      result[key] = t === 'number' ? Number(text) : text === '—' ? null : text;
    });
    return result;
  }

  // Section cards → object (uses data-key on card to preserve original keys)
  if (cls.includes('jv-sections')) {
    const result: Record<string, any> = {};
    el.querySelectorAll(':scope > .jv-section-card').forEach(card => {
      const key = card.getAttribute('data-key') ?? card.querySelector('.jv-section-label')?.textContent?.trim() ?? '';
      const body = card.querySelector('.jv-section-body')?.firstElementChild;
      result[key] = body ? htmlToJson(body) : '';
    });
    return result;
  }

  // Bullet list
  if (el.tagName === 'UL' || cls.includes('jv-ul')) {
    const items: any[] = [];
    el.querySelectorAll(':scope > li').forEach(li => {
      const t = li.getAttribute('data-type');
      const text = li.textContent?.trim() ?? '';
      if (t === 'number') items.push(Number(text));
      else if (t === 'boolean') items.push(text === 'true' || text === 'Yes');
      else items.push(text);
    });
    return items;
  }

  // Mixed object/card list
  if (cls.includes('jv-list')) {
    const items: any[] = [];
    el.querySelectorAll(':scope > .jv-list-card').forEach(card => {
      const child = card.firstElementChild;
      if (child && child.className?.toString().includes('jv-')) items.push(htmlToJson(child));
      else items.push(card.textContent?.trim() ?? '');
    });
    return items;
  }

  if (type === 'number') return Number(el.textContent?.trim());
  if (cls.includes('jv-null')) return null;
  return el.textContent?.trim() ?? '';
}

// ─── Knowledge Base → HTML ────────────────────────────────────────────────────

export function knowledgeBaseToHtml(kb: any): string {
  if (!kb || typeof kb !== 'object') return '<span class="jv-null">—</span>';
  const title = kb.title ?? '';
  const sections = Array.isArray(kb.sections) ? kb.sections : [];

  function renderSubSection(sub: any): string {
    let html = `<div class="kb-sub">`;
    html += `<h3 class="kb-sub-title"><span class="kb-num">${sub.index ?? ''}</span><span class="kb-sub-name" contenteditable="true">${esc(sub.title ?? '')}</span></h3>`;
    if (sub.description) {
      html += `<p class="kb-sub-desc" contenteditable="true">${esc(sub.description)}</p>`;
    }
    if (sub.business_goal) {
      html += `<div class="kb-field" data-field="business_goal"><span class="kb-label">Business Goal:</span><span class="kb-val" contenteditable="true">${esc(sub.business_goal)}</span></div>`;
    }
    if (Array.isArray(sub.legacy_mapping) && sub.legacy_mapping.length) {
      const items = sub.legacy_mapping.map((item: any) => `<li contenteditable="true">${esc(item.value ?? '')}</li>`).join('');
      html += `<div class="kb-field"><span class="kb-label">Legacy Mapping:</span><ul class="kb-list kb-legacy">${items}</ul></div>`;
    }
    if (Array.isArray(sub.required_logic) && sub.required_logic.length) {
      const items = sub.required_logic.map((item: any) => `<li contenteditable="true">${esc(item.value ?? '')}</li>`).join('');
      html += `<div class="kb-field"><span class="kb-label">Required Logic:</span><ul class="kb-list kb-logic">${items}</ul></div>`;
    }
    html += `</div>`;
    return html;
  }

  function renderSection(section: any): string {
    let html = `<div class="kb-section">`;
    html += `<h2 class="kb-section-title"><span class="kb-num">${section.index ?? ''}</span><span class="kb-section-name" contenteditable="true">${esc(section.title ?? '')}</span></h2>`;
    if (section.description) {
      html += `<p class="kb-section-desc" contenteditable="true">${esc(section.description)}</p>`;
    }
    if (Array.isArray(section.sections) && section.sections.length) {
      section.sections.forEach((sub: any) => { html += renderSubSection(sub); });
    }
    html += `</div>`;
    return html;
  }

  let html = `<div class="kb-doc">`;
  html += `<h1 class="kb-doc-title" contenteditable="true">${esc(title)}</h1>`;
  sections.forEach((section: any) => { html += renderSection(section); });
  html += `</div>`;
  return html;
}

// ─── HTML → Knowledge Base JSON ───────────────────────────────────────────────

export function htmlToKnowledgeBase(el: Element): any {
  const kb: any = {};
  kb.title = el.querySelector('.kb-doc-title')?.textContent?.trim() ?? '';
  kb.sections = [];

  el.querySelectorAll(':scope > .kb-section').forEach((sectionEl, si) => {
    const section: any = { index: si + 1 };
    section.title = sectionEl.querySelector('.kb-section-name')?.textContent?.trim() ?? '';
    const descEl = sectionEl.querySelector('.kb-section-desc');
    if (descEl) section.description = descEl.textContent?.trim() ?? '';

    section.sections = [];
    sectionEl.querySelectorAll(':scope > .kb-sub').forEach((subEl, subi) => {
      const sub: any = { index: subi + 1 };
      sub.title = subEl.querySelector('.kb-sub-name')?.textContent?.trim() ?? '';
      const subDescEl = subEl.querySelector('.kb-sub-desc');
      if (subDescEl) sub.description = subDescEl.textContent?.trim() ?? '';

      const bgField = subEl.querySelector('[data-field="business_goal"]');
      if (bgField) sub.business_goal = bgField.querySelector('.kb-val')?.textContent?.trim() ?? '';

      const legacyEl = subEl.querySelector('.kb-legacy');
      if (legacyEl) {
        let idx = 1;
        sub.legacy_mapping = Array.from(legacyEl.querySelectorAll('li')).map(li => ({ index: idx++, value: li.textContent?.trim() ?? '' }));
      }

      const logicEl = subEl.querySelector('.kb-logic');
      if (logicEl) {
        let idx = 1;
        sub.required_logic = Array.from(logicEl.querySelectorAll('li')).map(li => ({ index: idx++, value: li.textContent?.trim() ?? '' }));
      }

      section.sections.push(sub);
    });

    if (!section.sections.length) delete section.sections;
    kb.sections.push(section);
  });

  return kb;
}

// ─── Tool Integration → HTML ──────────────────────────────────────────────────

export function toolIntegrationToHtml(ti: any): string {
  if (!ti || typeof ti !== 'object') return '<span class="jv-null">—</span>';
  const title = ti.title ?? '';
  const description = ti.description ?? '';
  const sections = Array.isArray(ti.sections) ? ti.sections : [];

  let html = `<div class="kb-doc">`;
  html += `<h1 class="kb-doc-title" contenteditable="true">${esc(title)}</h1>`;
  if (description) {
    html += `<p class="ti-desc" contenteditable="true">${esc(description)}</p>`;
  }
  sections.forEach((s: any) => {
    html += `<div class="kb-sub">`;
    html += `<h3 class="kb-sub-title"><span class="kb-num">${s.index ?? ''}</span><span class="kb-sub-name" contenteditable="true">${esc(s.title ?? '')}</span></h3>`;
    if (s.description) {
      html += `<p class="kb-sub-desc" contenteditable="true">${esc(s.description)}</p>`;
    }
    if (s.business_goal) {
      html += `<div class="kb-field" data-field="business_goal"><span class="kb-label">Business Goal:</span><span class="kb-val" contenteditable="true">${esc(s.business_goal)}</span></div>`;
    }
    if (Array.isArray(s.required_logic) && s.required_logic.length) {
      html += `<div class="kb-field" data-field="required_logic"><span class="kb-label">Required Logic:</span><ul class="jv-ul">`;
      s.required_logic.forEach((item: any) => {
        html += `<li class="jv-li" contenteditable="true">${esc(item.value ?? '')}</li>`;
      });
      html += `</ul></div>`;
    }
    html += `</div>`;
  });
  html += `</div>`;
  return html;
}

// ─── Tool Section (single entry) → HTML ───────────────────────────────────────

export function toolSectionToHtml(s: any): string {
  if (!s || typeof s !== 'object') return '<span class="jv-null">—</span>';
  let html = `<div class="kb-doc">`;
  html += `<h1 class="kb-doc-title" contenteditable="true">${esc(s.title ?? '')}</h1>`;
  if (s.description) {
    html += `<p class="kb-sub-desc" contenteditable="true">${esc(s.description)}</p>`;
  }
  if (s.business_goal) {
    html += `<div class="kb-field" data-field="business_goal"><span class="kb-label">Business Goal:</span><span class="kb-val" contenteditable="true">${esc(s.business_goal)}</span></div>`;
  }
  if (Array.isArray(s.legacy_mapping) && s.legacy_mapping.length) {
    html += `<div class="kb-field" data-field="legacy_mapping"><span class="kb-label">Legacy Mapping:</span><ul class="jv-ul">`;
    s.legacy_mapping.forEach((item: any) => {
      html += `<li class="jv-li" contenteditable="true">${esc(item.value ?? '')}</li>`;
    });
    html += `</ul></div>`;
  }
  if (Array.isArray(s.required_logic) && s.required_logic.length) {
    html += `<div class="kb-field" data-field="required_logic"><span class="kb-label">Required Logic:</span><ul class="jv-ul">`;
    s.required_logic.forEach((item: any) => {
      html += `<li class="jv-li" contenteditable="true">${esc(item.value ?? '')}</li>`;
    });
    html += `</ul></div>`;
  }
  html += `</div>`;
  return html;
}

// ─── HTML → Tool Integration JSON ─────────────────────────────────────────────

export function htmlToToolIntegration(el: Element): any {
  const ti: any = {};
  ti.title = el.querySelector('.kb-doc-title')?.textContent?.trim() ?? '';
  const descEl = el.querySelector(':scope > .ti-desc');
  if (descEl) ti.description = descEl.textContent?.trim() ?? '';

  ti.sections = [];
  el.querySelectorAll(':scope > .kb-sub').forEach((subEl, idx) => {
    const s: any = { index: idx + 1 };
    s.title = subEl.querySelector('.kb-sub-name')?.textContent?.trim() ?? '';
    const sdesc = subEl.querySelector('.kb-sub-desc');
    if (sdesc) s.description = sdesc.textContent?.trim() ?? '';
    const bgField = subEl.querySelector('[data-field="business_goal"]');
    if (bgField) s.business_goal = bgField.querySelector('.kb-val')?.textContent?.trim() ?? '';
    ti.sections.push(s);
  });
  return ti;
}

// ─── Artifact icon ────────────────────────────────────────────────────────────

export function artifactIcon(name: string): string {
  const n = name.toLowerCase();
  if (n.includes('overview'))   return '🗺';
  if (n.includes('inventory'))  return '📦';
  if (n.includes('flow'))       return '🔀';
  if (n.includes('agent'))      return '🤖';
  if (n.includes('tool') || n.includes('webhook')) return '🔧';
  if (n.includes('journey') || n.includes('business')) return '🧭';
  if (n.includes('plan') || n.includes('execution'))   return '📋';
  if (n.includes('variable'))   return '📊';
  if (n.includes('decision'))   return '⚡';
  if (n.includes('summary'))    return '📝';
  return '📄';
}
