import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider, type Auth } from 'firebase/auth';

const firebaseConfig = {
  apiKey:     'AIzaSyDiYWifREhi6wBuAzPFGmACbkZNitIRIx0',
  authDomain: 'tgs-int-genai-vertextai-dev-01.firebaseapp.com',
  projectId:  'tgs-int-genai-vertextai-dev-01',
};

const domainHint = (process.env.REACT_APP_ALLOWED_DOMAIN || '').trim().toLowerCase();
const authEnabled = process.env.NODE_ENV !== 'test';

let auth: Auth | null = null;
let googleProvider: GoogleAuthProvider | null = null;

if (authEnabled) {
  const app = initializeApp(firebaseConfig);
  auth = getAuth(app);
  googleProvider = new GoogleAuthProvider();
  googleProvider.setCustomParameters({
    prompt: 'select_account',
    ...(domainHint ? { hd: domainHint } : {}),
  });
}

export { auth, authEnabled, domainHint, googleProvider };
