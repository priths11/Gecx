import { getStoredGoogleCredential } from '../googleAuth';

// ─── Endpoints ────────────────────────────────────────────────────────────────

// Routed through the same-origin /internal/proxy (server.py) to avoid cross-origin CORS preflight failures.
// `target` selects the whitelisted upstream base configured server-side (REMOTE_TARGETS in server.py).
const CONFIG_API_PATH = '/api/v1';
const DFCX_API_PATH = '/api/v1';

// ─── Helpers ──────────────────────────────────────────────────────────────────

let cachedServiceToken: string | null = null;
let tokenExpiresAt = 0;
let pendingTokenPromise: Promise<string> | null = null;

export async function fetchGcpServiceToken(audience?: string): Promise<string> {
  const now = Date.now();
  if (cachedServiceToken && now < tokenExpiresAt - 60000) {
    return cachedServiceToken;
  }

  if (pendingTokenPromise) {
    return pendingTokenPromise;
  }

  pendingTokenPromise = (async () => {
    try {
      const cleanAudience = audience && audience.includes('://')
        ? audience.split('/').slice(0, 3).join('/')
        : audience;

      const query = cleanAudience ? `?audience=${encodeURIComponent(cleanAudience)}` : '';
      const urls = [
        `http://localhost:8080/api/token${query}`,
        `/api/token${query}`
      ];

      for (const tokenUrl of urls) {
        try {
          const res = await fetch(tokenUrl);
          const contentType = res.headers.get('content-type') || '';
          if (res.ok && contentType.includes('application/json')) {
            const data = await res.json();
            if (data.token) {
              cachedServiceToken = data.token;
              tokenExpiresAt = now + 50 * 60 * 1000;
              return data.token;
            }
          }
        } catch {
          // try next url
        }
      }
    } finally {
      pendingTokenPromise = null;
    }
    return '';
  })();

  return pendingTokenPromise;
}

export async function getAuthHeaders(extraHeaders: Record<string, string> = {}, audience?: string): Promise<Record<string, string>> {
  const headers: Record<string, string> = { ...extraHeaders };
  const token = (await fetchGcpServiceToken(audience)) || getStoredGoogleCredential();

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  return headers;
}

export async function proxyFetch(path: string, init: RequestInit = {}, target: 'config' | 'migrator' | 'dfcx' | 'reporting' | 'agent_builder' = 'config'): Promise<Response> {
  return fetch(`/internal/proxy?path=${encodeURIComponent(path)}&target=${target}`, init);
}

async function handleResponse(res: Response) {
  const isJson = res.headers.get('content-type')?.includes('application/json');
  const body = isJson ? await res.json() : await res.text();
  if (!res.ok) {
    const msg = typeof body === 'string' ? body : body?.message || body?.error || `Request failed (${res.status})`;
    throw new Error(msg);
  }
  return body;
}

// ─── API 1: Upload files ───────────────────────────────────────────────────────

export async function uploadFiles(zipFiles: File[], visualDocFiles: File[], userEmail: string) {
  const formData = new FormData();
  formData.append('user_email', userEmail);
  zipFiles.forEach(f => formData.append('cx_zip', f, f.name));
  visualDocFiles.forEach(f => formData.append('visual_doc', f, f.name));
  if (!visualDocFiles.length) formData.append('visual_doc', '');

  const res = await proxyFetch('/upload-files', {
    method: 'POST',
    headers: { accept: 'application/json' },
    body: formData,
  }, 'migrator');
  return handleResponse(res);
}

// ─── API 2: Run migration ─────────────────────────────────────────────────────

export async function runMigration(jobId: string, userEmail: string) {
  const res = await proxyFetch('/run-migration', {
    method: 'POST',
    headers: { accept: 'application/json', 'content-type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ job_id: jobId, user_email: userEmail }),
  }, 'migrator');
  return handleResponse(res);
}

// ─── API 3: Save approved summary ────────────────────────────────────────────

export interface SaveSummaryPayload {
  job_id?: number;
  status_code?: number;
  output_dir?: string;
  output_files?: string[];
  data: string; // JSON.stringify of edited data
}

export async function saveApprovedSummary(payload: SaveSummaryPayload) {
  const res = await proxyFetch('/save-approved-summary', {
    method: 'POST',
    headers: { accept: 'application/json', 'content-type': 'application/json' },
    body: JSON.stringify(payload),
  }, 'migrator');
  return handleResponse(res);
}

// ─── API 4: Generate CX summary ──────────────────────────────────────────────

export async function generateCxSummary(id: number, userEmail: string) {
  const res = await proxyFetch(`${DFCX_API_PATH}/generate_cx_summary`, {
    method: 'POST',
    headers: { accept: 'application/json', 'content-type': 'application/json' },
    body: JSON.stringify({ id, user_email: userEmail }),
  }, 'dfcx');
  return handleResponse(res);
}

// ─── API 5: Approve CX summary (Sync to GCS) ─────────────────────────────────

export async function approveCxSummary(id: number, approvedOutput2: any, userEmail: string) {
  const res = await proxyFetch(`${DFCX_API_PATH}/approve_cx_summary`, {
    method: 'POST',
    headers: { accept: 'application/json', 'content-type': 'application/json' },
    body: JSON.stringify({ id, approved_output2: approvedOutput2, user_email: userEmail }),
  }, 'dfcx');
  return handleResponse(res);
}

// ─── API 6: Check validity ───────────────────────────────────────────────────

export async function checkValidity(email: string) {
  const res = await proxyFetch(`${CONFIG_API_PATH}/check_validity`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ official_email: email }),
  });
  return handleResponse(res);
}

// ─── API 7: Register User ────────────────────────────────────────────────────

export async function registerUser(payload: any) {
  const res = await proxyFetch(`${CONFIG_API_PATH}/register_user`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  return handleResponse(res);
}

// ─── API 8: Save Config ──────────────────────────────────────────────────────

export async function saveConfig(payload: any) {
  const res = await proxyFetch(`${CONFIG_API_PATH}/config`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  return handleResponse(res);
}

// ─── API 9: Get Config ───────────────────────────────────────────────────────

export async function getConfig(email: string) {
  const path = `${CONFIG_API_PATH}/get_config?user_email=${encodeURIComponent(email)}`;
  const res = await proxyFetch(path, {
    method: 'GET',
    headers: { 'Accept': 'application/json' },
  });
  return handleResponse(res);
}

export { CONFIG_API_PATH };
// ─── API 10: Get SSO Setup URL ──────────────────────────────────────────────

export async function getSsoSetupUrl(
  payload: {
    login_type: string;
    app_id?: string;
    app_secret?: string;
    provider?: string;
    name?: string;
    provider_id?: string;
    client_id?: string;
    issuer_url?: string;
    client_secret?: string;
    entity_id?: string;
    sso_url?: string;
    certificate?: string;
    sp_entity_id?: string;
  }
) {
  const res = await proxyFetch(`${CONFIG_API_PATH}/sso_setup_url`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  return handleResponse(res);
}

// ─── API 11: Configure Google IDP ──────────────────────────────────────────

export async function configureGoogleIdp(
  payload: { login_type: string; client_id: string; client_secret: string; provider: string }
) {
  const res = await proxyFetch('/idp', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ ...payload, project_id: 'tgs-int-genai-vertextai-dev-01' }),
  }, 'migrator');
  return handleResponse(res);
}

// ─── API 12: Configure SSO IDP ──────────────────────────────────────────────

export async function configureSSOIdp(
  payload: { login_type: string; client_id: string; client_secret: string; provider: string }
) {
  const res = await proxyFetch('/idp', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ ...payload, project_id: 'tgs-int-genai-vertextai-dev-01' }),
  }, 'migrator');
  return handleResponse(res);
}

// ─── API 13: Get Job Report ──────────────────────────────────────────────

export interface JobReportItem {
  id: number;
  project_name: string;
  app_name: string;
  bucket_id: string;
  upload_date: string;
  conversation_status: string;
}

export interface JobReportData {
  project_name: string;
  customer_project_id: string;
  project_list: JobReportItem[];
  customer_dataset: string;
  report: {
    id: number;
    project_name: string;
    job_status: string;
    created_date: string;
    modified_date: string;
    username: string;
    user_email: string;
    input_filepaths?: string[];
    input_zip_name?: string;
    input_file_count?: number;
    dfcx_summary_output1_original?: string;
    dfcx_summary_output1_final?: string;
    cx_summary_output2_original?: string;
    cx_summary_output2_final?: string;
    upload_processing_start_time?: string;
    upload_processing_end_time?: string;
    upload_processing_status?: string;
    upload_processing_error?: string;
    upload_processing_duration_sec?: number;
    output1_generation_start_time?: string;
    output1_generation_end_time?: string;
    output1_generation_status?: string;
    output1_generation_error?: string;
    output1_generation_duration_sec?: number;
    output2_generation_start_time?: string;
    output2_generation_end_time?: string;
    output2_generation_status?: string;
    output2_generation_error?: string | null;
    output2_generation_duration_sec?: number;
    agent_build_start_time?: string;
    agent_build_end_time?: string | null;
    agent_build_status?: string;
    agent_build_error?: string | null;
    agent_build_duration_sec?: number;
    no_of_flows?: number;
    no_of_intents?: number;
    no_of_pages?: number;
    no_of_playbooks?: number;
    no_of_test_cases?: number;
    no_of_entities?: number;
    flow_grouping_map_json?: string;
    lineage_map_json?: string | null;
    orphan_flow_count?: number | null;
    mapped_flow_count?: number | null;
    flow_coverage_percent?: number | null;
    orphan_page_count?: number | null;
    mapped_page_count?: number | null;
    page_coverage_percent?: number | null;
    planned_playbook_count?: number | null;
    generated_playbook_count?: number | null;
    mapped_playbook_count?: number | null;
    playbook_coverage_percent?: number | null;
    overall_coverage_percent?: number | null;
    capabilities?: string[];
    output1_token_usage?: number;
    output2_token_usage?: number;
    agent_build_token_usage?: number;
    output1_generation_confidence?: number;
    output2_generation_confidence?: number;
    agent_build_confidence?: number;
    app_name?: string;
    customer_project_id?: string;
    customer_bucket?: string;
    output1_model_name?: string;
    output2_model_name?: string;
    agent_builder_model_name?: string;
    lineage?: any;
    [key: string]: any;
  };
}

export interface JobReportResponse {
  status: string;
  message: string;
  data: JobReportData;
}

export const FALLBACK_JOB_REPORT: JobReportResponse = {
  status: 'success',
  message: 'Job report fetched successfully.',
  data: {
    project_name: 'soutstar-20Aug-as',
    customer_project_id: 'tgs-int-genai-vertextai-dev-01',
    project_list: [
      {
        id: 71175286,
        project_name: 'soutstar-20Aug-as',
        app_name: 'myagentas',
        bucket_id: 'cx-migration-southstar-sa-20aug',
        upload_date: '2026-08-31T10:12:55.484944+00:00',
        conversation_status: 'AGENT_BUILDING',
      },
      {
        id: 69862543,
        project_name: 'soutstar-20Aug-as',
        app_name: 'soutstar-20Aug-as',
        bucket_id: 'cx-migration-southstar-sa-20aug',
        upload_date: '2026-08-31T09:51:02.778961+00:00',
        conversation_status: 'UPLOAD_success',
      },
      {
        id: 68203508,
        project_name: 'soutstar-20Aug-as',
        app_name: 'soutstar-20Aug-as',
        bucket_id: 'cx-migration-southstar-sa-20aug',
        upload_date: '2026-08-25T14:30:03.818921+00:00',
        conversation_status: 'UPLOAD_success',
      },
      {
        id: 98892557,
        project_name: 'soutstar-20Aug-as',
        app_name: 'soutstar-20Aug-as',
        bucket_id: 'cx-migration-southstar-sa-20aug',
        upload_date: '2026-08-21T07:54:52.808635+00:00',
        conversation_status: 'UPLOAD_success',
      },
      {
        id: 37900977,
        project_name: 'soutstar-20Aug-as',
        app_name: 'mynewagent',
        bucket_id: 'cx-migration-southstar-sa-20aug',
        upload_date: '2026-08-20T14:58:21.194512+00:00',
        conversation_status: 'AGENT_BUILDING',
      },
    ],
    customer_dataset: 'southstar_migration_as',
    report: {
      id: 37900977,
      project_name: 'soutstar-20Aug-as',
      job_status: 'AGENT_BUILDING',
      created_date: '2026-08-20T14:58:21.194775+00:00',
      modified_date: '2026-08-20T15:09:53.455097+00:00',
      username: 'aarakkal@teksystems.com',
      user_email: 'aarakkal@teksystems.com',
      input_filepaths: [
        'gs://cx-migration-southstar-sa-20aug/14122034_20082026_SOUTSTAR-20AUG-AS/37900977/ingestion/A110029_240326_southstar.zip',
      ],
      input_zip_name: 'A110029_240326_southstar.zip',
      input_file_count: 1,
      dfcx_summary_output1_original: 'gs://cx-migration-southstar-sa-20aug/14122034_20082026_SOUTSTAR-20AUG-AS/37900977/output1/soutstar-20Aug-as_DFCX_SUMMARY_ORIGINAL.json',
      dfcx_summary_output1_final: 'gs://cx-migration-southstar-sa-20aug/14122034_20082026_SOUTSTAR-20AUG-AS/37900977/output1/soutstar-20Aug-as_DFCX_SUMMARY_APPROVED.json',
      cx_summary_output2_original: 'gs://cx-migration-southstar-sa-20aug/14122034_20082026_SOUTSTAR-20AUG-AS/37900977/output2/SOUTHSTAR_GECX_SUMMARY_ORIGINAL.json',
      cx_summary_output2_final: '',
      upload_processing_start_time: '2026-08-20T14:58:12.567635+00:00',
      upload_processing_end_time: '2026-08-20T14:58:21.194512+00:00',
      upload_processing_status: 'SUCCESS',
      upload_processing_error: '',
      upload_processing_duration_sec: 8,
      output1_generation_start_time: '2026-08-20T15:03:38.500913+00:00',
      output1_generation_end_time: '2026-08-20T15:04:41.960367+00:00',
      output1_generation_status: 'SUCCESS',
      output1_generation_error: '',
      output1_generation_duration_sec: 63,
      output2_generation_start_time: '2026-08-20T15:07:30.718116+00:00',
      output2_generation_end_time: '2026-08-20T15:08:12.708181+00:00',
      output2_generation_status: 'SUCCESS',
      output2_generation_error: null,
      output2_generation_duration_sec: 41,
      agent_build_start_time: '2026-08-20T15:09:47.523035+00:00',
      agent_build_end_time: null,
      agent_build_status: 'IN_PROGRESS',
      agent_build_error: null,
      agent_build_duration_sec: 0,
      no_of_flows: 2,
      no_of_intents: 12,
      no_of_pages: 9,
      no_of_playbooks: 1,
      no_of_test_cases: 0,
      no_of_entities: 0,
      flow_grouping_map_json: '[{"cluster_name": "General Service", "flow_ids": ["Default Start Flow", "ExistingUser"]}]',
      lineage_map_json: null,
      orphan_flow_count: null,
      mapped_flow_count: null,
      flow_coverage_percent: null,
      orphan_page_count: null,
      mapped_page_count: null,
      page_coverage_percent: null,
      planned_playbook_count: null,
      generated_playbook_count: null,
      mapped_playbook_count: null,
      playbook_coverage_percent: null,
      overall_coverage_percent: null,
      capabilities: ['General Service'],
      output1_token_usage: 19608,
      output2_token_usage: 10275,
      agent_build_token_usage: 0,
      output1_generation_confidence: 0.0,
      output2_generation_confidence: 1.0,
      agent_build_confidence: 0.0,
      app_name: 'mynewagent',
      customer_project_id: 'tgs-int-genai-vertextai-dev-01',
      customer_bucket: 'cx-migration-southstar-sa-20aug',
      output1_model_name: 'gemini-2.5-flash',
      output2_model_name: 'gemini-2.5-pro',
      agent_builder_model_name: 'gemini-2.5-pro',
      lineage: {
        source_agent: 'soutstar-20Aug-as',
        lineage_version: '1.0',
        coverage: {
          flows: {
            total: 2,
            active: 2,
            orphan: 0,
            mapped: 2,
            coverage_percent: 100.0,
          },
          pages: {
            total: 9,
            active: 9,
            orphan: 0,
            mapped: null,
            coverage_percent: null,
          },
          playbooks: {
            total: 1,
            mapped: 1,
            generated: 1,
            coverage_percent: 100.0,
          },
          overall_coverage_percent: 100.0,
        },
        capabilities: [
          {
            capability_name: 'General Service',
            mapping_reason: 'Mapped from output1 flow grouping.',
            source_flow_clusters: [
              {
                cluster_name: 'General Service',
                business_goal: null,
                source_flows: [
                  {
                    flow_id: 'Default Start Flow',
                    flow_display_name: 'Default Start Flow',
                  },
                  {
                    flow_id: 'ExistingUser',
                    flow_display_name: 'ExistingUser',
                  },
                ],
              },
            ],
          },
        ],
      },
    },
  },
};

export async function getJobReport(jobId: number | string, userEmail: string): Promise<JobReportResponse> {
  const res = await proxyFetch('/api/v1/get_job_report', {
    method: 'POST',
    headers: {
      accept: 'application/json',
      'content-type': 'application/json',
    },
    body: JSON.stringify({
      user_email: userEmail || 'aarakkal@teksystems.com',
      job_id: Number(jobId) || 37900977,
    }),
  }, 'reporting');
  return handleResponse(res);
}


