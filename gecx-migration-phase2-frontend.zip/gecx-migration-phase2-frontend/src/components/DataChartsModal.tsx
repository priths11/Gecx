import React, { useMemo, useEffect } from 'react';
import {
  ReactFlow,
  useNodesState,
  useEdgesState,
  Controls,
  Background,
  Panel,
  Node,
  Edge,
  MarkerType,
  Position
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';
import dagre from 'dagre';
import './css/DataChartsModal.css';

// ─── Types ────────────────────────────────────────────────────────────────────
interface Artifact { name: string; type: string; apiKey: string; content: any; }

interface DataChartsModalProps {
  isOpen: boolean;
  onClose: () => void;
  artifacts?: Artifact[];
  gecxData?: any;
}

const normalizeArtifactKey = (value: string) => value.toLowerCase().replace(/[\s_]+/g, '_');

// ─── Dagre Auto-Layout ────────────────────────────────────────────────────────

const dagreGraph = new dagre.graphlib.Graph();
dagreGraph.setDefaultEdgeLabel(() => ({}));

const nodeWidth = 250;
const nodeHeight = 60;

const getLayoutedElements = (nodes: Node[], edges: Edge[], direction = 'TB') => {
  dagreGraph.setGraph({ rankdir: direction, ranksep: 50, nodesep: 15 });

  const dagreNodes = nodes.filter(n => (n.data as any)?.details?.type !== 'Page');
  const pageNodes = nodes.filter(n => (n.data as any)?.details?.type === 'Page');
  
  const pageNodeIds = new Set(pageNodes.map(n => n.id));
  const dagreEdges = edges.filter(e => !pageNodeIds.has(e.target));
  const pageEdges = edges.filter(e => pageNodeIds.has(e.target));

  dagreNodes.forEach((node) => {
    const isFlowPage = (node.data as any)?.details?.type === 'Flow_Page';
    const w = isFlowPage ? 120 : 200;
    const h = isFlowPage ? 35 : 50;
    dagreGraph.setNode(node.id, { width: w, height: h });
  });

  dagreEdges.forEach((edge) => {
    dagreGraph.setEdge(edge.source, edge.target);
  });

  dagre.layout(dagreGraph);

  const newNodes = nodes.map((node) => {
    if ((node.data as any)?.details?.type !== 'Page') {
      const nodeWithPosition = dagreGraph.node(node.id);
      const isFlowPage = (node.data as any)?.details?.type === 'Flow_Page';
      const w = isFlowPage ? 120 : 200;
      const h = isFlowPage ? 35 : 50;
      node.position = {
        x: nodeWithPosition.x - w / 2,
        y: nodeWithPosition.y - h / 2,
      };
    }
    return node;
  });

  // Manually stack Page nodes vertically beneath their corresponding Flow parents
  const flowToPagesMap: Record<string, Node[]> = {};
  pageEdges.forEach(e => {
    if (!flowToPagesMap[e.source]) flowToPagesMap[e.source] = [];
    const targetNode = newNodes.find(n => n.id === e.target);
    if (targetNode) flowToPagesMap[e.source].push(targetNode);
  });

  Object.entries(flowToPagesMap).forEach(([flowId, pNodes]) => {
    const parentNode = newNodes.find(n => n.id === flowId);
    if (!parentNode) return;

    let startY = parentNode.position.y + nodeHeight + 50; 
    pNodes.forEach(pNode => {
      // Center the page node vertically aligned to the parent
      // Page nodes are smaller (min-width 140) but we align their top-left anchors mathematically
      // Notice: dagre puts X at center, so we copy parent X directly if they are same width, or adjust for width
      pNode.position = {
        x: parentNode.position.x + (nodeWidth / 2) - 85, // 85 is half of approx page width (170)
        y: startY
      };
      startY += nodeHeight + 20; 
    });
  });

  return { nodes: newNodes, edges };
};

// ─── Component ────────────────────────────────────────────────────────────────

export default function DataChartsModal({ isOpen, onClose, artifacts, gecxData }: DataChartsModalProps) {
  const [nodes, setNodes, onNodesChange] = useNodesState([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);
  const [selectedNodeData, setSelectedNodeData] = React.useState<any>(null);

  // Generate nodes and edges from artifacts
  const graphData = useMemo(() => {
    const newNodes: Node[] = [];
    const newEdges: Edge[] = [];

    if (!isOpen) return { nodes: [], edges: [] };

    if (gecxData) {
      // ---- OUTPUT 2 GECX ENGINE ----
      const rootId = 'gecx-root';
      newNodes.push({
        id: rootId,
        position: { x: 0, y: 0 },
        sourcePosition: Position.Bottom,
        targetPosition: Position.Top,
        data: { 
          label: 'GECX Agent Configuration',
          details: { type: 'GECX Root', summary: 'Final multi-agent parameters' }
        },
        type: 'default',
        className: 'mindmap-node root-node'
      });

      // Child 1: Goal
      if (gecxData.goal && Object.keys(gecxData.goal).length > 0) {
        newNodes.push({
          id: 'goal', position: { x: 0, y: 0 }, sourcePosition: Position.Bottom, targetPosition: Position.Top,
          data: { label: 'Agent Goal', details: { type: 'Goal', summary: JSON.stringify(gecxData.goal) } },
          type: 'default', className: 'mindmap-node cluster-node'
        });
        newEdges.push({ id: 'e-root-goal', source: rootId, target: 'goal', type: 'step', style: { stroke: '#94a3b8', strokeWidth: 2 } });
      }

      // Child 2: System Instructions
      if (gecxData.knowledge_base?.sections?.length) {
        newNodes.push({
          id: 'sys-instr', position: { x: 0, y: 0 }, sourcePosition: Position.Bottom, targetPosition: Position.Top,
          data: { label: 'System Instructions', details: { type: 'Category', summary: 'Knowledge base configurations' } },
          type: 'default', className: 'mindmap-node cluster-node'
        });
        newEdges.push({ id: 'e-root-sys', source: rootId, target: 'sys-instr', type: 'step', style: { stroke: '#94a3b8', strokeWidth: 2 } });

        gecxData.knowledge_base.sections.forEach((sec: any) => {
          const secId = `sys-sec-${sec.index}`;
          newNodes.push({
            id: secId, position: { x: 0, y: 0 }, sourcePosition: Position.Bottom, targetPosition: Position.Top,
            data: { label: sec.title || `Section ${sec.index}`, details: { type: 'Section', summary: sec.description || '' } },
            type: 'default', className: 'mindmap-node flow-node'
          });
          newEdges.push({ id: `e-sys-${secId}`, source: 'sys-instr', target: secId, type: 'step', style: { stroke: '#cbd5e1', strokeWidth: 1.5 } });

          (sec.sections || []).forEach((sub: any) => {
            const subId = `sys-sub-${sub.index}`;
            newNodes.push({
              id: subId, position: { x: 0, y: 0 }, sourcePosition: Position.Bottom, targetPosition: Position.Top,
              data: { 
                label: sub.title || `Sub-section ${sub.index}`, 
                details: { 
                  type: 'Page', // Forces dashed styling and tight vertical branch layout
                  businessGoal: sub.business_goal, 
                  legacyMapping: sub.legacy_mapping?.map((l:any)=>l.value).join(', '), 
                  requiredLogic: sub.required_logic?.map((l:any)=>l.value).join(', ') 
                } 
              },
              type: 'default', className: 'mindmap-node page-node'
            });
            newEdges.push({ id: `e-${secId}-${subId}`, source: secId, target: subId, type: 'step', style: { stroke: '#94a3b8', strokeWidth: 1.5, strokeDasharray: '4 4' } });
          });
        });
      }

      // Child 3: Tools Integration
      if (gecxData.tool_integration?.sections?.length) {
        newNodes.push({
          id: 'tools', position: { x: 0, y: 0 }, sourcePosition: Position.Bottom, targetPosition: Position.Top,
          data: { label: 'Tools Integration', details: { type: 'Category', summary: gecxData.tool_integration.description || '' } },
          type: 'default', className: 'mindmap-node cluster-node'
        });
        newEdges.push({ id: 'e-root-tools', source: rootId, target: 'tools', type: 'step', style: { stroke: '#94a3b8', strokeWidth: 2 } });

        gecxData.tool_integration.sections.forEach((tool: any) => {
          const toolId = `tool-${tool.index}`;
          newNodes.push({
            id: toolId, position: { x: 0, y: 0 }, sourcePosition: Position.Bottom, targetPosition: Position.Top,
            data: { 
              label: tool.title || `Tool ${tool.index}`, 
              details: { 
                 type: 'Flow', 
                 summary: tool.description || '', 
                 businessGoal: tool.business_goal, 
                 requiredLogic: tool.required_logic?.map((l:any)=>l.value).join(', ') 
              } 
            },
            type: 'default', className: 'mindmap-node flow-node'
          });
          newEdges.push({ id: `e-tools-${toolId}`, source: 'tools', target: toolId, type: 'step', style: { stroke: '#cbd5e1', strokeWidth: 1.5 } });
        });
      }
    } else if (artifacts) {
      // ---- OUTPUT 1 FLOW ENGINE ----
      // 1. Root Node (Agent Title)
      const sourceAgentArtifact = artifacts.find(a => normalizeArtifactKey(a.apiKey) === 'source_agent');
      const titleArtifact = artifacts.find(a => normalizeArtifactKey(a.apiKey) === 'title');
      const overviewArtifact = artifacts.find(a => normalizeArtifactKey(a.apiKey) === 'overview');
      const rootLabel = sourceAgentArtifact?.content ? String(sourceAgentArtifact.content) : (titleArtifact?.content ? String(titleArtifact.content) : 'Agent');
      
      const rootId = 'root';
      newNodes.push({
        id: rootId,
        position: { x: 0, y: 0 },
        sourcePosition: Position.Bottom,
        targetPosition: Position.Top,
        data: { 
          label: rootLabel,
          details: {
            type: 'Agent',
            summary: overviewArtifact?.content ? String(overviewArtifact.content) : 'No overview available.'
          }
        },
        type: 'default',
        className: 'mindmap-node root-node'
      });

      // 2. Hierarchy Map (flow_page_hierarchy)
      const hierarchyArtifact = artifacts.find(a => normalizeArtifactKey(a.apiKey) === 'flow_page_hierarchy');
      const hierarchy = hierarchyArtifact?.content;

      if (hierarchy && Array.isArray(hierarchy.flows)) {
        hierarchy.flows.forEach((flow: any) => {
          const flowId = `flow-${flow.flow_id}`;
          
          newNodes.push({
            id: flowId,
            position: { x: 0, y: 0 },
            sourcePosition: Position.Bottom,
            targetPosition: Position.Top,
            data: { 
              label: flow.flow_name,
              details: {
                type: 'Flow',
                status: flow.status,
                summary: `Contains ${flow.pages?.length || 0} pages`
              }
            },
            type: 'default',
            className: `mindmap-node flow-node${flow.status === 'inactive' ? ' inactive-flow' : ''}`
          });
          
          // Connect to parent flows or root
          if (flow.parent_flow_ids && flow.parent_flow_ids.length > 0) {
            flow.parent_flow_ids.forEach((pId: string) => {
              const parentId = `flow-${pId}`;
              newEdges.push({
                id: `e-${parentId}-${flowId}`,
                source: parentId,
                target: flowId,
                type: 'step',
                style: { stroke: '#cbd5e1', strokeWidth: 1.5 },
              });
            });
          } else {
            // No parent flow, connect to root node
            newEdges.push({
              id: `e-${rootId}-${flowId}`,
              source: rootId,
              target: flowId,
              type: 'step',
              animated: true,
              style: { stroke: '#94a3b8', strokeWidth: 2 },
              markerEnd: { type: MarkerType.ArrowClosed, color: '#94a3b8' }
            });
          }

          // Generate child pages
          if (Array.isArray(flow.pages)) {
            flow.pages.forEach((page: any) => {
              const pageId = `page-${flow.flow_id}-${page.page_id}`;
              
              newNodes.push({
                id: pageId,
                position: { x: 0, y: 0 },
                sourcePosition: Position.Bottom,
                targetPosition: Position.Top,
                data: {
                  label: page.page_name,
                  details: {
                    type: 'Flow_Page', // We use Flow_Page so Dagre doesn't skip it like it does for 'Page' in GECX mode
                    status: page.status,
                    summary: `Page in ${flow.flow_name}`
                  }
                },
                type: 'default',
                className: `mindmap-node page-node${page.status === 'inactive' ? ' inactive-page' : ''}`
              });

              // Connect to parent pages or flow
              if (page.parent_page_ids && page.parent_page_ids.length > 0) {
                page.parent_page_ids.forEach((pId: string) => {
                  const parentId = `page-${flow.flow_id}-${pId}`;
                  newEdges.push({
                    id: `e-${parentId}-${pageId}`,
                    source: parentId,
                    target: pageId,
                    type: 'step',
                    style: { stroke: '#94a3b8', strokeWidth: 1.5, strokeDasharray: '4 4' },
                  });
                });
              } else {
                newEdges.push({
                  id: `e-${flowId}-${pageId}`,
                  source: flowId,
                  target: pageId,
                  type: 'step',
                  style: { stroke: '#cbd5e1', strokeWidth: 1.5 },
                });
              }
            });
          }
        });
      }

      if (newNodes.length === 1) {
        newNodes[0].data.label = 'No hierarchy data available to map';
      }
    }

    // Apply layout algorithm
    return getLayoutedElements(newNodes, newEdges, 'TB');
  }, [artifacts, gecxData, isOpen]);

  // Hook layouted data into React Flow state
  useEffect(() => {
    if (isOpen) {
      setNodes(graphData.nodes);
      setEdges(graphData.edges);
      setSelectedNodeData(null);
    }
  }, [graphData, isOpen, setNodes, setEdges]);

  const onNodeClick = React.useCallback((event: React.MouseEvent, node: Node) => {
    if (node.data && node.data.details) {
      setSelectedNodeData({ label: node.data.label, ...node.data.details as any });
    } else {
      setSelectedNodeData(null);
    }
  }, []);

  if (!isOpen) return null;

  return (
    <div className="chart-modal-overlay chart-modal-overlay" onClick={onClose}>
      <div className="chart-modal-content" onClick={e => e.stopPropagation()}>
        
        <div className="chart-modal-header">
          <h2>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 20a8 8 0 1 0 0-16 8 8 0 0 0 0 16Z"/>
              <circle cx="12" cy="12" r="3"/>
              <path d="M3 12h5"/><path d="M16 12h5"/><path d="M12 3v5"/><path d="M12 16v5"/>
            </svg>
            Flow Architect Mind Map
          </h2>
          <button className="chart-modal-close" onClick={onClose} aria-label="Close">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <line x1="18" y1="6" x2="6" y2="18" />
              <line x1="6" y1="6" x2="18" y2="18" />
            </svg>
          </button>
        </div>
        
        <div className="react-flow-container">
          <ReactFlow
            nodes={nodes}
            edges={edges}
            onNodesChange={onNodesChange}
            onEdgesChange={onEdgesChange}
            onNodeClick={onNodeClick}
            fitView
            minZoom={0.2}
            maxZoom={2}
            nodesDraggable={true}
            elementsSelectable={true}
            colorMode="light"
          >
            <Background color="#cbd5e1" gap={20} size={1} />
            <Controls showInteractive={false} />
            <Panel position="bottom-right" className="mindmap-legend">
              Drag to pan • Scroll to zoom • Click nodes for details
            </Panel>
          </ReactFlow>

          {selectedNodeData && (
            <div className={`mindmap-details-panel ${selectedNodeData ? 'open' : ''}`}>
              <div className="mindmap-details-header">
                <h3>{selectedNodeData.label}</h3>
                <span className="mindmap-details-badge">{selectedNodeData.type}</span>
                <button className="mindmap-details-close" onClick={() => setSelectedNodeData(null)}>
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <line x1="18" y1="6" x2="6" y2="18" />
                    <line x1="6" y1="6" x2="18" y2="18" />
                  </svg>
                </button>
              </div>
              <div className="mindmap-details-body">
                {selectedNodeData.pageType && (
                  <div className="mindmap-details-section">
                    <h4>Page Type</h4>
                    <p>{selectedNodeData.pageType}</p>
                  </div>
                )}
                {selectedNodeData.status && (
                  <div className="mindmap-details-section">
                    <h4>Status</h4>
                    <p style={{ textTransform: 'capitalize' }}>{selectedNodeData.status}</p>
                  </div>
                )}
                {selectedNodeData.summary && (
                  <div className="mindmap-details-section">
                    <h4>Overview</h4>
                    <p>{selectedNodeData.summary}</p>
                  </div>
                )}
                {selectedNodeData.businessGoal && (
                  <div className="mindmap-details-section">
                    <h4>Business Goal</h4>
                    <p>{selectedNodeData.businessGoal}</p>
                  </div>
                )}
                {selectedNodeData.instructionSummary && (
                  <div className="mindmap-details-section">
                    <h4>Instruction Summary</h4>
                    <p>{selectedNodeData.instructionSummary}</p>
                  </div>
                )}
                {selectedNodeData.toolingExpectations && (
                  <div className="mindmap-details-section">
                    <h4>Tooling Expectations</h4>
                    <p>{selectedNodeData.toolingExpectations}</p>
                  </div>
                )}
                {selectedNodeData.legacyMapping && (
                  <div className="mindmap-details-section">
                    <h4>Legacy Mapping</h4>
                    <p>{selectedNodeData.legacyMapping}</p>
                  </div>
                )}
                {selectedNodeData.requiredLogic && (
                  <div className="mindmap-details-section">
                    <h4>Required Logic</h4>
                    <p>{selectedNodeData.requiredLogic}</p>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

      </div>
    </div>
  );
}
