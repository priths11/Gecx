import type { DiscoveredProject, SyncedProject } from '../workflowTypes';
import './css/IngestionPage.css';

// ─── Sub-components ────────────────────────────────────────────────────────────

function GcsPathCell({ path }: { path: string | null }) {
  if (!path) return <span className="ingest-pending">Will be generated on sync</span>;
  return <code className="ingest-mono ingest-mono--path">{path}</code>;
}

function JobIdCell({ jobId }: { jobId: string | null }) {
  if (!jobId) return <span className="ingest-pending">Pending…</span>;
  return <span className="ingest-job-id">{jobId}</span>;
}

/** Build a merged view: start from locked (selected) projects;
 *  overlay real sync data when available. */
interface RowData {
  name: string;
  jobId: string | null;
  gcsPath: string | null;
  bqSink: string | null;
  synced: boolean;
}

function buildRows(
  lockedProjects: DiscoveredProject[],
  syncedProjects: SyncedProject[]
): RowData[] {
  const syncMap = new Map(syncedProjects.map((p) => [p.name, p]));
  return lockedProjects.map((p) => {
    const synced = syncMap.get(p.name);
    if (synced) {
      return {
        name: p.name,
        jobId: synced.jobId,
        gcsPath: synced.gcsPath,
        bqSink: synced.bqSink,
        synced: true,
      };
    }
    return { name: p.name, jobId: null, gcsPath: null, bqSink: null, synced: false };
  });
}

// ─── Main Component ────────────────────────────────────────────────────────────

interface IngestionPageProps {
  bucketName: string;
  /** Projects the user selected and locked in Step 1. Always present. */
  lockedProjects: DiscoveredProject[];
  /** Projects that have been uploaded and have real job IDs. */
  syncedProjects: SyncedProject[];
  isSyncing: boolean;
  isRunningMigration: boolean;
  onSyncBatch: () => void;
  onBack: () => void;
  onInitiateDiscovery: () => void;
}

function IngestionPage({
  bucketName,
  lockedProjects,
  syncedProjects,
  isSyncing,
  isRunningMigration,
  onSyncBatch,
  onBack,
  onInitiateDiscovery,
}: IngestionPageProps) {
  const hasSyncedProjects = syncedProjects.length > 0;
  const rows = buildRows(lockedProjects, syncedProjects);

  // How many are still pending vs synced
  const pendingCount = rows.filter((r) => !r.synced).length;
  const syncedCount  = rows.filter((r) =>  r.synced).length;

  return (
    <div className="ingest-shell">
      <div className="ingest-card">
        {/* ── Header ── */}
        <div className="ingest-header">
          <div className="ingest-header-left">
            <div className="ingest-title-row">
              <span className="ingest-icon" aria-hidden="true">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#2563eb" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
                </svg>
              </span>
              <h2>Data Ingestion &amp; GCS Sync Dashboard</h2>
            </div>
            {bucketName && (
              <p className="ingest-sub">
                Active Bucket: <strong>{bucketName}</strong>
                &nbsp;·&nbsp;
                <span style={{ color: '#374151' }}>
                  {rows.length} project{rows.length !== 1 ? 's' : ''} locked
                </span>
                {syncedCount > 0 && (
                  <>&nbsp;·&nbsp;<span style={{ color: '#16a34a', fontWeight: 700 }}>{syncedCount} synced ✓</span></>
                )}
                {pendingCount > 0 && hasSyncedProjects === false && (
                  <>&nbsp;·&nbsp;<span style={{ color: '#f59e0b', fontWeight: 700 }}>{pendingCount} pending sync</span></>
                )}
              </p>
            )}
          </div>
          <button
            className="ingest-sync-btn"
            onClick={onSyncBatch}
            disabled={isSyncing || hasSyncedProjects || lockedProjects.length === 0}
            type="button"
          >
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ marginRight: 7, verticalAlign: 'text-bottom' }}>
              <polyline points="17 1 21 5 17 9" /><path d="M3 11V9a4 4 0 0 1 4-4h14" />
              <polyline points="7 23 3 19 7 15" /><path d="M21 13v2a4 4 0 0 1-4 4H3" />
            </svg>
            {isSyncing
              ? 'Syncing…'
              : hasSyncedProjects
                ? 'Synced ✓'
                : 'Sync Batch to GCS & BQ'}
          </button>
        </div>

        {/* ── Table Section ── */}
        <div className="ingest-table-section">
          <div className="ingest-table-label">
            LOCKED BUCKET 1-1 MAPPED PROJECTS &amp; GCS PATHS
          </div>
          <div className="ingest-table-wrapper">
            <table className="ingest-table">
              <thead>
                <tr>
                  <th className="ingest-th">PROJECT NAME</th>
                  <th className="ingest-th">STATUS</th>
                  <th className="ingest-th">GENERATED PROJECT JOB ID</th>
                  <th className="ingest-th">CLOUD STORAGE PATH (1-1 FOLDER)</th>
                  <th className="ingest-th">BIGQUERY AUDIT SINK</th>
                </tr>
              </thead>
              <tbody>
                {rows.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="ingest-td ingest-td--empty">
                      No projects locked. Go back to Discovery and lock a bucket.
                    </td>
                  </tr>
                ) : (
                  rows.map((row, idx) => (
                    <tr key={`${row.name}-${idx}`} className={`ingest-row${row.synced ? ' ingest-row--synced' : ''}`}>
                      <td className="ingest-td">
                        <strong className="ingest-project-name">{row.name}</strong>
                      </td>
                      <td className="ingest-td">
                        {row.synced ? (
                          <span className="ingest-status ingest-status--synced">✓ Synced</span>
                        ) : isSyncing ? (
                          <span className="ingest-status ingest-status--syncing">⏳ Syncing…</span>
                        ) : (
                          <span className="ingest-status ingest-status--pending">⏸ Awaiting Sync</span>
                        )}
                      </td>
                      <td className="ingest-td">
                        <JobIdCell jobId={row.jobId} />
                      </td>
                      <td className="ingest-td">
                        <GcsPathCell path={row.gcsPath} />
                      </td>
                      <td className="ingest-td">
                        {row.bqSink
                          ? <code className="ingest-mono ingest-mono--bq">{row.bqSink}</code>
                          : <span className="ingest-pending">Pending…</span>}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          {/* Sync hint */}
          {rows.length > 0 && !hasSyncedProjects && !isSyncing && (
            <div className="ingest-sync-hint">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#2563eb" strokeWidth="2" style={{ flexShrink: 0 }}>
                <circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>
              </svg>
              Click <strong>Sync Batch to GCS &amp; BQ</strong> above to upload your project(s) and generate real Job IDs and GCS paths.
            </div>
          )}
        </div>

        {/* ── Footer navigation ── */}
        <div className="ingest-footer">
          <button className="ingest-back-btn" onClick={onBack} type="button">
            ← Back to Discovery
          </button>
          <button
            className="ingest-proceed-btn"
            onClick={onInitiateDiscovery}
            disabled={!hasSyncedProjects || isRunningMigration}
            type="button"
          >
            {isRunningMigration
              ? 'Running Discovery…'
              : 'Initiate Automated Discovery & AST Extraction →'}
          </button>
        </div>
      </div>
    </div>
  );
}

export default IngestionPage;
