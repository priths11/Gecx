import React, { useState, useEffect } from 'react';
import './css/SignupPage.css';
import { getSsoSetupUrl, configureGoogleIdp, configureSSOIdp, proxyFetch, CONFIG_API_PATH } from '../api/migrationApi';
import { useToast } from '../context/ToastContext';

interface SignupFormData {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  companyName: string;
  address1: string;
  address2: string;
  city: string;
  state: string;
  postalCode: string;
  country: string;
  promotion_id: string;
  loginType: string;
  customerType: string;
  termsAccepted: boolean;
}

interface SignupErrors {
  firstName?: string;
  lastName?: string;
  email?: string;
  phone?: string;
  companyName?: string;
  address1?: string;
  city?: string;
  state?: string;
  postalCode?: string;
  country?: string;
  termsAccepted?: string;
}

const SignupPage: React.FC<{ onCancel: () => void; onRegister: (data: SignupFormData) => void }> = ({ onCancel, onRegister }) => {
  const { showToast } = useToast();
  const [promotionCode, setPromotionCode] = useState('Fetching...');

  const [formData, setFormData] = useState<SignupFormData>({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    companyName: '',
    address1: '',
    address2: '',
    city: '',
    state: '',
    postalCode: '',
    country: '',
    promotion_id: '',
    loginType: 'GOOGLE_SSO',
    customerType: 'TRIAL',
    termsAccepted: false,
  });

  const [errors, setErrors] = useState<SignupErrors>({});

  // SSO Modal State
  const [showSSOModal, setShowSSOModal] = useState(false);
  const [ssoLoading, setSsoLoading] = useState(false);
  const [ssoCallbackURL] = useState('https://tgs-int-genai-vertextai-dev-01.firebaseapp.com/__/auth/handler');
  const [editProviderId, setEditProviderId] = useState(false);

  // General inputs & OKTA
  const [ssoName, setSsoName] = useState('');
  const [ssoProviderId, setSsoProviderId] = useState(''); // starting with oidc. / saml.
  const [ssoClientId, setSsoClientId] = useState('');
  const [ssoIssuerUrl, setSsoIssuerUrl] = useState('');
  const [ssoClientSecret, setSsoClientSecret] = useState('');

  // SAML Specific
  const [ssoEntityId, setSsoEntityId] = useState('');
  const [ssoUrl, setSsoUrl] = useState('');
  const [ssoCertificate, setSsoCertificate] = useState('');
  const [ssoSpEntityId, setSsoSpEntityId] = useState('');

  // Microsoft/Generic
  const [ssoAppId, setSsoAppId] = useState('');
  const [ssoAppSecret, setSsoAppSecret] = useState('');

  const hasFetched = React.useRef(false);

  useEffect(() => {
    if (!editProviderId) {
      const cleanName = ssoName.toLowerCase().replace(/[^a-z0-9]/g, '-').replace(/-+/g, '-').replace(/(^-|-$)/g, '');
      if (formData.loginType === 'OKTA_SSO') {
        setSsoProviderId('oidc.' + cleanName);
      } else if (formData.loginType === 'SAML_SSO') {
        setSsoProviderId('saml.' + cleanName);
      }
    }
  }, [ssoName, editProviderId, formData.loginType]);

  useEffect(() => {
    if (hasFetched.current) return;
    const runFetch = async () => {
      proxyFetch(`${CONFIG_API_PATH}/promotions/active`, { headers: { Accept: 'application/json' } })
        .then(res => res.json())
        .then(res => {
          if (res.data && res.data.promotion_code) {
            setPromotionCode(res.data.promotion_code);
            setFormData(prev => ({ ...prev, promotion_id: res.data.promotion_id }));
          }
        })
        .catch(console.error);
    };

    void runFetch();
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    const checked = (e.target as HTMLInputElement).checked;

    if (name === 'loginType' && (value === 'AZURE_SSO' || value === 'GOOGLE_SSO' || value === 'OKTA_SSO' || value === 'SAML_SSO')) {
      setShowSSOModal(true);
    }

    setFormData((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value,
    }));
    // Clear error when user types
    if (errors[name as keyof SignupErrors]) {
      setErrors((prev) => ({ ...prev, [name]: '' }));
    }
  };

  const validate = () => {
    const newErrors: SignupErrors = {};
    if (!formData.firstName) newErrors.firstName = 'First Name is required';
    if (!formData.lastName) newErrors.lastName = 'Last Name is required';
    if (!formData.email) {
      newErrors.email = 'Official Email is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Invalid email format';
    }
    if (!formData.phone) newErrors.phone = 'Phone No is required';
    if (!formData.companyName) newErrors.companyName = 'Company Name is required';
    if (!formData.address1) newErrors.address1 = 'Address Line 1 is required';
    if (!formData.city) newErrors.city = 'City is required';
    if (!formData.state) newErrors.state = 'State is required';
    if (!formData.postalCode) {
      newErrors.postalCode = 'Postal Code is required';
    } else if (!/^\d+$/.test(formData.postalCode)) {
      newErrors.postalCode = 'Postal Code must be numeric';
    }
    if (!formData.country) newErrors.country = 'Country is required';
    if (!formData.termsAccepted) newErrors.termsAccepted = 'You must accept the terms and conditions';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validate()) {
      onRegister(formData);
    }
  };

  const isSsoValid = () => {
    if (formData.loginType === 'OKTA_SSO') {
      return ssoName.trim() && ssoProviderId.trim() && ssoClientId.trim() && ssoIssuerUrl.trim() && ssoClientSecret.trim();
    }
    if (formData.loginType === 'SAML_SSO') {
      return ssoName.trim() && ssoProviderId.trim() && ssoEntityId.trim() && ssoUrl.trim() && ssoCertificate.trim() && ssoSpEntityId.trim();
    }
    return ssoAppId.trim() && ssoAppSecret.trim();
  };

  const handleSSOSubmit = async () => {
    if (!isSsoValid()) {
      showToast('Please fill out all required fields marked with *', 'error');
      return;
    }
    setSsoLoading(true);
    try {
      if (formData.loginType === 'GOOGLE_SSO') {
        await configureGoogleIdp({
          login_type: formData.loginType,
          client_id: ssoAppId,
          client_secret: ssoAppSecret,
          provider: 'google',
        });
        showToast('Google IDP configured successfully!', 'success');
        setShowSSOModal(false);
      } else if (formData.loginType === 'AZURE_SSO') {
        await configureSSOIdp({
          login_type: formData.loginType,
          client_id: ssoAppId,
          client_secret: ssoAppSecret,
          provider: 'microsoft',
        });
        showToast('Microsoft IDP configured successfully!', 'success');
        setShowSSOModal(false);
      } else {
        const ssoPayload: any = {
          login_type: formData.loginType,
        };

        if (formData.loginType === 'OKTA_SSO') {
          ssoPayload.name = ssoName;
          ssoPayload.provider_id = ssoProviderId;
          ssoPayload.client_id = ssoClientId;
          ssoPayload.issuer_url = ssoIssuerUrl;
          ssoPayload.client_secret = ssoClientSecret;
        } else if (formData.loginType === 'SAML_SSO') {
          ssoPayload.name = ssoName;
          ssoPayload.provider_id = ssoProviderId;
          ssoPayload.entity_id = ssoEntityId;
          ssoPayload.sso_url = ssoUrl;
          ssoPayload.certificate = ssoCertificate;
          ssoPayload.sp_entity_id = ssoSpEntityId;
        } else {
          ssoPayload.app_id = ssoAppId;
          ssoPayload.app_secret = ssoAppSecret;
        }

        await getSsoSetupUrl(ssoPayload);
        showToast('Configuration successfully saved!', 'success');
        setShowSSOModal(false);
      }
    } catch (err: any) {
      const msg = err.message || 'Error occurred during SSO setup';
      showToast(msg, 'error');
    } finally {
      setSsoLoading(false);
    }
  };

  return (
    <div className="signup-container">
      <form className="signup-form" onSubmit={handleSubmit}>
        <div className="teksystems-logo-wrap" style={{ marginTop: '10px' }}>
          <div className="teksystems-logo-mock">
            <img src="/teksystems-logo.jpeg" alt="TEKsystems logo" style={{ height: '28px', width: 'auto' }} />
            <span className="logo-tek">TEK<span className="logo-systems">systems</span></span>
          </div>
          <div className="teksystems-sub">Global Services</div>
        </div>
        <div className="auth-divider-thin" aria-hidden="true" />

        {/* Section 1: Your Details */}
        <div className="modern-section">
          <h3 className="modern-section-title">Your Details</h3>
          <div className="form-grid">
            <div className="form-group">
              <label>First Name</label>
              <input
                type="text"
                name="firstName"
                value={formData.firstName}
                onChange={handleChange}
                placeholder="Enter first name"
                className={errors.firstName ? 'error-input' : ''}
              />
              {errors.firstName && <span className="error-text">{errors.firstName}</span>}
            </div>
            <div className="form-group">
              <label>Last Name</label>
              <input
                type="text"
                name="lastName"
                value={formData.lastName}
                onChange={handleChange}
                placeholder="Enter last name"
                className={errors.lastName ? 'error-input' : ''}
              />
              {errors.lastName && <span className="error-text">{errors.lastName}</span>}
            </div>
            <div className="form-group">
              <label>Official Email</label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                placeholder="Enter official email"
                className={errors.email ? 'error-input' : ''}
              />
              {errors.email && <span className="error-text">{errors.email}</span>}
            </div>
            <div className="form-group">
              <label>Phone No</label>
              <input
                type="text"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                placeholder="Enter phone number"
                className={errors.phone ? 'error-input' : ''}
              />
              {errors.phone && <span className="error-text">{errors.phone}</span>}
            </div>
          </div>
        </div>

        {/* Section 2: Company Details */}
        <div className="modern-section">
          <h3 className="modern-section-title">Company Details</h3>
          <div className="form-stack">
            <div className="form-group full-width">
              <label>Company Name</label>
              <input
                type="text"
                name="companyName"
                value={formData.companyName}
                onChange={handleChange}
                placeholder="Enter company name"
                className={errors.companyName ? 'error-input' : ''}
              />
              {errors.companyName && <span className="error-text">{errors.companyName}</span>}
            </div>
            <div className="form-group full-width">
              <label>Address Line 1</label>
              <input
                type="text"
                name="address1"
                value={formData.address1}
                onChange={handleChange}
                placeholder="Address line 1"
                className={errors.address1 ? 'error-input' : ''}
              />
              {errors.address1 && <span className="error-text">{errors.address1}</span>}
            </div>
            <div className="form-group full-width">
              <label>Address Line 2 (Optional)</label>
              <input
                type="text"
                name="address2"
                value={formData.address2}
                onChange={handleChange}
                placeholder="Address line 2"
              />
            </div>
          </div>
          <div className="form-grid">
            <div className="form-group">
              <label>City</label>
              <input
                type="text"
                name="city"
                value={formData.city}
                onChange={handleChange}
                placeholder="City"
                className={errors.city ? 'error-input' : ''}
              />
              {errors.city && <span className="error-text">{errors.city}</span>}
            </div>
            <div className="form-group">
              <label>State</label>
              <input
                type="text"
                name="state"
                value={formData.state}
                onChange={handleChange}
                placeholder="State"
                className={errors.state ? 'error-input' : ''}
              />
              {errors.state && <span className="error-text">{errors.state}</span>}
            </div>
            <div className="form-group">
              <label>Postal Code</label>
              <input
                type="text"
                name="postalCode"
                value={formData.postalCode}
                onChange={handleChange}
                placeholder="Postal code"
                className={errors.postalCode ? 'error-input' : ''}
              />
              {errors.postalCode && <span className="error-text">{errors.postalCode}</span>}
            </div>
            <div className="form-group">
              <label>Country</label>
              <input
                type="text"
                name="country"
                value={formData.country}
                onChange={handleChange}
                placeholder="Country"
                className={errors.country ? 'error-input' : ''}
              />
              {errors.country && <span className="error-text">{errors.country}</span>}
            </div>
          </div>
        </div>

        {/* Section 3: Preferences */}
        <div className="modern-section">
          <h3 className="modern-section-title">Preferences</h3>
          <div className="preferences-stack">
            <div className="pref-row">
              <label>Promotion:</label>
              <div className="pref-input-wrap">
                <input type="text" value={promotionCode} disabled className="disabled-pill" />
              </div>
            </div>
            <div className="pref-row">
              <label>Login Type:</label>
              <div className="radio-group">
                <label className="radio-label">
                  <input type="radio" name="loginType" value="AZURE_SSO" checked={formData.loginType === 'AZURE_SSO'} onChange={handleChange} />
                  Microsoft
                </label>
                <label className="radio-label">
                  <input type="radio" name="loginType" value="GOOGLE_SSO" checked={formData.loginType === 'GOOGLE_SSO'} onChange={handleChange} />
                  Google SSO
                </label>
                <label className="radio-label">
                  <input type="radio" name="loginType" value="OKTA_SSO" checked={formData.loginType === 'OKTA_SSO'} onChange={handleChange} />
                  OKTA
                </label>
                <label className="radio-label">
                  <input type="radio" name="loginType" value="SAML_SSO" checked={formData.loginType === 'SAML_SSO'} onChange={handleChange} />
                  SAML
                </label>
              </div>
            </div>
            <div className="pref-row">
              <label>Customer Type:</label>
              <div className="radio-group">
                <label className="radio-label">
                  <input type="radio" name="customerType" value="PARTNER" checked={formData.customerType === 'PARTNER'} onChange={handleChange} />
                  Partner
                </label>
                <label className="radio-label">
                  <input type="radio" name="customerType" value="INTERNAL" checked={formData.customerType === 'INTERNAL'} onChange={handleChange} />
                  Internal
                </label>
                <label className="radio-label">
                  <input type="radio" name="customerType" value="TRIAL" checked={formData.customerType === 'TRIAL'} onChange={handleChange} />
                  Trial
                </label>
                <label className="radio-label">
                  <input type="radio" name="customerType" value="PERSONAL" checked={formData.customerType === 'PERSONAL'} onChange={handleChange} />
                  Personal
                </label>
              </div>
            </div>
          </div>
        </div>

        <div className="terms-section">
          <label className="checkbox-label">
            <input
              type="checkbox"
              name="termsAccepted"
              checked={formData.termsAccepted}
              onChange={handleChange}
            />
            Terms and Conditions
          </label>
          {errors.termsAccepted && <div className="error-text block">{errors.termsAccepted}</div>}
        </div>

        <div className="form-actions">
          <button type="button" className="cancel-btn" onClick={onCancel}>Cancel</button>
          <button type="submit" className="register-btn">Register</button>
        </div>
      </form>

      {/* SSO Setup Modal */}
      {showSSOModal && (
        <div className="sso-modal-overlay">
          <div className="sso-modal-content">
            <div className="sso-modal-header">
              <h3>SSO Configuration - {formData.loginType.replace('_', ' ')}</h3>
              <button className="sso-modal-close" onClick={() => setShowSSOModal(false)}>&times;</button>
            </div>

            <div className="sso-modal-body">
              <div className="sso-dynamic-form">
                <p className="sso-modal-hint" style={{ marginBottom: '16px' }}>Select and configure an identity provider.</p>

                <div className="sso-provider-select" style={{ marginBottom: '24px' }}>
                  <span style={{ fontSize: '11px', color: '#2563eb', fontWeight: 600, background: 'white', padding: '0 4px', position: 'relative', top: '8px', left: '12px' }}>Select a provider</span>
                  <select name="loginType" value={formData.loginType} onChange={handleChange} style={{ width: '100%', padding: '12px 14px', border: '1.5px solid #2563eb', borderRadius: '4px', fontSize: '14px', appearance: 'none', background: 'transparent', cursor: 'pointer', color: '#1e293b', fontWeight: 500 }}>
                    <option value="AZURE_SSO">Microsoft</option>
                    <option value="GOOGLE_SSO">Google</option>
                    <option value="OKTA_SSO">OpenID Connect</option>
                    <option value="SAML_SSO">SAML</option>
                  </select>
                </div>

                <div className="sso-details-row" style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: '16px' }}>
                  <button type="button" style={{ background: 'none', border: 'none', color: '#2563eb', fontSize: '13px', fontWeight: 600, padding: 0, cursor: 'pointer' }}>Details</button>
                </div>

                {formData.loginType === 'OKTA_SSO' && (
                  <>
                    <h4 style={{ fontSize: '15px', fontWeight: 600, color: '#1e293b', marginBottom: '16px' }}>Choose grant type</h4>
                    <div className="grant-type-radio" style={{ marginBottom: '24px' }}>
                      <input type="radio" checked readOnly style={{ marginRight: '8px' }} /> <span style={{ fontSize: '13px' }}>Code flow</span>
                    </div>
                    <div className="sso-input-group">
                      <label>Name *</label>
                      <input type="text" value={ssoName} onChange={e => setSsoName(e.target.value)} />
                      {!editProviderId && (
                        <span style={{ fontSize: '11px', color: '#64748b', marginTop: '6px', display: 'block' }}>Provider ID: {ssoProviderId || 'oidc.'} &nbsp;<button type="button" onClick={() => setEditProviderId(true)} style={{ color: '#2563eb', textDecoration: 'none', background: 'none', border: 'none', padding: 0, cursor: 'pointer', font: 'inherit', fontWeight: 600 }}>Edit</button></span>
                      )}
                    </div>
                    {editProviderId && (
                      <div className="sso-input-group">
                        <label>Provider ID * <span className="provider-id-hint" style={{ fontSize: '11px', color: '#64748b', display: 'block', marginTop: '4px' }}>Provider ID must start with 'oidc'</span></label>
                        <input type="text" value={ssoProviderId} onChange={e => setSsoProviderId(e.target.value)} />
                      </div>
                    )}
                    <div className="sso-input-group">
                      <label>Client ID *</label>
                      <input type="text" value={ssoClientId} onChange={e => setSsoClientId(e.target.value)} />
                    </div>
                    <div className="sso-input-group">
                      <label>Issuer (URL) *</label>
                      <input type="text" value={ssoIssuerUrl} onChange={e => setSsoIssuerUrl(e.target.value)} />
                    </div>
                    <div className="sso-input-group">
                      <label>Client secret *</label>
                      <input type="password" value={ssoClientSecret} onChange={e => setSsoClientSecret(e.target.value)} />
                    </div>
                  </>
                )}

                {formData.loginType === 'SAML_SSO' && (
                  <>
                    <div className="sso-input-group" style={{ marginTop: '16px' }}>
                      <label>Name *</label>
                      <input type="text" value={ssoName} onChange={e => setSsoName(e.target.value)} />
                      {!editProviderId && (
                        <span style={{ fontSize: '11px', color: '#64748b', marginTop: '6px', display: 'block' }}>Provider ID: {ssoProviderId || 'saml.'} &nbsp;<button type="button" onClick={() => setEditProviderId(true)} style={{ color: '#2563eb', textDecoration: 'none', background: 'none', border: 'none', padding: 0, cursor: 'pointer', font: 'inherit', fontWeight: 600 }}>Edit</button></span>
                      )}
                    </div>
                    {editProviderId && (
                      <div className="sso-input-group" style={{ marginTop: '16px' }}>
                        <label>Provider ID * <span className="provider-id-hint" style={{ fontSize: '11px', color: '#64748b', display: 'block', marginTop: '4px' }}>Provider ID: saml.</span></label>
                        <input type="text" value={ssoProviderId} onChange={e => setSsoProviderId(e.target.value)} />
                      </div>
                    )}
                    <div className="sso-grid-2" style={{ display: 'flex', gap: '12px' }}>
                      <div className="sso-input-group" style={{ flex: 1 }}>
                        <label>Entity ID *</label>
                        <input type="text" value={ssoEntityId} onChange={e => setSsoEntityId(e.target.value)} />
                      </div>
                      <div className="sso-input-group" style={{ flex: 1 }}>
                        <label>SSO URL *</label>
                        <input type="text" value={ssoUrl} onChange={e => setSsoUrl(e.target.value)} />
                      </div>
                    </div>

                    <h4 className="sso-section-header" style={{ fontSize: '16px', color: '#1e293b', marginTop: '32px', marginBottom: '16px', fontWeight: 600 }}>Certificates</h4>
                    <div className="sso-input-group">
                      <textarea rows={4} value={ssoCertificate} onChange={e => setSsoCertificate(e.target.value)} placeholder="Certificate 1 *" style={{ width: '100%', padding: '12px', border: '1px solid #cbd5e1', borderRadius: '4px', fontSize: '13px' }} />
                      <span style={{ fontSize: '11px', color: '#64748b', marginTop: '4px', display: 'block' }}>Must start with "-----BEGIN CERTIFICATE-----"</span>
                    </div>
                    <button type="button" className="sso-link-btn" style={{ background: 'none', border: '1px solid #cbd5e1', padding: '6px 12px', borderRadius: '4px', color: '#2563eb', fontSize: '12px', fontWeight: 600, cursor: 'pointer', marginBottom: '32px' }}>+ Add additional certificate</button>

                    <h4 className="sso-section-header" style={{ fontSize: '16px', color: '#1e293b', marginBottom: '16px', fontWeight: 600 }}>Service provider</h4>
                    <div className="sso-input-group">
                      <label>Entity ID *</label>
                      <input type="text" value={ssoSpEntityId} onChange={e => setSsoSpEntityId(e.target.value)} />
                    </div>
                  </>
                )}

                {(formData.loginType === 'AZURE_SSO' || formData.loginType === 'GOOGLE_SSO') && (
                  <>
                    <h4 style={{ fontSize: '15px', fontWeight: 600, color: '#1e293b', marginBottom: '16px' }}>Configure Microsoft</h4>
                    <div className="sso-input-group" style={{ marginTop: '16px' }}>
                      <label>App ID *</label>
                      <input type="text" value={ssoAppId} onChange={e => setSsoAppId(e.target.value)} />
                    </div>
                    <div className="sso-input-group">
                      <label>App secret *</label>
                      <input type="password" value={ssoAppSecret} onChange={e => setSsoAppSecret(e.target.value)} />
                    </div>
                  </>
                )}

                {/* Instruction Blocks which include the Callback URL now merged into single view! */}
                <div style={{ marginTop: '32px' }}>
                  <h3 style={{ fontSize: '17px', color: '#1e293b', marginBottom: '8px', fontWeight: 600 }}>
                    {formData.loginType === 'OKTA_SSO' && 'Configure your OIDC provider'}
                    {formData.loginType === 'SAML_SSO' && 'Configure your SAML provider'}
                    {(formData.loginType === 'AZURE_SSO' || formData.loginType === 'GOOGLE_SSO') && 'Configure Microsoft'}
                  </h3>

                  <p className="sso-modal-hint" style={{ fontSize: '13px', color: '#64748b', marginBottom: '16px' }}>
                    {formData.loginType === 'OKTA_SSO' && (
                      <>To complete set up, add this authorization callback URL to your OIDC app configuration. <a href="https://docs.cloud.google.com/identity-platform/docs/show-custom-domain?_gl=1*129n80b*_ga*MjE0NDUxNDc3My4xNzczOTI2MDE0*_ga_WH2QY8WWF5*czE3NzU5NzI2MjgkbzE3JGcwJHQxNzc1OTcyNjI4JGo2MCRsMCRoMA.." target="_blank" rel="noopener noreferrer" style={{ color: '#2563eb', textDecoration: 'none' }}>Learn more</a></>
                    )}
                    {formData.loginType === 'SAML_SSO' && (
                      <>To complete set up, add this authorization callback URL to your SAML app configuration. <a href="https://docs.cloud.google.com/identity-platform/docs/show-custom-domain?_gl=1*129n80b*_ga*MjE0NDUxNDc3My4xNzczOTI2MDE0*_ga_WH2QY8WWF5*czE3NzU5NzI2MjgkbzE3JGcwJHQxNzc1OTcyNjI4JGo2MCRsMCRoMA.." target="_blank" rel="noopener noreferrer" style={{ color: '#2563eb', textDecoration: 'none' }}>Learn more on customizing the callback URL.</a></>
                    )}
                    {(formData.loginType === 'AZURE_SSO' || formData.loginType === 'GOOGLE_SSO') && (
                      <>To complete set up, add this OAuth redirect URI to your Microsoft app configuration. <a href="https://docs.cloud.google.com/identity-platform/docs/web/microsoft?_gl=1*wdwrkg*_ga*MjE0NDUxNDc3My4xNzczOTI2MDE0*_ga_WH2QY8WWF5*czE3NzU4OTM4NTEkbzE2JGcxJHQxNzc1ODkzOTIzJGo2MCRsMCRoMA.." target="_blank" rel="noopener noreferrer" style={{ color: '#2563eb', textDecoration: 'none' }}>Learn more</a></>
                    )}
                  </p>

                  <div className="sso-callback-wrap">
                    <label style={{ fontSize: '11px', padding: '0 4px', background: 'white', position: 'relative', top: '8px', left: '12px', color: '#64748b' }}>Authorization callback (URL)</label>
                    <div className="sso-callback-input-wrap">
                      <input type="text" value={ssoCallbackURL} readOnly style={{ background: 'white', border: '1.5px solid #cbd5e1' }} />
                      <button
                        className="sso-copy-btn"
                        type="button"
                        onClick={() => {
                          navigator.clipboard.writeText(ssoCallbackURL);
                        }}
                        title="Copy to clipboard"
                      >
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>
                      </button>
                    </div>
                  </div>
                </div>

                <div className="sso-instruction-footer" style={{ marginTop: '40px' }}>
                  <h3 style={{ fontSize: '17px', color: '#1e293b', marginBottom: '8px', fontWeight: 600 }}>Configure your application</h3>
                  <p style={{ fontSize: '13px', color: '#64748b', lineHeight: 1.5, marginBottom: '16px' }}>Users will be created and updated as they log in using just-in-time(JIT) provisioning. You can configure project-wide account linking in settings.</p>
                </div>

                <div className="sso-modal-actions" style={{ display: 'flex', gap: '16px', marginTop: '32px' }}>
                  <button
                    className="sso-next-btn"
                    onClick={handleSSOSubmit}
                    type="button"
                    disabled={ssoLoading || !isSsoValid()}
                    style={{ background: '#2563eb', color: 'white', border: 'none', padding: '8px 20px', borderRadius: '4px', fontWeight: 600, cursor: isSsoValid() ? 'pointer' : 'not-allowed', opacity: isSsoValid() ? 1 : 0.6 }}
                  >
                    {ssoLoading ? 'Saving...' : 'Save'}
                  </button>
                  <button type="button" className="sso-cancel-btn" onClick={() => setShowSSOModal(false)} style={{ background: 'none', border: 'none', color: '#1e293b', fontWeight: 600, cursor: 'pointer' }}>Cancel</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SignupPage;
