import { useRef, useCallback, useEffect, useLayoutEffect, useMemo, useState } from 'react';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
// html2canvas removed — using jspdf-autotable for fast, non-blocking PDF generation
import { jsonToHtml, htmlToJson, toTitleCase, toSentenceCase } from '../utils/artifactRenderer';
import './css/OutputOnePage.css';
import DataChartsModal from './DataChartsModal';

// ─── Types ────────────────────────────────────────────────────────────────────

interface Artifact { name: string; type: string; apiKey: string; content: any; }
interface Props {
  activeArtifact: Artifact;
  artifacts: Artifact[];
  isApproving?: boolean;
  isGenerating?: boolean;
  approvedId?: number | null;
  onApprove: (payload: Record<string, any>) => void;
  onGenerate: () => void;
  onArtifactSelect: (name: string) => void;
  localEdits: Record<string, string>;
  onEditsChange: React.Dispatch<React.SetStateAction<Record<string, string>>>;
  // 5-step workflow additions
  bucketName?: string;
  projectNames?: string[];
  activeProjectName?: string;
  onProjectChange?: (name: string) => void;
  onBack?: () => void;
  onProceed?: () => void;
}

const ROW_PAGE_SIZE = 5;
const PAGINATED_ARTIFACT_KEYS = new Set([
  'page_summaries',
  'key_decision_points_first_20',
  'variable_catalog_first_20',
  'key_decision_points',
  'decision_points',
  'variable_catalog',
]);
const NESTED_PAGINATED_PARENT_KEYS = new Set([
  'decision_points_and_variable_catalog',
]);

function esc(s: string) {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function normalizeArtifactKey(value: string) {
  return value.toLowerCase().replace(/[\s_]+/g, '_');
}

function getArtifactPaginationKey(artifact: Artifact) {
  const apiKey = normalizeArtifactKey(artifact.apiKey ?? '');
  if (PAGINATED_ARTIFACT_KEYS.has(apiKey)) return apiKey;

  const nameKey = normalizeArtifactKey(artifact.name ?? '');
  if (PAGINATED_ARTIFACT_KEYS.has(nameKey)) return nameKey;

  return apiKey;
}

function getArtifactIdentityKey(artifact: Artifact) {
  const apiKey = normalizeArtifactKey(artifact.apiKey ?? '');
  const nameKey = normalizeArtifactKey(artifact.name ?? '');
  return apiKey || nameKey;
}

function arePageMapsEqual(left: Record<string, number>, right: Record<string, number>) {
  const leftKeys = Object.keys(left);
  const rightKeys = Object.keys(right);

  if (leftKeys.length !== rightKeys.length) return false;

  return leftKeys.every(key => left[key] === right[key]);
}

function buildSectionsHtml(sections: Artifact[], localEdits: Record<string, string>): string {
  return sections.map(a => {
    const content = localEdits[a.apiKey] ?? jsonToHtml(a.content);
    return `<div class="page-section" data-apikey="${esc(a.apiKey)}">
      <div class="page-section-title">${esc(toTitleCase(a.name))}</div>
      <div class="page-section-content">${content}</div>
    </div>`;
  }).join('');
}

// ─── Tabs Configuration ───────────────────────────────────────────────────────

const TAB_CONFIG = [
  {
    id: 'Business Use case',
    keys: ['current_business_use_case', 'problem_statement', 'intended_users', 'business_outcome', 'prioritized_business_journeys']
  },
  {
    id: 'Agent Design',
    keys: ['title', 'source_agent', 'overview', 'flow_grouping', 'flow_summaries', 'page_summaries']
  },
  {
    id: 'Technical Stack Review',
    keys: ['existing_input_inventory', 'flow_status_overview', 'webhook_summary', 'decision_points_and_variable_catalog', 'cx_test_case_summary_rows', 'summary']
  }
];

const ALL_KNOWN_KEYS = new Set(TAB_CONFIG.flatMap(t => t.keys));

// ─── Component ────────────────────────────────────────────────────────────────

function OutputOnePage({ artifacts, isApproving = false, isGenerating = false, approvedId, onApprove, onGenerate, localEdits, onEditsChange, bucketName, projectNames = [], activeProjectName, onProjectChange, onBack, onProceed }: Omit<Props, 'activeArtifact' | 'onArtifactSelect'> & { activeArtifact?: Artifact; onArtifactSelect?: (name: string) => void }) {
  const segmentRefs = useRef<Record<string, HTMLDivElement | null>>({});
  const paginatedRefs = useRef<Record<string, HTMLDivElement | null>>({});
  const nestedPaginatedRefs = useRef<Record<string, HTMLDivElement | null>>({});
  const [rowPageIndexMap, setRowPageIndexMap] = useState<Record<string, number>>({});
  const [isDownloading, setIsDownloading] = useState(false);
  const [activeTab, setActiveTab] = useState('Business Use case');
  const [isChartModalOpen, setIsChartModalOpen] = useState(false);

  // Find page summary columns config (used to hide columns in UI and PDF)
  const pageSummColsArtifact = artifacts.find(a =>
    normalizeArtifactKey(a.apiKey) === 'page_summary_columns'
  );
  const hiddenColKeys = new Set<string>(
    pageSummColsArtifact && Array.isArray(pageSummColsArtifact.content)
      ? (pageSummColsArtifact.content as any[])
          .filter((c: any) => c.hide)
          .map((c: any) => String(c.name).toLowerCase().replace(/\s+/g, '_'))
      : []
  );

  // Filter rows to remove hidden columns (for UI and PDF display only)
  const filterHiddenCols = (rows: any[]): any[] => {
    if (!hiddenColKeys.size || !rows.length) return rows;
    return rows.map(row => {
      const filtered: any = {};
      Object.keys(row).forEach(k => {
        if (!hiddenColKeys.has(k.toLowerCase())) filtered[k] = row[k];
      });
      return filtered;
    });
  };

  const availableTabs = [...TAB_CONFIG.map(t => t.id)];

  // Exclude hidden artifacts and metadata artifacts
  const displayArtifacts = useMemo(() => {
    const excludedKeys = new Set(['page_summary_columns', 'webhook_summary_columns', 'flow_page_hierarchy', 'flow_count', 'page_count']);
    const filtered = artifacts.filter(a => 
      !excludedKeys.has(normalizeArtifactKey(a.apiKey))
    );

    const activeTabConfig = TAB_CONFIG.find(t => t.id === activeTab);
    if (!activeTabConfig) return filtered;

    const matched = filtered.filter(a => activeTabConfig.keys.includes(normalizeArtifactKey(a.apiKey)));
    matched.sort((a, b) => {
      const idxA = activeTabConfig.keys.indexOf(normalizeArtifactKey(a.apiKey));
      const idxB = activeTabConfig.keys.indexOf(normalizeArtifactKey(b.apiKey));
      return idxA - idxB;
    });

    if (activeTab === 'Agent Design') {
      const others = filtered.filter(a => !ALL_KNOWN_KEYS.has(normalizeArtifactKey(a.apiKey)));
      return [...matched, ...others];
    }
    return matched;
  }, [artifacts, activeTab]);

  const contentBlocks: Array<
    | { type: 'segment'; id: string; artifacts: Artifact[] }
    | { type: 'paginated'; artifact: Artifact; normalizedKey: string }
    | { type: 'nested-paginated'; artifact: Artifact; identityKey: string }
  > = useMemo(() => {
    const blocks: Array<
      | { type: 'segment'; id: string; artifacts: Artifact[] }
      | { type: 'paginated'; artifact: Artifact; normalizedKey: string }
      | { type: 'nested-paginated'; artifact: Artifact; identityKey: string }
    > = [];

    let currentSegment: Artifact[] = [];
    let segmentIndex = 0;

    displayArtifacts.forEach(artifact => {
      const normalizedKey = getArtifactPaginationKey(artifact);
      const isPaginatedArtifact = PAGINATED_ARTIFACT_KEYS.has(normalizedKey) && Array.isArray(artifact.content);
      const identityKey = getArtifactIdentityKey(artifact);
      const isNestedPaginatedArtifact =
        NESTED_PAGINATED_PARENT_KEYS.has(identityKey) &&
        artifact.content &&
        typeof artifact.content === 'object' &&
        !Array.isArray(artifact.content);

      if (isPaginatedArtifact || isNestedPaginatedArtifact) {
        if (currentSegment.length) {
          blocks.push({ type: 'segment', id: `segment-${segmentIndex}`, artifacts: currentSegment });
          currentSegment = [];
          segmentIndex += 1;
        }
        if (isPaginatedArtifact) {
          blocks.push({ type: 'paginated', artifact, normalizedKey });
        } else {
          blocks.push({ type: 'nested-paginated', artifact, identityKey });
        }
        return;
      }

      currentSegment.push(artifact);
    });

    if (currentSegment.length) {
      blocks.push({ type: 'segment', id: `segment-${segmentIndex}`, artifacts: currentSegment });
    }

    return blocks;
  }, [displayArtifacts]);

  // Reset row page when artifacts change
  useEffect(() => {
    setRowPageIndexMap(prev => {
      const next: Record<string, number> = {};
      displayArtifacts.forEach(artifact => {
        const normalizedKey = getArtifactPaginationKey(artifact);
        if (PAGINATED_ARTIFACT_KEYS.has(normalizedKey) && Array.isArray(artifact.content)) {
          const maxPageIndex = Math.max(0, Math.ceil(artifact.content.length / ROW_PAGE_SIZE) - 1);
          next[normalizedKey] = Math.min(prev[normalizedKey] ?? 0, maxPageIndex);
        }

        if (
          NESTED_PAGINATED_PARENT_KEYS.has(getArtifactIdentityKey(artifact)) &&
          artifact.content &&
          typeof artifact.content === 'object' &&
          !Array.isArray(artifact.content)
        ) {
          Object.entries(artifact.content as Record<string, any>).forEach(([key, value]) => {
            const normalizedChildKey = normalizeArtifactKey(key);
            if (!PAGINATED_ARTIFACT_KEYS.has(normalizedChildKey) || !Array.isArray(value)) return;
            const pageStateKey = `${getArtifactIdentityKey(artifact)}:${normalizedChildKey}`;
            const maxPageIndex = Math.max(0, Math.ceil(value.length / ROW_PAGE_SIZE) - 1);
            next[pageStateKey] = Math.min(prev[pageStateKey] ?? 0, maxPageIndex);
          });
        }
      });
      return arePageMapsEqual(prev, next) ? prev : next;
    });
  }, [displayArtifacts]);

  // Set editable segment HTML — only when artifacts change, not on every keystroke
  useEffect(() => {
    contentBlocks.forEach(block => {
      if (block.type !== 'segment') return;
      const target = segmentRefs.current[block.id];
      if (!target) return;
      target.innerHTML = buildSectionsHtml(block.artifacts, localEdits);
    });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [artifacts, activeTab]);

  // Set paginated table HTML (sliced by row page)
  useLayoutEffect(() => {
    contentBlocks.forEach(block => {
      if (block.type !== 'paginated') return;
      const target = paginatedRefs.current[block.normalizedKey];
      if (!target || !Array.isArray(block.artifact.content)) return;

      const scrollEl = target.closest('.viewer-scroll-container') as HTMLElement | null;
      const savedTop = scrollEl?.scrollTop ?? 0;
      const rowPageIndex = rowPageIndexMap[block.normalizedKey] ?? 0;
      const slice = (block.artifact.content as any[]).slice(
        rowPageIndex * ROW_PAGE_SIZE,
        (rowPageIndex + 1) * ROW_PAGE_SIZE
      );
      const rows = block.normalizedKey === 'page_summaries' ? filterHiddenCols(slice) : slice;
      target.innerHTML = jsonToHtml(rows);

      if (scrollEl) requestAnimationFrame(() => { scrollEl.scrollTop = savedTop; });
    });

    contentBlocks.forEach(block => {
      if (block.type !== 'nested-paginated') return;
      const content = block.artifact.content;
      if (!content || typeof content !== 'object' || Array.isArray(content)) return;

      Object.entries(content as Record<string, any>).forEach(([key, value]) => {
        const normalizedChildKey = normalizeArtifactKey(key);
        if (!PAGINATED_ARTIFACT_KEYS.has(normalizedChildKey) || !Array.isArray(value)) return;

        const refKey = `${block.identityKey}:${normalizedChildKey}`;
        const target = nestedPaginatedRefs.current[refKey];
        if (!target) return;

        const scrollEl = target.closest('.viewer-scroll-container') as HTMLElement | null;
        const savedTop = scrollEl?.scrollTop ?? 0;
        const rowPageIndex = rowPageIndexMap[refKey] ?? 0;
        const slice = value.slice(
          rowPageIndex * ROW_PAGE_SIZE,
          (rowPageIndex + 1) * ROW_PAGE_SIZE
        );
        target.innerHTML = jsonToHtml(slice);

        if (scrollEl) requestAnimationFrame(() => { scrollEl.scrollTop = savedTop; });
      });
    });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [artifacts, rowPageIndexMap, activeTab]);

  // Extract per-section edits from whichever editable div fired the event
  const handleInput = useCallback((e: React.SyntheticEvent<HTMLDivElement>) => {
    const container = e.currentTarget;
    const updates: Record<string, string> = {};
    container.querySelectorAll<HTMLElement>('[data-apikey]').forEach(el => {
      const key = el.getAttribute('data-apikey')!;
      const contentEl = el.querySelector('.page-section-content');
      if (contentEl) {
        updates[key] = contentEl.innerHTML;
      } else {
        const clone = el.cloneNode(true) as HTMLElement;
        clone.querySelector('.page-section-title')?.remove();
        updates[key] = clone.innerHTML;
      }
    });
    onEditsChange(prev => ({ ...prev, ...updates }));
  }, [onEditsChange]);

  const flushEdits = () => {
    const freshEdits = { ...localEdits };
    Object.values(segmentRefs.current).forEach(node => {
      node?.querySelectorAll<HTMLElement>('[data-apikey]').forEach(el => {
        const k = el.getAttribute('data-apikey')!;
        const contentEl = el.querySelector('.page-section-content');
        if (contentEl) {
          freshEdits[k] = contentEl.innerHTML;
        } else {
          const clone = el.cloneNode(true) as HTMLElement;
          clone.querySelector('.page-section-title')?.remove();
          freshEdits[k] = clone.innerHTML;
        }
      });
    });
    return freshEdits;
  };

  const handleApprove = () => {
    const freshEdits = flushEdits();
    const payload: Record<string, any> = {};
    artifacts.forEach(a => {
      if (PAGINATED_ARTIFACT_KEYS.has(getArtifactPaginationKey(a)) && Array.isArray(a.content)) {
        payload[a.apiKey] = a.content; // always use full original rows
        return;
      }
      if (NESTED_PAGINATED_PARENT_KEYS.has(getArtifactIdentityKey(a))) {
        payload[a.apiKey] = a.content; // always use full original rows
        return;
      }
      const editedHtml = freshEdits[a.apiKey];
      if (editedHtml === undefined) {
        payload[a.apiKey] = a.content;
      } else {
        const container = document.createElement('div');
        container.innerHTML = editedHtml;
        const root = container.firstElementChild;
        payload[a.apiKey] = root ? htmlToJson(root) : a.content;
      }
    });
    onApprove(payload);
  };

  const handleDownload = () => {
    if (isDownloading) return;
    setIsDownloading(true);

    // Run after current render so button shows "Generating PDF…" first
    setTimeout(() => {
      try {
        const pdf = new jsPDF({ unit: 'mm', format: 'a4', orientation: 'landscape' });
        const margin = 14;
        const pageW = pdf.internal.pageSize.getWidth();
        let cursorY = margin;

        const addSectionHeader = (title: string) => {
          if (cursorY > margin + 10) { cursorY += 6; }
          pdf.setFontSize(10);
          pdf.setFont('helvetica', 'bold');
          pdf.setTextColor(37, 99, 235);
          pdf.text(title, margin, cursorY);
          cursorY += 1;
          pdf.setDrawColor(37, 99, 235);
          pdf.setLineWidth(0.3);
          pdf.line(margin, cursorY, pageW - margin, cursorY);
          cursorY += 5;
          pdf.setTextColor(0, 0, 0);
        };

        const addKeyValue = (key: string, value: string) => {
          pdf.setFontSize(9);
          pdf.setFont('helvetica', 'bold');
          const keyText = `${key}: `;
          const keyW = pdf.getTextWidth(keyText);
          pdf.text(keyText, margin + 2, cursorY);
          pdf.setFont('helvetica', 'normal');
          const maxW = pageW - margin * 2 - keyW - 2;
          const lines = pdf.splitTextToSize(toSentenceCase(value), maxW);
          pdf.text(lines, margin + 2 + keyW, cursorY);
          cursorY += 5 * lines.length;
          if (cursorY > pdf.internal.pageSize.getHeight() - margin) {
            pdf.addPage(); cursorY = margin;
          }
        };

        // Add spaces after JSON structural characters so jsPDF linebreak can wrap at word boundaries
        const formatCell = (v: any): string => {
          if (v == null) return '';
          if (typeof v !== 'object') return toSentenceCase(String(v));
          return toSentenceCase(JSON.stringify(v).replace(/,(?="|\[|\{)/g, ', ').replace(/:(?="|\[|\{|\d|true|false|null)/g, ': '));
        };

        const addArrayTable = (rows: any[]) => {
          if (!rows.length) return;
          const keys = Object.keys(rows[0]);
          const headers = keys.map(k => toTitleCase(k));
          autoTable(pdf, {
            startY: cursorY,
            head: [headers],
            body: rows.map(row => keys.map(k => formatCell(row[k]))),
            margin: { left: margin, right: margin },
            styles: { fontSize: 7, cellPadding: 2, overflow: 'linebreak', minCellWidth: 20 },
            headStyles: { fillColor: [243, 244, 246], textColor: [30, 41, 59], fontStyle: 'bold' },
            alternateRowStyles: { fillColor: [248, 250, 252] },
            theme: 'grid',
            didDrawPage: () => { cursorY = margin; },
          });
          cursorY = (pdf as any).lastAutoTable.finalY + 6;
        };

        const addBulletList = (items: string[], indent = 4) => {
          pdf.setFontSize(9);
          pdf.setFont('helvetica', 'normal');
          pdf.setTextColor(71, 85, 105);
          items.forEach(item => {
            if (cursorY > pdf.internal.pageSize.getHeight() - margin) { pdf.addPage(); cursorY = margin; }
            const lines = pdf.splitTextToSize(`• ${toSentenceCase(item)}`, pageW - margin * 2 - indent);
            pdf.text(lines, margin + indent, cursorY);
            cursorY += 5 * lines.length;
          });
          pdf.setTextColor(0, 0, 0);
        };

        const addFieldLabel = (label: string) => {
          if (cursorY > pdf.internal.pageSize.getHeight() - margin) { pdf.addPage(); cursorY = margin; }
          pdf.setFontSize(9);
          pdf.setFont('helvetica', 'bold');
          pdf.setTextColor(55, 65, 81);
          pdf.text(`${label}:`, margin + 2, cursorY);
          cursorY += 5;
          pdf.setTextColor(0, 0, 0);
        };

        const renderContent = (content: any) => {
          if (content == null) return;

          if (Array.isArray(content)) {
            if (!content.length) return;
            if (typeof content[0] === 'object' && content[0] !== null) {
              addArrayTable(content);
            } else {
              addBulletList(content.map((i: any) => String(i ?? '')));
            }
            return;
          }

          if (typeof content === 'object') {
            Object.entries(content).forEach(([k, v]) => {
              if (v == null) return;
              const label = toTitleCase(k);
              if (Array.isArray(v)) {
                if (!v.length) return;
                addFieldLabel(label);
                if (typeof v[0] === 'object' && v[0] !== null) {
                  addArrayTable(v);
                } else {
                  addBulletList(v.map((i: any) => String(i ?? '')));
                }
              } else if (typeof v === 'object') {
                addFieldLabel(label);
                renderContent(v);
              } else {
                addKeyValue(label, String(v).trim());
              }
            });
            return;
          }

          pdf.setFontSize(9);
          pdf.setFont('helvetica', 'normal');
          pdf.setTextColor(71, 85, 105);
          const lines = pdf.splitTextToSize(toSentenceCase(String(content)), pageW - margin * 2 - 2);
          lines.forEach((line: string) => {
            if (cursorY > pdf.internal.pageSize.getHeight() - margin) { pdf.addPage(); cursorY = margin; }
            pdf.text(line, margin + 2, cursorY);
            cursorY += 5;
          });
          pdf.setTextColor(0, 0, 0);
        };

        const freshEdits = flushEdits();

        const excludedKeys = new Set(['page_summary_columns', 'webhook_summary_columns', 'flow_page_hierarchy', 'flow_count', 'page_count']);
        const filtered = artifacts.filter(a => 
          !excludedKeys.has(normalizeArtifactKey(a.apiKey))
        );

        TAB_CONFIG.forEach((tab, tabIndex) => {
          const matched = filtered.filter(a => tab.keys.includes(normalizeArtifactKey(a.apiKey)));
          matched.sort((a, b) => {
            const idxA = tab.keys.indexOf(normalizeArtifactKey(a.apiKey));
            const idxB = tab.keys.indexOf(normalizeArtifactKey(b.apiKey));
            return idxA - idxB;
          });

          const tabArtifacts = [...matched];
          if (tab.id === 'Agent Design') {
            const others = filtered.filter(a => !ALL_KNOWN_KEYS.has(normalizeArtifactKey(a.apiKey)));
            tabArtifacts.push(...others);
          }

          if (tabArtifacts.length === 0) return;

          if (tabIndex > 0) {
            pdf.addPage();
            cursorY = margin;
          }

          pdf.setFontSize(16);
          pdf.setFont('helvetica', 'bold');
          pdf.setTextColor(15, 23, 42);
          pdf.text(tab.id, margin, cursorY);
          cursorY += 2;
          pdf.setDrawColor(15, 23, 42);
          pdf.setLineWidth(0.5);
          pdf.line(margin, cursorY, pageW - margin, cursorY);
          cursorY += 8;
          pdf.setTextColor(0, 0, 0);

          tabArtifacts.forEach((a, i) => {
            if (i > 0 && cursorY > margin + 20) {
              if (cursorY > pdf.internal.pageSize.getHeight() - margin - 20) {
                pdf.addPage(); cursorY = margin;
              }
            }
            addSectionHeader(toTitleCase(a.name));
            let content = a.content;
            // For paginated table sections, don't apply edited HTML
            if (getArtifactPaginationKey(a) === 'page_summaries' && Array.isArray(content)) {
              renderContent(filterHiddenCols(content));
              return;
            }
            if (PAGINATED_ARTIFACT_KEYS.has(getArtifactPaginationKey(a)) && Array.isArray(content)) {
              renderContent(content);
              return;
            }
            if (NESTED_PAGINATED_PARENT_KEYS.has(getArtifactIdentityKey(a))) {
              renderContent(content);
              return;
            }
            const editedHtml = freshEdits[a.apiKey];
            if (editedHtml !== undefined) {
              const container = document.createElement('div');
              container.innerHTML = editedHtml;
              const root = container.firstElementChild;
              content = root ? htmlToJson(root) : a.content;
            }
            renderContent(content);
          });
        });

        pdf.save('migration-brief.pdf');
      } finally {
        setIsDownloading(false);
      }
    }, 50);
  };

  if (!artifacts.length) return (
    <section className="output-card">
      <div className="output-card-head">
        <div className="output-card-title">
          <div className="output-card-icon" aria-hidden="true">⌘</div>
          <div>
            <h2>Output 1: Parsed DFCX AST</h2>
            <p>Review and edit the structured data extracted from the legacy system.</p>
          </div>
        </div>
      </div>
      <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#94a3b8', fontSize: '14px' }}>
        Run discovery on the Ingestion page to see results here.
      </div>
    </section>
  );

  return (
    <section className="output-card">
      <div className="output-card-head">
        <div className="output-card-title">
          <div className="output-card-icon" aria-hidden="true">⌘</div>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
              <h2 style={{ margin: 0 }}>Output 1: Parsed DFCX AST</h2>
              {bucketName && (
                <span className="o1-bucket-badge">Bucket: {bucketName}</span>
              )}
            </div>
            {activeProjectName && (
              <p style={{ margin: '4px 0 0', fontSize: 13, color: '#64748b' }}>
                Review and edit the structured data extracted from the legacy system for:{' '}
                <strong>{activeProjectName}</strong>
                {bucketName && <> under Bucket <strong>{bucketName}</strong></>}.
              </p>
            )}
          </div>
        </div>
        <div className="output-card-actions">
          {/* Project selector */}
          {projectNames.length > 0 && (
            <select
              className="o1-project-select"
              value={activeProjectName || ''}
              onChange={(e) => onProjectChange?.(e.target.value)}
              aria-label="Select project"
            >
              {projectNames.map((n) => (
                <option key={n} value={n}>{n}</option>
              ))}
            </select>
          )}

          {/* Save PDF */}
          <button className="o1-btn o1-btn--secondary" type="button" onClick={handleDownload} disabled={isDownloading}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ marginRight: 5, verticalAlign: 'text-bottom' }}><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            {isDownloading ? 'Generating…' : 'Save PDF'}
          </button>

          {/* Approved / Sync to GCS */}
          <button
            className={`o1-btn ${approvedId ? 'o1-btn--approved' : 'o1-btn--approve'}`}
            type="button"
            onClick={handleApprove}
            disabled={isApproving}
          >
            {isApproving ? 'Syncing…' : approvedId ? '✓ Approved' : 'Sync to GCS'}
          </button>

          {/* Bulk Approve */}
          <button
            className="o1-btn o1-btn--bulk"
            type="button"
            onClick={handleApprove}
            disabled={isApproving}
          >
            Bulk Approve All SSOT
          </button>

          {/* Generate GECX */}
          <button
            className="o1-btn o1-btn--generate"
            type="button"
            onClick={onGenerate}
            disabled={isGenerating || !approvedId}
          >
            {isGenerating ? 'Generating…' : 'Generate GECX 🚀'}
          </button>

          {/* Charts */}
          <button className="o1-btn o1-btn--icon" type="button" onClick={() => setIsChartModalOpen(true)} aria-label="View Charts" title="View Charts">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z" />
              <circle cx="12" cy="12" r="3" />
            </svg>
          </button>
        </div>
      </div>

      <div className="output-one-tabs" role="tablist" aria-label="Output 1 tabs">
        {availableTabs.map((tab: string) => (
          <button
            key={tab}
            className={`output-one-tab${activeTab === tab ? ' active' : ''}`}
            onClick={() => setActiveTab(tab)}
            type="button"
          >
            {tab}
          </button>
        ))}
      </div>

      <div className="output-workspace">
        <section className="artifact-viewer">
          <div className="viewer-scroll-container">
            {contentBlocks.map(block => {
              if (block.type === 'segment') {
                return (
                  <div
                    key={block.id}
                    ref={(node) => { segmentRefs.current[block.id] = node; }}
                    className="jv-editor"
                    onInput={handleInput}
                  />
                );
              }

              if (block.type === 'nested-paginated') {
                const nestedContent = block.artifact.content as Record<string, any>;

                return (
                  <div key={block.artifact.apiKey} className="page-section page-section-paginated">
                    <div className="page-section-title">{toTitleCase(block.artifact.name)}</div>
                    <div className="jv-sections">
                      {Object.entries(nestedContent).map(([key, value]) => {
                        const normalizedChildKey = normalizeArtifactKey(key);
                        const pageStateKey = `${block.identityKey}:${normalizedChildKey}`;

                        if (PAGINATED_ARTIFACT_KEYS.has(normalizedChildKey) && Array.isArray(value)) {
                          const totalRows = value.length;
                          const totalRowPages = Math.ceil(totalRows / ROW_PAGE_SIZE);
                          const rowPageIndex = rowPageIndexMap[pageStateKey] ?? 0;
                          const showPagination = totalRows > ROW_PAGE_SIZE;

                          return (
                            <div key={key} className="jv-section-card" data-key={key}>
                              <div className="jv-section-label">{toTitleCase(key)}</div>
                              <div className="jv-section-body">
                                <div ref={(node) => { nestedPaginatedRefs.current[pageStateKey] = node; }} />
                                {showPagination && (
                                  <div className="pagination-bar-inline">
                                    <button
                                      className="pagination-btn"
                                      type="button"
                                      disabled={rowPageIndex === 0}
                                      onClick={(e) => {
                                        (e.currentTarget as HTMLElement).blur();
                                        setRowPageIndexMap(prev => ({
                                          ...prev,
                                          [pageStateKey]: Math.max(0, (prev[pageStateKey] ?? 0) - 1),
                                        }));
                                      }}
                                    >
                                      ← Previous
                                    </button>
                                    <span className="pagination-info">
                                      Rows {rowPageIndex * ROW_PAGE_SIZE + 1}–{Math.min((rowPageIndex + 1) * ROW_PAGE_SIZE, totalRows)} of {totalRows}
                                    </span>
                                    <button
                                      className="pagination-btn"
                                      type="button"
                                      disabled={rowPageIndex === totalRowPages - 1}
                                      onClick={(e) => {
                                        (e.currentTarget as HTMLElement).blur();
                                        setRowPageIndexMap(prev => ({
                                          ...prev,
                                          [pageStateKey]: Math.min(totalRowPages - 1, (prev[pageStateKey] ?? 0) + 1),
                                        }));
                                      }}
                                    >
                                      Next →
                                    </button>
                                  </div>
                                )}
                              </div>
                            </div>
                          );
                        }

                        return (
                          <div key={key} className="jv-section-card" data-key={key}>
                            <div className="jv-section-label">{toTitleCase(key)}</div>
                            <div
                              className="jv-section-body"
                              dangerouslySetInnerHTML={{ __html: jsonToHtml(value) }}
                            />
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              }

              const totalRows = Array.isArray(block.artifact.content) ? block.artifact.content.length : 0;
              const totalRowPages = Math.ceil(totalRows / ROW_PAGE_SIZE);
              const rowPageIndex = rowPageIndexMap[block.normalizedKey] ?? 0;
              const showPagination = totalRows > ROW_PAGE_SIZE;

              return (
                <div key={block.artifact.apiKey} className="page-section page-section-paginated">
                  <div className="page-section-title">{toTitleCase(block.artifact.name)}</div>
                  <div ref={(node) => { paginatedRefs.current[block.normalizedKey] = node; }} />
                  {showPagination && (
                    <div className="pagination-bar-inline">
                      <button
                        className="pagination-btn"
                        type="button"
                        disabled={rowPageIndex === 0}
                        onClick={(e) => {
                          (e.currentTarget as HTMLElement).blur();
                          setRowPageIndexMap(prev => ({
                            ...prev,
                            [block.normalizedKey]: Math.max(0, (prev[block.normalizedKey] ?? 0) - 1),
                          }));
                        }}
                      >
                        ← Previous
                      </button>
                      <span className="pagination-info">
                        Rows {rowPageIndex * ROW_PAGE_SIZE + 1}–{Math.min((rowPageIndex + 1) * ROW_PAGE_SIZE, totalRows)} of {totalRows}
                      </span>
                      <button
                        className="pagination-btn"
                        type="button"
                        disabled={rowPageIndex === totalRowPages - 1}
                        onClick={(e) => {
                          (e.currentTarget as HTMLElement).blur();
                          setRowPageIndexMap(prev => ({
                            ...prev,
                            [block.normalizedKey]: Math.min(totalRowPages - 1, (prev[block.normalizedKey] ?? 0) + 1),
                          }));
                        }}
                      >
                        Next →
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </section>
      </div>

      <DataChartsModal
        isOpen={isChartModalOpen}
        onClose={() => setIsChartModalOpen(false)}
        artifacts={artifacts}
      />

      {/* Footer navigation */}
      <div className="o1-footer-nav">
        <button className="o1-nav-btn o1-nav-btn--back" onClick={onBack} type="button">
          ← Back to Ingestion
        </button>
        <button
          className="o1-nav-btn o1-nav-btn--proceed"
          onClick={onProceed}
          type="button"
          disabled={!approvedId}
        >
          Proceed to HITL GECX Ready Files →
        </button>
      </div>
    </section>
  );
}

export default OutputOnePage;
