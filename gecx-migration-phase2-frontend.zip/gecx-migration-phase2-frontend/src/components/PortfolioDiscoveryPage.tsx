import React, { useRef } from 'react';
import type { DiscoveredProject, QuotaTier } from '../workflowTypes';
import './css/PortfolioDiscoveryPage.css';

// ─── Sub-components ────────────────────────────────────────────────────────────

interface DiscoveryKPICardProps {
  label: string;
  value: string;
  subValue?: string;
  accent: 'blue' | 'green' | 'orange' | 'purple';
  icon: React.ReactNode;
}

function DiscoveryKPICard({ label, value, subValue, accent, icon }: DiscoveryKPICardProps) {
  return (
    <div className={`disc-kpi-card disc-kpi-card--${accent}`}>
      <span className="disc-kpi-label">{label}</span>
      <div className="disc-kpi-value">{value}</div>
      {subValue && (
        <div className="disc-kpi-sub">
          {accent === 'green' && <span className="disc-kpi-check" aria-hidden="true">✓ </span>}
          {accent === 'orange' && <span className="disc-kpi-warn" aria-hidden="true">⚠ </span>}
          {subValue}
        </div>
      )}
      <div className="disc-kpi-icon" aria-hidden="true">{icon}</div>
    </div>
  );
}

interface ProjectRowProps {
  project: DiscoveredProject;
  onToggle: (id: string) => void;
  onInspect: (id: string) => void;
}

function ProjectRow({ project, onToggle, onInspect }: ProjectRowProps) {
  return (
    <tr className={`disc-table-row ${project.selected ? 'disc-table-row--selected' : ''}`}>
      <td className="disc-td disc-td--check">
        <input
          type="checkbox"
          checked={project.selected}
          onChange={() => onToggle(project.id)}
          className="disc-checkbox"
          aria-label={`Select ${project.name}`}
        />
      </td>
      <td className="disc-td">
        <div className="disc-project-name">{project.name}</div>
        <div className="disc-agent-id">{project.agentId || '—'}</div>
      </td>
      <td className="disc-td">
        <span className={`disc-source-badge disc-source-badge--${project.sourceType === 'GCP Console' ? 'gcp' : 'zip'}`}>
          {project.sourceType === 'GCP Console' ? (
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <path d="M12 2L2 7l10 5 10-5-10-5z" stroke="#4285f4" strokeWidth="2" strokeLinejoin="round"/>
              <path d="M2 17l10 5 10-5M2 12l10 5 10-5" stroke="#4285f4" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          ) : (
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" stroke="#7c3aed" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          )}
          {project.sourceType}
        </span>
      </td>
      <td className="disc-td">
        <span className="disc-status disc-status--unanalyzed">{project.categorizationStatus}</span>
      </td>
      <td className="disc-td disc-td--matrix">
        Run analysis to evaluate
      </td>
      <td className="disc-td">
        <button
          className="disc-inspect-btn"
          onClick={() => onInspect(project.id)}
          type="button"
        >
          🔍 Inspect
        </button>
      </td>
    </tr>
  );
}

// ─── Main Component ────────────────────────────────────────────────────────────

interface PortfolioDiscoveryPageProps {
  discoveredProjects: DiscoveredProject[];
  bucketName: string;
  onBucketNameChange: (name: string) => void;
  onAddZipFiles: (files: File[]) => void;
  onFetchGcpProjects: () => void;
  onToggleSelect: (id: string) => void;
  onSelectAll: (checked: boolean) => void;
  onAnalyze: () => void;
  onLockBucket: () => void;
  quotaTotal: number;
  tiers: QuotaTier[];
}

function PortfolioDiscoveryPage({
  discoveredProjects,
  bucketName,
  onBucketNameChange,
  onAddZipFiles,
  onFetchGcpProjects,
  onToggleSelect,
  onSelectAll,
  onAnalyze,
  onLockBucket,
  quotaTotal,
  tiers,
}: PortfolioDiscoveryPageProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const selectedProjects = discoveredProjects.filter((p) => p.selected);
  const quotaUsed = selectedProjects.length;
  const unassigned = discoveredProjects.length - selectedProjects.length;
  const allChecked = discoveredProjects.length > 0 && discoveredProjects.every((p) => p.selected);
  const quotaPercent = quotaTotal > 0 ? Math.round((quotaUsed / quotaTotal) * 100) : 0;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.currentTarget.files || []).filter((f) =>
      f.name.toLowerCase().endsWith('.zip')
    );
    if (files.length) onAddZipFiles(files);
    e.currentTarget.value = '';
  };

  return (
    <div className="disc-shell">
      {/* ── KPI Row ── */}
      <div className="disc-kpi-row">
        <DiscoveryKPICard
          label="DISCOVERED INVENTORY"
          value={`${discoveredProjects.length} Project${discoveredProjects.length !== 1 ? 's' : ''}`}
          subValue="Discovered via GCP / ZIP"
          accent="blue"
          icon={
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#2563eb" strokeWidth="2">
              <circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" />
            </svg>
          }
        />
        <DiscoveryKPICard
          label="ADDED TO ACTIVE BUCKET"
          value={`${quotaUsed} Selected`}
          subValue="Ready for Ingestion"
          accent="green"
          icon={
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#16a34a" strokeWidth="2">
              <polyline points="20 6 9 17 4 12" />
            </svg>
          }
        />
        <DiscoveryKPICard
          label="UNASSIGNED / REMAINING"
          value={unassigned > 0 ? `${unassigned} Leftover` : '0 Remaining'}
          subValue={unassigned > 0 ? 'Available for Next Batch' : 'All assigned'}
          accent={unassigned > 0 ? 'orange' : 'blue'}
          icon={
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke={unassigned > 0 ? '#f59e0b' : '#2563eb'} strokeWidth="2">
              <circle cx="12" cy="12" r="10" /><line x1="12" y1="8" x2="12" y2="12" /><line x1="12" y1="16" x2="12.01" y2="16" />
            </svg>
          }
        />
        <DiscoveryKPICard
          label="ACTIVE SUBSCRIPTION QUOTA"
          value={`${quotaUsed} / ${quotaTotal} Slots`}
          subValue="Enterprise Tier Active"
          accent="purple"
          icon={
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#7c3aed" strokeWidth="2">
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
            </svg>
          }
        />
      </div>

      {/* ── Main 2-column layout ── */}
      <div className="disc-main">
        {/* ─ Left: Inventory Table ─ */}
        <div className="disc-left">
          <div className="disc-panel">
            <div className="disc-panel-header">
              <div>
                <h2 className="disc-panel-title">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#2563eb" strokeWidth="2" style={{ verticalAlign: 'middle', marginRight: 8 }}>
                    <circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" />
                  </svg>
                  Discovered Portfolio Inventory
                </h2>
                <p className="disc-panel-subtitle">
                  Fetch projects from connected GCP environment or upload DFCX / Playbook ZIP exports.
                </p>
              </div>
              <div className="disc-panel-actions">
                <button
                  className="disc-btn disc-btn--primary"
                  onClick={onFetchGcpProjects}
                  type="button"
                >
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ marginRight: 6, verticalAlign: 'text-bottom' }}>
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" /><polyline points="17 8 12 3 7 8" /><line x1="12" y1="3" x2="12" y2="15" />
                  </svg>
                  Fetch GCP Projects
                </button>
                <button
                  className="disc-btn disc-btn--secondary"
                  onClick={() => fileInputRef.current?.click()}
                  type="button"
                >
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ marginRight: 6, verticalAlign: 'text-bottom' }}>
                    <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" />
                  </svg>
                  Upload Project ZIP
                </button>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".zip"
                  multiple
                  className="disc-hidden-input"
                  onChange={handleFileChange}
                />
              </div>
            </div>

            {/* Table */}
            <div className="disc-table-wrapper">
              <table className="disc-table" role="grid">
                <thead>
                  <tr>
                    <th className="disc-th disc-th--check">
                      <input
                        type="checkbox"
                        checked={allChecked}
                        onChange={(e) => onSelectAll(e.target.checked)}
                        className="disc-checkbox"
                        aria-label="Select all projects"
                        disabled={discoveredProjects.length === 0}
                      />
                    </th>
                    <th className="disc-th">PROJECT / AGENT NAME</th>
                    <th className="disc-th">SOURCE TYPE</th>
                    <th className="disc-th">CATEGORIZATION STATUS</th>
                    <th className="disc-th">CATEGORIZATION MATRIX</th>
                    <th className="disc-th">ACTION</th>
                  </tr>
                </thead>
                <tbody>
                  {discoveredProjects.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="disc-td disc-td--empty">
                        No projects yet — upload a ZIP or fetch from GCP.
                      </td>
                    </tr>
                  ) : (
                    discoveredProjects.map((p) => (
                      <ProjectRow
                        key={p.id}
                        project={p}
                        onToggle={onToggleSelect}
                        onInspect={() => {/* no-op for now */}}
                      />
                    ))
                  )}
                </tbody>
              </table>
            </div>

            {/* Footer */}
            <div className="disc-table-footer">
              <span className="disc-table-hint">
                Select items and click Analyze to classify complexity matrix.
              </span>
              <button
                className="disc-btn disc-btn--analyze"
                onClick={onAnalyze}
                type="button"
                disabled={selectedProjects.length === 0}
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ marginRight: 6, verticalAlign: 'text-bottom' }}>
                  <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
                </svg>
                Analyze Selected Projects
              </button>
            </div>
          </div>
        </div>

        {/* ─ Right: Bucket Configuration ─ */}
        <div className="disc-right">
          <div className="disc-panel disc-panel--bucket">
            <div className="disc-bucket-header">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#2563eb" strokeWidth="2" aria-hidden="true">
                <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
              </svg>
              <span>ACTIVE BUCKET CONFIGURATION</span>
            </div>

            <div className="disc-bucket-section">
              <label className="disc-field-label">CUSTOM BUCKET NAME</label>
              <input
                className="disc-bucket-name-input"
                value={bucketName}
                onChange={(e) => onBucketNameChange(e.target.value)}
                placeholder="BUCKET_ENTERPRISE_BATCH"
              />
            </div>

            <div className="disc-bucket-section">
              <div className="disc-quota-header">
                <span className="disc-quota-label">Subscription Quota Allocation</span>
                <span className="disc-quota-count">
                  <strong>{quotaUsed} / {quotaTotal}</strong> Slots Selected
                </span>
              </div>
              <div className="disc-quota-bar-track">
                <div
                  className="disc-quota-bar-fill"
                  style={{ width: `${Math.min(quotaPercent, 100)}%` }}
                />
              </div>
            </div>

            <div className="disc-bucket-section">
              <div className="disc-tier-label">TIER-WISE QUOTA ALLOWANCE:</div>
              <div className="disc-tier-grid">
                {tiers.map((t) => (
                  <div key={t.label} className="disc-tier-cell">
                    <div className="disc-tier-name">{t.label.toUpperCase()}</div>
                    <div className="disc-tier-count">
                      {t.used} / {t.total}
                      {t.used < t.total && (
                        <span className="disc-tier-left"> ({t.total - t.used} Left)</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
              <div className="disc-tier-status">
                <span className="disc-tier-status-dot" />
                Status: <span>Validated against Tier Quota</span>
                {unassigned > 0 && <span className="disc-tier-leftover">&nbsp;{unassigned} Leftover</span>}
              </div>
            </div>

            <div className="disc-bucket-section disc-bucket-section--selected">
                <div className="disc-selected-label">SELECTED PROJECTS IN BUCKET:</div>
                <div className="disc-selected-chips disc-selected-chips--scroll">
                  {selectedProjects.length > 0 ? (
                    selectedProjects.map((p) => (
                      <span key={p.id} className="disc-chip">{p.name}</span>
                    ))
                  ) : (
                    <div className="disc-selected-empty">No projects selected yet.</div>
                  )}
                </div>
              </div>

            <button
              className="disc-lock-btn"
              onClick={onLockBucket}
              type="button"
              disabled={selectedProjects.length === 0 || !bucketName.trim()}
            >
              Lock Bucket &amp; Proceed →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default PortfolioDiscoveryPage;
