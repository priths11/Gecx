import { useState, useEffect } from 'react';
import { saveConfig } from '../api/migrationApi';
import { useToast } from '../context/ToastContext';
import { InfoTooltip, HITL_SSOT_TOOLTIP_TEXT, HITL_GECX_TOOLTIP_TEXT, AGENT_BUILDER_TOOLTIP_TEXT } from '../constants/tooltipConstants';
import './css/ConfigurationDrawer.css';

interface ConfigErrors {
  projectName?: string;
  project?: string;
  location?: string;
  serviceAccount?: string;
  dataOutputDirectory?: string;
  bucket?: string;
  datasetName?: string;
  ssotModel?: string;
  ssotTopP?: string;
  ssotCand?: string;
  ssotMaxOutput?: string;
  ssotTopK?: string;
  ssotTemp?: string;
  gecxModel?: string;
  gecxTopP?: string;
  gecxCand?: string;
  gecxMaxOutput?: string;
  gecxTopK?: string;
  gecxTemp?: string;
  abModel?: string;
  abTopP?: string;
  abCand?: string;
  abMaxOutput?: string;
  abTopK?: string;
  abTemp?: string;
}

function ConfigurationDrawer({ isOpen, onClose, user, globalConfig, onConfigSaved }: any) {
  // Local state for configuration fields
  const [projectName, setProjectName] = useState('');
  const [project, setProject] = useState('');
  const [location, setLocation] = useState('');
  const [serviceAccount, setServiceAccount] = useState('');
  const [dataOutputDirectory, setDataOutputDirectory] = useState('');
  const [datasetName, setDatasetName] = useState('');
  const [bucket, setBucket] = useState('');

  const { showToast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState<ConfigErrors>({});

  // HITL S.S.O.T fields
  const [ssotModel, setSsotModel] = useState('');
  const [ssotTopP, setSsotTopP] = useState('');
  const [ssotCand, setSsotCand] = useState('');
  const [ssotMaxOutput, setSsotMaxOutput] = useState('');
  const [ssotTopK, setSsotTopK] = useState('');
  const [ssotTemp, setSsotTemp] = useState('');

  // HITL GECX fields
  const [gecxModel, setGecxModel] = useState('');
  const [gecxTopP, setGecxTopP] = useState('');
  const [gecxCand, setGecxCand] = useState('');
  const [gecxMaxOutput, setGecxMaxOutput] = useState('');
  const [gecxTopK, setGecxTopK] = useState('');
  const [gecxTemp, setGecxTemp] = useState('');

  // Agent Builder fields
  const [abModel, setAbModel] = useState('');
  const [abTopP, setAbTopP] = useState('');
  const [abCand, setAbCand] = useState('');
  const [abMaxOutput, setAbMaxOutput] = useState('');
  const [abTopK, setAbTopK] = useState('');
  const [abTemp, setAbTemp] = useState('');

  const [projectId, setProjectId] = useState('');
  const [selectedConfigIndex, setSelectedConfigIndex] = useState(0);

  // Helper: clear a single field error when user starts typing
  const clearError = (field: keyof ConfigErrors) => {
    if (errors[field]) setErrors(prev => ({ ...prev, [field]: '' }));
  };

  useEffect(() => {
    if (globalConfig) {
      let conf = globalConfig;
      if (Array.isArray(globalConfig) && globalConfig.length > 0) {
        conf = globalConfig[selectedConfigIndex] || globalConfig[0];
      }

      if (!conf) return;

      // Populate main config
      const mConf = conf.migration_config || {};
      const bConf = conf.bootstrap_status || {};
      const prConf = conf.project_registration || {};

      setProjectName(mConf.project_name || bConf.project_name || prConf.project_name || '');
      setLocation(mConf.location || '');
      setBucket(mConf.bucket_name || bConf.customer_bucket || '');
      setDataOutputDirectory(mConf.output_dir || '');
      setServiceAccount(mConf.service_account_name || bConf.service_account_name || prConf.service_account_name || '');

      // Target mConf.id first, but fallback to project_id in bootstrap or registration
      if (mConf.id) {
        setProjectId(String(mConf.id));
      } else if (bConf.project_id) {
        setProjectId(String(bConf.project_id));
      } else if (prConf.project_id) {
        setProjectId(String(prConf.project_id));
      } else {
        setProjectId('');
      }

      setProject(mConf.customer_project_id || bConf.customer_project_id || '');
      setDatasetName(mConf.customer_dataset || bConf.customer_dataset || '');

      // Output 1
      const o1 = conf.output1_model || {};
      setSsotModel(o1.model || '');
      setSsotTopP(o1.top_p !== undefined && o1.top_p !== null ? String(o1.top_p) : '');
      setSsotCand(o1.candidate_count !== undefined && o1.candidate_count !== null ? String(o1.candidate_count) : '');
      setSsotMaxOutput(o1.max_output_token !== undefined && o1.max_output_token !== null ? String(o1.max_output_token) : '');
      setSsotTopK(o1.top_k !== undefined && o1.top_k !== null ? String(o1.top_k) : '');
      setSsotTemp(o1.temperature !== undefined && o1.temperature !== null ? String(o1.temperature) : '');

      // Output 2
      const o2 = conf.output2_model || {};
      setGecxModel(o2.model || '');
      setGecxTopP(o2.top_p !== undefined && o2.top_p !== null ? String(o2.top_p) : '');
      setGecxCand(o2.candidate_count !== undefined && o2.candidate_count !== null ? String(o2.candidate_count) : '');
      setGecxMaxOutput(o2.max_output_token !== undefined && o2.max_output_token !== null ? String(o2.max_output_token) : '');
      setGecxTopK(o2.top_k !== undefined && o2.top_k !== null ? String(o2.top_k) : '');
      setGecxTemp(o2.temperature !== undefined && o2.temperature !== null ? String(o2.temperature) : '');

      // Agent Builder
      const ab = conf.agent_builder_model || {};
      setAbModel(ab.model || '');
      setAbTopP(ab.top_p !== undefined && ab.top_p !== null ? String(ab.top_p) : '');
      setAbCand(ab.candidate_count !== undefined && ab.candidate_count !== null ? String(ab.candidate_count) : '');
      setAbMaxOutput(ab.max_output_token !== undefined && ab.max_output_token !== null ? String(ab.max_output_token) : '');
      setAbTopK(ab.top_k !== undefined && ab.top_k !== null ? String(ab.top_k) : '');
      setAbTemp(ab.temperature !== undefined && ab.temperature !== null ? String(ab.temperature) : '');

      // Once API data is loaded, clear any stale validation errors
      setErrors({});
    }
  }, [globalConfig, selectedConfigIndex]);

  const validate = (): boolean => {
    const newErrors: ConfigErrors = {};
    if (!projectName.trim()) newErrors.projectName = 'Project Name is required';
    if (!project.trim()) newErrors.project = 'GCP Project ID is required';
    if (!location.trim()) newErrors.location = 'Location/Region is required';
    if (!serviceAccount.trim()) newErrors.serviceAccount = 'Service Account Name is required';
    if (!dataOutputDirectory.trim()) newErrors.dataOutputDirectory = 'Data Output Directory is required';
    if (!bucket.trim()) newErrors.bucket = 'GCS Bucket is required';
    if (!datasetName.trim()) newErrors.datasetName = 'Dataset Name is required';

    if (!ssotModel) newErrors.ssotModel = 'Model is required';
    if (!ssotTopP.trim()) newErrors.ssotTopP = 'Top P is required';
    if (!ssotCand.trim()) newErrors.ssotCand = 'Candidate Count is required';
    if (!ssotMaxOutput.trim()) newErrors.ssotMaxOutput = 'Output Tokens is required';
    if (!ssotTopK.trim()) newErrors.ssotTopK = 'Top K is required';
    if (!ssotTemp.trim()) newErrors.ssotTemp = 'Temperature is required';

    if (!gecxModel) newErrors.gecxModel = 'Model is required';
    if (!gecxTopP.trim()) newErrors.gecxTopP = 'Top P is required';
    if (!gecxCand.trim()) newErrors.gecxCand = 'Candidate Count is required';
    if (!gecxMaxOutput.trim()) newErrors.gecxMaxOutput = 'Output Tokens is required';
    if (!gecxTopK.trim()) newErrors.gecxTopK = 'Top K is required';
    if (!gecxTemp.trim()) newErrors.gecxTemp = 'Temperature is required';

    if (!abModel) newErrors.abModel = 'Model is required';
    if (!abTopP.trim()) newErrors.abTopP = 'Top P is required';
    if (!abCand.trim()) newErrors.abCand = 'Candidate Count is required';
    if (!abMaxOutput.trim()) newErrors.abMaxOutput = 'Output Tokens is required';
    if (!abTopK.trim()) newErrors.abTopK = 'Top K is required';
    if (!abTemp.trim()) newErrors.abTemp = 'Temperature is required';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSave = async () => {
    if (!user?.email) {
      showToast('User email not found. Please log in again.', 'error');
      return;
    }

    if (!validate()) return;

    setIsLoading(true);
    const payload: any = {
      name: "",
      project_name: projectName,
      customer_project_id: project,
      customer_dataset: datasetName,
      location: location,
      bucket_name: bucket,
      output_dir: dataOutputDirectory,
      service_account_name: serviceAccount,
      output1_model: {
        model: ssotModel,
        top_p: parseFloat(ssotTopP) || 0.95,
        top_k: parseInt(ssotTopK, 10) || 40,
        max_output_token: parseInt(ssotMaxOutput, 10) || 8192,
        temperature: parseFloat(ssotTemp) || 0,
        candidate_count: parseInt(ssotCand, 10) || 1
      },
      output2_model: {
        model: gecxModel,
        top_p: parseFloat(gecxTopP) || 0.95,
        top_k: parseInt(gecxTopK, 10) || 40,
        max_output_token: parseInt(gecxMaxOutput, 10) || 8192,
        temperature: parseFloat(gecxTemp) || 0,
        candidate_count: parseInt(gecxCand, 10) || 1
      },
      agent_builder_model: {
        model: abModel,
        top_p: parseFloat(abTopP) || 0.9,
        top_k: parseInt(abTopK, 10) || 40,
        max_output_token: parseInt(abMaxOutput, 10) || 8192,
        temperature: parseFloat(abTemp) || 0.2,
        candidate_count: parseInt(abCand, 10) || 1
      },
      user_id: "",
      user_email: user.email,
      role: "OWNER"
    };

    try {
      const res = await saveConfig(payload);
      if (res.status === 'success') {
        showToast('Configuration saved successfully!', 'success');
        // Ensure we pass back an array since App.tsx expects an array for globalConfig
        const updatedArray = res.data ? (Array.isArray(res.data) ? res.data : [res.data]) : [payload];
        if (onConfigSaved) onConfigSaved(updatedArray);
        onClose();
      } else {
        showToast(res.message || 'Failed to save configuration.', 'error');
      }
    } catch (err: any) {
      showToast(err.message || 'Error communicating with server.', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <aside className={`config-side-panel ${isOpen ? 'open' : ''}`}>
      <div className="config-panel-blur" onClick={onClose} />
      <div className="config-panel-inner">
        <div className="config-panel-header">
          <h3>Advanced Configurations</h3>
          <button className="config-close-btn" onClick={onClose}>&times;</button>
        </div>

        <div className="config-panel-scroll">
          {/* ── CX Migration Configurations ── */}
          <div className="config-block main-config-block">
            <h3>CX Migration Configurations</h3>

            {Array.isArray(globalConfig) && globalConfig.length > 0 && (
              <div className="config-field" style={{ marginBottom: '16px', maxWidth: '400px' }}>
                <label className="pill-label" style={{ background: '#fef3c7', color: '#92400e !important' }}>Switch Configuration Profile</label>
                <select
                  value={selectedConfigIndex}
                  className="model-dropdown"
                  onChange={e => {
                    const idx = parseInt(e.target.value, 10);
                    setSelectedConfigIndex(idx);
                    clearError('projectName');
                  }}
                >
                  {globalConfig.map((cfg: any, index: number) => (
                    <option key={index} value={index}>
                      {cfg.migration_config?.project_name || cfg.bootstrap_status?.project_name || `Configuration ${index + 1}`}
                    </option>
                  ))}
                </select>
              </div>
            )}

            <div className="config-grid-3">
              <div className="config-field">
                <label className="pill-label">Project Name <span className="required-star">*</span></label>
                <input
                  type="text"
                  value={projectName}
                  placeholder="Enter project name..."
                  className={errors.projectName ? 'error-input' : ''}
                  onChange={e => { setProjectName(e.target.value); clearError('projectName'); }}
                />
                {errors.projectName && <span className="field-error-text">{errors.projectName}</span>}
              </div>
              <div className="config-field">
                <label className="pill-label">GCP Project ID <span className="required-star">*</span><div className="tooltip-container" style={{ position: 'relative', display: 'flex', alignItems: 'center' }}>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#4338ca" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ cursor: 'help' }}>
                    <circle cx="12" cy="12" r="10"></circle>
                    <line x1="12" y1="16" x2="12" y2="12"></line>
                    <line x1="12" y1="8" x2="12.01" y2="8"></line>
                  </svg>
                  <div className="tooltip-content">
                    <ul style={{ margin: 0, paddingLeft: '20px', display: 'flex', flexDirection: 'column', gap: '6px' }}>
                      <li><b>Project ID:</b><br />A Project ID is a globally unique, permanent alphanumeric string used to identify your project across Google Cloud, while the Location specifies the physical regional or zonal area where your specific resources are hosted.</li>
                    </ul>
                    <div style={{ marginTop: '10px', color: '#fbbf24', fontWeight: '500' }}>If any of these permissions are missing, setup or execution may fail.</div>
                  </div>
                </div></label>
                <input
                  type="text"
                  value={project}
                  className={errors.project ? 'error-input' : ''}
                  onChange={e => { setProject(e.target.value); clearError('project'); }}
                />
                {errors.project && <span className="field-error-text">{errors.project}</span>}
              </div>
              <div className="config-field">
                <label className="pill-label">Location/Region <span className="required-star">*</span><div className="tooltip-container" style={{ position: 'relative', display: 'flex', alignItems: 'center' }}>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#4338ca" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ cursor: 'help' }}>
                    <circle cx="12" cy="12" r="10"></circle>
                    <line x1="12" y1="16" x2="12" y2="12"></line>
                    <line x1="12" y1="8" x2="12.01" y2="8"></line>
                  </svg>
                  <div className="tooltip-content">
                    <ul style={{ margin: 0, paddingLeft: '20px', display: 'flex', flexDirection: 'column', gap: '6px' }}>
                      <li><b>Location:</b><br />The specific data center location (e.g., us-central1) that determines your data's latency, availability, and cost.</li>
                    </ul>
                    <div style={{ marginTop: '10px', color: '#fbbf24', fontWeight: '500' }}>If any of these permissions are missing, setup or execution may fail.</div>
                  </div>
                </div></label>
                <input
                  type="text"
                  value={location}
                  className={errors.location ? 'error-input' : ''}
                  onChange={e => { setLocation(e.target.value); clearError('location'); }}
                />
                {errors.location && <span className="field-error-text">{errors.location}</span>}
              </div>
              <div className="config-field">
                <label className="pill-label" style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                  Service Account Name <span className="required-star">*</span>
                  <div className="tooltip-container" style={{ position: 'relative', display: 'flex', alignItems: 'center' }}>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#4338ca" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ cursor: 'help' }}>
                      <circle cx="12" cy="12" r="10"></circle>
                      <line x1="12" y1="16" x2="12" y2="12"></line>
                      <line x1="12" y1="8" x2="12.01" y2="8"></line>
                    </svg>
                    <div className="tooltip-content">
                      <div className="tooltip-header">Required Service Account Permissions</div>
                      <div style={{ marginBottom: '10px' }}>Enter a service account that has the required access in your GCP project. This service account is used to create and manage the resources needed for migration and agent build flows.</div>
                      <ul style={{ margin: 0, paddingLeft: '20px', display: 'flex', flexDirection: 'column', gap: '6px' }}>
                        <li><b>roles/bigquery.dataEditor</b><br />Create and update BigQuery tables and write migration/build data.</li>
                        <li><b>roles/bigquery.user</b><br />Run BigQuery jobs and access datasets.</li>
                        <li><b>roles/storage.admin</b><br />Create and manage Cloud Storage buckets, folders, and files.</li>
                        <li><b>roles/aiplatform.user</b><br />Use Vertex AI models for content generation.</li>
                        <li><b>CES / CX access roles</b><br />Required for CX Studio app, tool, and agent creation flows.</li>
                        <li><b>roles/iam.serviceAccountTokenCreator</b><br />Must be granted to the Cloud Run runtime service account on this service account so the application can impersonate it securely.</li>
                      </ul>
                      <div style={{ marginTop: '10px', color: '#fbbf24', fontWeight: '500' }}>If any of these permissions are missing, setup or execution may fail.</div>
                    </div>
                  </div>
                </label>
                <input
                  type="text"
                  value={serviceAccount}
                  className={errors.serviceAccount ? 'error-input' : ''}
                  onChange={e => { setServiceAccount(e.target.value); clearError('serviceAccount'); }}
                />
                {errors.serviceAccount && <span className="field-error-text">{errors.serviceAccount}</span>}
              </div>

              <div className="config-field">
                <label className="pill-label">Data Output Directory <span className="required-star">*</span></label>
                <input
                  type="text"
                  value={dataOutputDirectory}
                  className={errors.dataOutputDirectory ? 'error-input' : ''}
                  onChange={e => { setDataOutputDirectory(e.target.value); clearError('dataOutputDirectory'); }}
                />
                {errors.dataOutputDirectory && <span className="field-error-text">{errors.dataOutputDirectory}</span>}
              </div>
              <div className="config-field">
                <label className="pill-label">GCS Bucket <span className="required-star">*</span><div className="tooltip-container" style={{ position: 'relative', display: 'flex', alignItems: 'center' }}>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#4338ca" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ cursor: 'help' }}>
                    <circle cx="12" cy="12" r="10"></circle>
                    <line x1="12" y1="16" x2="12" y2="12"></line>
                    <line x1="12" y1="8" x2="12.01" y2="8"></line>
                  </svg>
                  <div className="tooltip-content">
                    <div className="tooltip-header">Cloud Storage Bucket Name</div>
                    <div style={{ marginBottom: '10px' }}>Bucket name is the Cloud Storage bucket where uploaded DFCX zip files and generated migration artifacts will be stored.</div>
                    <ul style={{ margin: 0, paddingLeft: '20px', display: 'flex', flexDirection: 'column', gap: '6px' }}>
                      <li>Must be globally unique across all Google Cloud Storage users.</li>
                      <li>Can contain lowercase letters, numbers, hyphens, underscores, and dots: a-z, 0-9, -, _, .</li>
                      <li>Must start and end with a letter or number.</li>
                      <li>Length must be 3 to 63 characters.</li>
                      <li>If dots are used, the full name can be up to 222 characters, but each dot-separated section must be no more than 63 characters.</li>
                      <li>Uppercase letters are not allowed.</li>
                      <li>Spaces are not allowed.</li>
                      <li>Bucket name cannot look like an IP address. Example: 192.168.1.1 is not valid.</li>
                      <li>Bucket name cannot start with goog.</li>
                      <li>Bucket name cannot contain google or close misspellings like g00gle.</li>
                      <li>Avoid using dots unless you need a domain-style bucket, because dot-based names may require domain verification.</li>
                      <li>Avoid PII such as user emails, phone numbers, or personal names because bucket names are publicly visible.</li>
                      <li>Recommended naming pattern: cx-migration-company-env-unique-suffix</li>
                      <li>Example valid values: cx-migration-ss, cx-migration-test, cx-migration-fb-dev-001</li>
                    </ul>
                    <div style={{ marginTop: '10px', color: '#fbbf24', fontWeight: '500' }}>If any of these permissions are missing, setup or execution may fail.</div>
                  </div>
                </div></label>
                <input
                  type="text"
                  value={bucket}
                  className={errors.bucket ? 'error-input' : ''}
                  onChange={e => { setBucket(e.target.value); clearError('bucket'); }}
                />
                {errors.bucket && <span className="field-error-text">{errors.bucket}</span>}
              </div>
              <div className="config-field">
                <label className="pill-label">Dataset Name <span className="required-star">*</span><div className="tooltip-container" style={{ position: 'relative', display: 'flex', alignItems: 'center' }}>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#4338ca" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ cursor: 'help' }}>
                    <circle cx="12" cy="12" r="10"></circle>
                    <line x1="12" y1="16" x2="12" y2="12"></line>
                    <line x1="12" y1="8" x2="12.01" y2="8"></line>
                  </svg>
                  <div className="tooltip-content">
                    <div className="tooltip-header">BigQuery Dataset Name</div>
                    <div style={{ marginBottom: '10px' }}>Dataset name is the BigQuery dataset that will store migration config, model details, job metadata, and reporting data.</div>
                    <ul style={{ margin: 0, paddingLeft: '20px', display: 'flex', flexDirection: 'column', gap: '6px' }}>
                      <li>Must be unique within the selected GCP project.</li>
                      <li>Can contain letters, numbers, and underscores: A-Z, a-z, 0-9, _.</li>
                      <li>Maximum length: 1024 characters.</li>
                      <li>Spaces are not allowed.</li>
                      <li>Hyphens are not allowed. Example: DFCX-To-CX-Migration is not valid.</li>
                      <li>Special characters like &, @, %, ., /, and - are not allowed.</li>
                      <li>Dataset names are case-sensitive by default. Example: Migration_Data and migration_data can be treated as different datasets.</li>
                      <li>Avoid starting with _ because BigQuery treats it as a hidden dataset.</li>
                      <li>Recommended naming pattern: DFCX_To_CX_Migration_CompanyOrEnvironment</li>
                      <li>Example valid values: DFCX_To_CX_Migration_Dev, first_bank_migration_dev</li>
                    </ul>
                    <div style={{ marginTop: '10px', color: '#fbbf24', fontWeight: '500' }}>If any of these permissions are missing, setup or execution may fail.</div>
                  </div>
                </div></label>
                <input
                  type="text"
                  value={datasetName}
                  className={errors.datasetName ? 'error-input' : ''}
                  onChange={e => { setDatasetName(e.target.value); clearError('datasetName'); }}
                />
                {errors.datasetName && <span className="field-error-text">{errors.datasetName}</span>}
              </div>
            </div>
          </div>

          {/* ── 3 model config blocks side by side ── */}
          <div className="hitl-blocks-container">

            {/* HITL S.S.O.T */}
            <div className="config-block hitl-block">
              <h3 style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                HITL SSOT
                <InfoTooltip content={HITL_SSOT_TOOLTIP_TEXT.HEADING} />
              </h3>
              <div className="config-grid-3-mini">
                <div className="config-field">
                  <label className="pill-label" style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                    Model <span className="required-star">*</span>
                    <InfoTooltip content={HITL_SSOT_TOOLTIP_TEXT.MODEL} />
                  </label>
                  <select
                    value={ssotModel}
                    className={`model-dropdown${errors.ssotModel ? ' error-input' : ''}`}
                    onChange={e => { setSsotModel(e.target.value); clearError('ssotModel'); }}
                  >
                    <option value="" disabled>Select model</option>
                    <option value="gemini-2.5-pro">Gemini 2.5 Pro</option>
                    <option value="gemini-2.5-flash">Gemini 2.5 Flash</option>
                    <option value="gemini-1.5-pro">Gemini 1.5 Pro</option>
                    <option value="gemini-1.5-flash">Gemini 1.5 Flash</option>
                  </select>
                  {errors.ssotModel && <span className="field-error-text">{errors.ssotModel}</span>}
                </div>
                <div className="config-field">
                  <label className="pill-label" style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                    Top P <span className="required-star">*</span>
                    <InfoTooltip content={HITL_SSOT_TOOLTIP_TEXT.TOP_P} />
                  </label>
                  <input type="number" step="0.01" value={ssotTopP} className={errors.ssotTopP ? 'error-input' : ''} onChange={e => { setSsotTopP(e.target.value); clearError('ssotTopP'); }} />
                  {errors.ssotTopP && <span className="field-error-text">{errors.ssotTopP}</span>}
                </div>
                <div className="config-field">
                  <label className="pill-label" style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                    Candidate Count <span className="required-star">*</span>
                    <InfoTooltip content={HITL_SSOT_TOOLTIP_TEXT.CANDIDATE_COUNT} />
                  </label>
                  <input type="number" value={ssotCand} className={errors.ssotCand ? 'error-input' : ''} onChange={e => { setSsotCand(e.target.value); clearError('ssotCand'); }} />
                  {errors.ssotCand && <span className="field-error-text">{errors.ssotCand}</span>}
                </div>
                <div className="config-field">
                  <label className="pill-label" style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                    Output Tokens <span className="required-star">*</span>
                    <InfoTooltip content={HITL_SSOT_TOOLTIP_TEXT.OUTPUT_TOKENS} />
                  </label>
                  <input type="number" value={ssotMaxOutput} className={errors.ssotMaxOutput ? 'error-input' : ''} onChange={e => { setSsotMaxOutput(e.target.value); clearError('ssotMaxOutput'); }} />
                  {errors.ssotMaxOutput && <span className="field-error-text">{errors.ssotMaxOutput}</span>}
                </div>
                <div className="config-field">
                  <label className="pill-label" style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                    Top K <span className="required-star">*</span>
                    <InfoTooltip content={HITL_SSOT_TOOLTIP_TEXT.TOP_K} />
                  </label>
                  <input type="number" value={ssotTopK} className={errors.ssotTopK ? 'error-input' : ''} onChange={e => { setSsotTopK(e.target.value); clearError('ssotTopK'); }} />
                  {errors.ssotTopK && <span className="field-error-text">{errors.ssotTopK}</span>}
                </div>
                <div className="config-field">
                  <label className="pill-label" style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                    Temperature <span className="required-star">*</span>
                    <InfoTooltip content={HITL_SSOT_TOOLTIP_TEXT.TEMPERATURE} />
                  </label>
                  <input type="number" step="0.1" value={ssotTemp} className={errors.ssotTemp ? 'error-input' : ''} onChange={e => { setSsotTemp(e.target.value); clearError('ssotTemp'); }} />
                  {errors.ssotTemp && <span className="field-error-text">{errors.ssotTemp}</span>}
                </div>
              </div>
            </div>

            {/* HITL GECX */}
            <div className="config-block hitl-block">
              <h3 style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                HITL GECX
                <InfoTooltip content={HITL_GECX_TOOLTIP_TEXT.HEADING} />
              </h3>
              <div className="config-grid-3-mini">
                <div className="config-field">
                  <label className="pill-label" style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                    Model <span className="required-star">*</span>
                    <InfoTooltip content={HITL_GECX_TOOLTIP_TEXT.MODEL} />
                  </label>
                  <select
                    value={gecxModel}
                    className={`model-dropdown${errors.gecxModel ? ' error-input' : ''}`}
                    onChange={e => { setGecxModel(e.target.value); clearError('gecxModel'); }}
                  >
                    <option value="" disabled>Select model</option>
                    <option value="gemini-2.5-pro">Gemini 2.5 Pro</option>
                    <option value="gemini-2.5-flash">Gemini 2.5 Flash</option>
                    <option value="gemini-1.5-pro">Gemini 1.5 Pro</option>
                    <option value="gemini-1.5-flash">Gemini 1.5 Flash</option>
                  </select>
                  {errors.gecxModel && <span className="field-error-text">{errors.gecxModel}</span>}
                </div>
                <div className="config-field">
                  <label className="pill-label" style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                    Top P <span className="required-star">*</span>
                    <InfoTooltip content={HITL_GECX_TOOLTIP_TEXT.TOP_P} />
                  </label>
                  <input type="number" step="0.01" value={gecxTopP} className={errors.gecxTopP ? 'error-input' : ''} onChange={e => { setGecxTopP(e.target.value); clearError('gecxTopP'); }} />
                  {errors.gecxTopP && <span className="field-error-text">{errors.gecxTopP}</span>}
                </div>
                <div className="config-field">
                  <label className="pill-label" style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                    Candidate Count <span className="required-star">*</span>
                    <InfoTooltip content={HITL_GECX_TOOLTIP_TEXT.CANDIDATE_COUNT} />
                  </label>
                  <input type="number" value={gecxCand} className={errors.gecxCand ? 'error-input' : ''} onChange={e => { setGecxCand(e.target.value); clearError('gecxCand'); }} />
                  {errors.gecxCand && <span className="field-error-text">{errors.gecxCand}</span>}
                </div>
                <div className="config-field">
                  <label className="pill-label" style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                    Output Tokens <span className="required-star">*</span>
                    <InfoTooltip content={HITL_GECX_TOOLTIP_TEXT.OUTPUT_TOKENS} />
                  </label>
                  <input type="number" value={gecxMaxOutput} className={errors.gecxMaxOutput ? 'error-input' : ''} onChange={e => { setGecxMaxOutput(e.target.value); clearError('gecxMaxOutput'); }} />
                  {errors.gecxMaxOutput && <span className="field-error-text">{errors.gecxMaxOutput}</span>}
                </div>
                <div className="config-field">
                  <label className="pill-label" style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                    Top K <span className="required-star">*</span>
                    <InfoTooltip content={HITL_GECX_TOOLTIP_TEXT.TOP_K} />
                  </label>
                  <input type="number" value={gecxTopK} className={errors.gecxTopK ? 'error-input' : ''} onChange={e => { setGecxTopK(e.target.value); clearError('gecxTopK'); }} />
                  {errors.gecxTopK && <span className="field-error-text">{errors.gecxTopK}</span>}
                </div>
                <div className="config-field">
                  <label className="pill-label" style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                    Temperature <span className="required-star">*</span>
                    <InfoTooltip content={HITL_GECX_TOOLTIP_TEXT.TEMPERATURE} />
                  </label>
                  <input type="number" step="0.1" value={gecxTemp} className={errors.gecxTemp ? 'error-input' : ''} onChange={e => { setGecxTemp(e.target.value); clearError('gecxTemp'); }} />
                  {errors.gecxTemp && <span className="field-error-text">{errors.gecxTemp}</span>}
                </div>
              </div>
            </div>

            {/* Agent Builder Config */}
            <div className="config-block hitl-block">
              <h3 style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                Agent Builder
                <InfoTooltip content={AGENT_BUILDER_TOOLTIP_TEXT.HEADING} />
              </h3>
              <div className="config-grid-3-mini">
                <div className="config-field">
                  <label className="pill-label" style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                    Model <span className="required-star">*</span>
                    <InfoTooltip content={AGENT_BUILDER_TOOLTIP_TEXT.MODEL} />
                  </label>
                  <select
                    value={abModel}
                    className={`model-dropdown${errors.abModel ? ' error-input' : ''}`}
                    onChange={e => { setAbModel(e.target.value); clearError('abModel'); }}
                  >
                    <option value="" disabled>Select model</option>
                    <option value="gemini-2.5-pro">Gemini 2.5 Pro</option>
                    <option value="gemini-2.5-flash">Gemini 2.5 Flash</option>
                    <option value="gemini-1.5-pro">Gemini 1.5 Pro</option>
                    <option value="gemini-1.5-flash">Gemini 1.5 Flash</option>
                  </select>
                  {errors.abModel && <span className="field-error-text">{errors.abModel}</span>}
                </div>
                <div className="config-field">
                  <label className="pill-label" style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                    Top P <span className="required-star">*</span>
                    <InfoTooltip content={AGENT_BUILDER_TOOLTIP_TEXT.TOP_P} />
                  </label>
                  <input type="number" step="0.01" value={abTopP} className={errors.abTopP ? 'error-input' : ''} onChange={e => { setAbTopP(e.target.value); clearError('abTopP'); }} />
                  {errors.abTopP && <span className="field-error-text">{errors.abTopP}</span>}
                </div>
                <div className="config-field">
                  <label className="pill-label" style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                    Candidate Count <span className="required-star">*</span>
                    <InfoTooltip content={AGENT_BUILDER_TOOLTIP_TEXT.CANDIDATE_COUNT} />
                  </label>
                  <input type="number" value={abCand} className={errors.abCand ? 'error-input' : ''} onChange={e => { setAbCand(e.target.value); clearError('abCand'); }} />
                  {errors.abCand && <span className="field-error-text">{errors.abCand}</span>}
                </div>
                <div className="config-field">
                  <label className="pill-label" style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                    Output Tokens <span className="required-star">*</span>
                    <InfoTooltip content={AGENT_BUILDER_TOOLTIP_TEXT.OUTPUT_TOKENS} />
                  </label>
                  <input type="number" value={abMaxOutput} className={errors.abMaxOutput ? 'error-input' : ''} onChange={e => { setAbMaxOutput(e.target.value); clearError('abMaxOutput'); }} />
                  {errors.abMaxOutput && <span className="field-error-text">{errors.abMaxOutput}</span>}
                </div>
                <div className="config-field">
                  <label className="pill-label" style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                    Top K <span className="required-star">*</span>
                    <InfoTooltip content={AGENT_BUILDER_TOOLTIP_TEXT.TOP_K} />
                  </label>
                  <input type="number" value={abTopK} className={errors.abTopK ? 'error-input' : ''} onChange={e => { setAbTopK(e.target.value); clearError('abTopK'); }} />
                  {errors.abTopK && <span className="field-error-text">{errors.abTopK}</span>}
                </div>
                <div className="config-field">
                  <label className="pill-label" style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                    Temperature <span className="required-star">*</span>
                    <InfoTooltip content={AGENT_BUILDER_TOOLTIP_TEXT.TEMPERATURE} />
                  </label>
                  <input type="number" step="0.1" value={abTemp} className={errors.abTemp ? 'error-input' : ''} onChange={e => { setAbTemp(e.target.value); clearError('abTemp'); }} />
                  {errors.abTemp && <span className="field-error-text">{errors.abTemp}</span>}
                </div>
              </div>
            </div>
          </div>

          {/* ── Project ID (read-only, not mandatory) ── */}
          <div className="config-block project-id-full" style={{ marginTop: '16px' }}>
            <div className="config-field">
              <label>Project ID</label>
              <div style={{ display: 'flex', gap: '8px' }}>
                <input type="text" placeholder="Project ID will be generated..." value={projectId} disabled style={{ backgroundColor: '#f1f5f9', cursor: 'not-allowed', flex: 1 }} />
                <button
                  type="button"
                  onClick={() => {
                    if (projectId) {
                      navigator.clipboard.writeText(projectId);
                      showToast('Project ID copied to clipboard!', 'success');
                    }
                  }}
                  style={{
                    padding: '8px 12px',
                    backgroundColor: '#e2e8f0',
                    border: '1px solid #cbd5e1',
                    borderRadius: '8px',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: '#475569'
                  }}
                  title="Copy Project ID"
                >
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>
                </button>
              </div>
              <span style={{ fontSize: '11px', color: '#64748b', marginTop: '4px', fontWeight: '500' }}>Note: Copy This Project ID and use this project ID while uploading a file</span>
            </div>
          </div>

          <div className="config-save-centered">
            <button type="button" className="btn-save" onClick={handleSave} disabled={isLoading}>
              {isLoading ? 'Saving...' : 'Save & Close'}
            </button>
          </div>
        </div>
      </div>
    </aside>
  );
}

export default ConfigurationDrawer;