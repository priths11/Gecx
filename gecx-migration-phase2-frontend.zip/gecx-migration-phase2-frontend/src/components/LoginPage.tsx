import React, { useEffect, useRef, useState } from 'react';
import './css/LoginPage.css';
import { initializeGoogleSignInButton, isGoogleLibraryReady } from '../googleAuth';
function LoginPage({ authEnabled, onGoogleSignIn, onGoogleError, signInSubtitle, onSignUpClick, onSignInAzure, onSignInOkta }: {
  authEnabled: boolean;
  onGoogleSignIn: (user: any) => void;
  onGoogleError: (msg: string) => void;
  signInSubtitle: string;
  onSignUpClick: () => void;
  onSignInAzure: () => void;
  onSignInOkta: () => void;
  onNavigate?: (screen: string) => void;
}) {
  const googleButtonRef = useRef(null);
  const [origin, setOrigin] = useState('');

  useEffect(() => {
    setOrigin(window.location.origin);
  }, []);

  useEffect(() => {
    if (!authEnabled || !googleButtonRef.current || !isGoogleLibraryReady()) return undefined;

    void initializeGoogleSignInButton(
      googleButtonRef.current,
      onGoogleSignIn,
      onGoogleError,
    );

    return undefined;
  }, [authEnabled, onGoogleError, onGoogleSignIn]);

  return (
    <main className="login-layout">
      <section className="login-left">
        <div className="login-left-content">
          <div className="login-icon-wrap" aria-hidden="true">
            <div className="login-icon">🤖</div>
          </div>
          <h1 className="login-heading">Next-Generation<br /><span className="highlight-text">CX Migration Engine</span></h1>
          <p className="login-subtitle">
            Seamlessly transform legacy Dialogflow state-machines into<br />dynamic Gemini agents using AI-powered automation.
          </p>
          <div className="feature-pills">
            <div className="feature-pill">
              <span className="check-icon">✓</span>
              <span>Automated<br />Discovery</span>
            </div>
            <div className="feature-pill">
              <span className="check-icon">✓</span>
              <span>SSOT<br />Generation</span>
            </div>
            <div className="feature-pill">
              <span className="check-icon">✓</span>
              <span>Agentic<br />Deployment</span>
            </div>
          </div>
        </div>
      </section>

      <section className="login-right">
        <section className="login-auth-card">
          <div className="teksystems-logo-wrap">
            <div className="teksystems-logo-mock">
              <img src="/teksystems-logo.jpeg" alt="TEKsystems logo" style={{ height: '28px', width: 'auto' }} />

              <span className="logo-tek">TEK<span className="logo-systems">systems</span></span>
            </div>
            <div className="teksystems-sub">Global Services</div>
          </div>

          <div className="auth-divider-thin" aria-hidden="true" />

          <h2 className="card-heading">Gemini Enterprise for Customer<br />Experience</h2>
          <p className="card-subheading">MIGRATION ASSISTANCE ENGINE</p>

          {!authEnabled && (
            <p className="helper">
              Google sign-in is not configured. Add `REACT_APP_GOOGLE_CLIENT_ID` in your `.env` file.
            </p>
          )}
          <p className="helper">{signInSubtitle}. Choose an existing account or use another Google account.</p>
          {process.env.NODE_ENV !== 'production' && origin && (
            <p className="helper">Current origin for Google Cloud Console: <strong>{origin}</strong></p>
          )}
          <div ref={googleButtonRef} className="google-btn" />

          <button className="azure-btn" onClick={onSignInAzure} type="button">
            <span className="azure-logo" aria-hidden="true">
              <svg width="20" height="20" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M0 0h10v10H0z" fill="#f25022" />
                <path d="M11 0h10v10H11z" fill="#7fba00" />
                <path d="M0 11h10v10H0z" fill="#00a4ef" />
                <path d="M11 11h10v10H11z" fill="#ffb900" />
              </svg>
            </span>
            <span>Microsoft</span>
          </button>

          <button className="okta-btn" onClick={onSignInOkta} type="button">
            <span className="okta-logo" aria-hidden="true">O</span>
            <span>OKTA</span>
          </button>

          <button className="saml-btn" onClick={() => { }} type="button">
            <span className="saml-logo" aria-hidden="true">S</span>
            <span>SAML</span>
          </button>

          <div className="signup-prompt">
            <span>New to the platform?</span>
            <button className="signup-link-btn" onClick={onSignUpClick} type="button">
              Create account
            </button>
          </div>

          <div className="security-badge">
            <span className="shield-icon">🛡️</span>
            <span>ENTERPRISE SECURITY</span>
          </div>

          <p className="auth-footnote">
            Strictly authorized personnel only. All parsing activities,<br />
            file uploads, and LLM token usage are actively monitored<br />
            and logged to BigQuery.
          </p>
        </section>
      </section>
    </main>
  );
}

export default LoginPage;
