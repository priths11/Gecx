import './css/JumpBar.css';

const STEPS = [
  { screen: 'discovery', label: '1. Portfolio Discovery',      icon: '🔍' },
  { screen: 'ingestion', label: '2. Data Ingestion & GCS Sync', icon: '☁️' },
  { screen: 'output1',   label: '3. HITL SSOT AST Review',     icon: '⌘'  },
  { screen: 'output2',   label: '4. HITL GECX Ready Files',    icon: '🤖' },
  { screen: 'dashboard', label: '5. Operational Reporting',    icon: '📊' },
];

interface JumpBarProps {
  onNavigate: (screen: string) => void;
  activeScreen?: string;
}

function JumpBar({ onNavigate, activeScreen }: JumpBarProps) {
  return (
    <div className="app-jumpbar" role="navigation" aria-label="Quick navigation">
      <span className="jump-label">JUMP TO:</span>
      {STEPS.map(({ screen, label, icon }) => (
        <button
          key={screen}
          className={`jump-pill jump-pill-btn${activeScreen === screen ? ' jump-pill--active' : ''}`}
          onClick={() => onNavigate(screen)}
          type="button"
          title={label}
        >
          <span className="jump-icon" aria-hidden="true">{icon}</span>
          {label}
        </button>
      ))}
    </div>
  );
}

export default JumpBar;
