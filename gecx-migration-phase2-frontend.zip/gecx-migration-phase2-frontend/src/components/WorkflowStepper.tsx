import './css/WorkflowStepper.css';

type StepState = 'active' | 'complete' | 'idle';

const STEPS = [
  { num: 1, label: '1. Portfolio Discovery',     screen: 'discovery'  },
  { num: 2, label: '2. Data Ingestion & GCS Sync', screen: 'ingestion' },
  { num: 3, label: '3. HITL SSOT AST Review',    screen: 'output1'    },
  { num: 4, label: '4. HITL GECX Ready Files',   screen: 'output2'    },
  { num: 5, label: '5. Operational Reporting',   screen: 'dashboard'  },
];

interface WorkflowStepperProps {
  activeScreen: string;
  getWorkflowStepState: (step: number) => StepState | 'synced';
  syncSucceeded: boolean;
}

function WorkflowStepper({ activeScreen, getWorkflowStepState }: WorkflowStepperProps) {
  return (
    <nav className="wf-strip" aria-label="Workflow progress">
      {STEPS.map((step, idx) => {
        const state = getWorkflowStepState(step.num);
        const isComplete = state === 'complete';
        const isActive = state === 'active';

        return (
          <div key={step.num} className="wf-step-group">
            <div className={`wf-step ${isActive ? 'wf-step--active' : ''} ${isComplete ? 'wf-step--complete' : ''}`}>
              <div className="wf-dot" aria-hidden="true">
                {isComplete ? '✓' : step.num}
              </div>
              <span className="wf-label">{step.label}</span>
            </div>
            {idx < STEPS.length - 1 && (
              <div
                className={`wf-connector${isComplete ? ' wf-connector--active' : ''}`}
                aria-hidden="true"
              />
            )}
          </div>
        );
      })}
    </nav>
  );
}

export default WorkflowStepper;
