import React from 'react';
import './css/AccountNotFoundModal.css';

interface AccountNotFoundModalProps {
  onRegister: () => void;
  onCancel: () => void;
}

const AccountNotFoundModal: React.FC<AccountNotFoundModalProps> = ({ onRegister, onCancel }) => {
  return (
    <div className="anf-modal-overlay">
      <div className="anf-modal-card">
        <div className="anf-modal-header">
          <div className="anf-welcome-text">Welcome</div>
          <div className="anf-to-text">To</div>
          <h1 className="anf-main-title">
            Next-Generation<br />
            <span className="anf-highlight">CX Migration Engine</span>
          </h1>
        </div>

        <div className="anf-modal-divider"></div>

        <div className="anf-modal-body">
          <h2 className="anf-error-title">Account Not Found</h2>
          <p className="anf-error-desc">
            It looks like you don't have an account with us yet.<br />
            Please create account.
          </p>
        </div>

        <div className="anf-modal-footer">
          <button className="anf-btn-cancel" onClick={onCancel}>
            Cancel
          </button>
          <button className="anf-btn-register" onClick={onRegister}>
            Register
          </button>
        </div>
      </div>
    </div>
  );
};

export default AccountNotFoundModal;
