import React from 'react';
import './css/AppHeader.css';

function AppHeader({ onSignOut, user, onToggleConfigs, needsConfig, onSelectProject }: { 
  onSignOut: any, 
  user: any, 
  onToggleConfigs: any, 
  needsConfig?: boolean,
  onSelectProject: (projectId: string) => void
}) {
  const displayName = user?.displayName || 'Guest';
  const initials = (displayName || user?.email || 'G')
    .split(' ')
    .map((part) => part[0])
    .join('')
    .slice(0, 2)
    .toUpperCase();

  return (
    <header className="product-header">
      <div className="product-brand">
        <div className="product-brand-icon" aria-hidden="true">
          🤖
        </div>
        <div className="product-brand-copy">
          <h1>CX Migration Engine</h1>
          <p>GCP ENTERPRISE ACCELERATOR</p>
        </div>
      </div>
      <div className="product-actions">
        <div className="profile-block">
          <div className="profile-copy">
            <strong>{displayName}</strong>
          </div>
          <div className="profile-avatar">{initials}</div>
          
          <div style={{ position: 'relative' }}>
            <button className="gear-button" onClick={onToggleConfigs} type="button" aria-label="Settings">
              <img src="/gear.png" alt="Settings" />
            </button>
            {needsConfig && (
              <div className="gear-tooltip">
                Please edit configurations
              </div>
            )}
          </div>

          <div className="insights-container">
            <button 
              className="insights-button" 
              onClick={() => onSelectProject('')} 
              type="button" 
              aria-label="Insights"
            >
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <path d="M3 3v18h18" />
                <path d="M18.7 8l-5.1 5.2-2.8-2.7L7 14.3" />
              </svg>
            </button>
          </div>

          <button className="signout-button" onClick={onSignOut} type="button" aria-label="Sign out">
            Logout
          </button>
        </div>
      </div>
    </header>
  );
}

export default AppHeader;
