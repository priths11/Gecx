import React from 'react';

interface ComplexityModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const ComplexityModal: React.FC<ComplexityModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="dashboard-modal-overlay" onClick={onClose}>
      <div className="dashboard-modal-container" onClick={e => e.stopPropagation()}>
        <div className="dashboard-modal-header">
           <div className="header-title">
             <span className="modal-icon purple">📊</span>
             <h3>Complexity Reduction Logic</h3>
           </div>
           <button className="close-btn" onClick={onClose}>&times;</button>
        </div>
        <div className="dashboard-modal-body">
          <div className="formula-section">
            <span className="formula-label">CORE FORMULA</span>
            <div className="formula-value purple">84.5%</div>
            <div className="formula-desc">(Legacy Nodes - Synthesized Goals) / Legacy Nodes</div>
          </div>
          
          <div className="stats-comparison-row">
            <div className="stat-box">
              <span className="stat-label">INPUT (LEGACY)</span>
              <div className="stat-number">420 Pages/Flows</div>
            </div>
            <div className="stat-box">
              <span className="stat-label">OUTPUT (GECX)</span>
              <div className="stat-number">65 Agentic Goals</div>
            </div>
          </div>
        </div>
        <div className="dashboard-modal-footer">
           <button className="btn-close-modal" onClick={onClose}>Close</button>
        </div>
      </div>
    </div>
  );
};

export default ComplexityModal;
