import React from 'react';

const ProcessLatencySpikes: React.FC = () => {
  return (
    <div className="latency-card">
      <div className="card-header">
        <h3>Process Latency Spikes</h3>
        <span className="badge-outline">OUTLIER DETECTION</span>
      </div>
      <div className="chart-area">
        <svg viewBox="0 0 400 300" className="scatter-svg">
          {/* Grid lines */}
          <line x1="40" y1="20" x2="40" y2="260" stroke="#e2e8f0" strokeWidth="1" />
          <line x1="40" y1="260" x2="380" y2="260" stroke="#e2e8f0" strokeWidth="1" />
          <line x1="40" y1="210" x2="380" y2="210" stroke="#f1f5f9" strokeWidth="1" />
          <line x1="40" y1="160" x2="380" y2="160" stroke="#f1f5f9" strokeWidth="1" />
          <line x1="40" y1="110" x2="380" y2="110" stroke="#f1f5f9" strokeWidth="1" />
          <line x1="40" y1="60" x2="380" y2="60" stroke="#f1f5f9" strokeWidth="1" />

          {/* Labels */}
          <text x="10" y="160" transform="rotate(-90 10,160)" className="axis-label">Time (s)</text>
          <text x="210" y="290" className="axis-label">Size (MB)</text>

          {/* Axis values */}
          <text x="35" y="265" textAnchor="end" className="tick-label">0</text>
          <text x="35" y="215" textAnchor="end" className="tick-label">50</text>
          <text x="35" y="165" textAnchor="end" className="tick-label">100</text>
          <text x="35" y="115" textAnchor="end" className="tick-label">150</text>
          <text x="35" y="65" textAnchor="end" className="tick-label">200</text>
          <text x="35" y="25" textAnchor="end" className="tick-label">250</text>

          {/* Data Points */}
          <circle cx="60" cy="220" r="6" fill="#94c1ff" opacity="0.8" />
          <circle cx="120" cy="180" r="6" fill="#94c1ff" opacity="0.8" />
          <circle cx="180" cy="150" r="6" fill="#94c1ff" opacity="0.8" />
          <circle cx="250" cy="120" r="6" fill="#94c1ff" opacity="0.8" />
          
          {/* Outlier */}
          <path d="M 330 50 L 340 65 L 330 80 L 320 65 Z" fill="#ef4444" />
        </svg>
      </div>
      <div className="alert-box error">
        <div className="alert-content">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
            <line x1="12" y1="9" x2="12" y2="13"></line>
            <line x1="12" y1="17" x2="12.01" y2="17"></line>
          </svg>
          <span className="alert-text">LATENCY SPIKE DETECTED</span>
          <p className="alert-desc">Project <b>13335</b> took 40% longer. <button className="link-button" type="button">View Spikes Detail</button></p>
        </div>
      </div>
    </div>
  );
};

export default ProcessLatencySpikes;
