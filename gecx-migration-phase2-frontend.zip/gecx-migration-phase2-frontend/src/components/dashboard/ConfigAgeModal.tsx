import React from 'react';

interface ConfigAgeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const ConfigAgeModal: React.FC<ConfigAgeModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="dashboard-modal-overlay" onClick={onClose}>
      <div className="dashboard-modal-container" onClick={e => e.stopPropagation()}>
        <div className="dashboard-modal-header">
           <div className="header-title">
             <span className="modal-icon orange">📅</span>
             <h3>Configuration Age Logic</h3>
           </div>
           <button className="close-btn" onClick={onClose}>&times;</button>
        </div>
        <div className="dashboard-modal-body">
          <div className="formula-section orange-bg">
            <span className="formula-label orange">CALCULATION BASE</span>
            <div className="formula-value orange">34 Days</div>
            <div className="formula-desc orange">Current Date - Export Metadata Date</div>
          </div>
          
          <div className="data-rows">
            <div className="data-row">
              <span className="data-label">Export Created</span>
              <span className="data-value">Feb 14, 2026</span>
            </div>
            <div className="data-row">
              <span className="data-label">Migration Start</span>
              <span className="data-value">Mar 20, 2026</span>
            </div>
          </div>
          
          <div className="modal-info-note">
             <p>Configurations older than 30 days are flagged to ensure the migration doesn't bypass recent production updates in Dialogflow CX.</p>
          </div>
        </div>
        <div className="dashboard-modal-footer">
           <button className="btn-close-modal" onClick={onClose}>Close</button>
        </div>
      </div>
    </div>
  );
};

export default ConfigAgeModal;
