import React from 'react';

const ConversionEfficiencyTable: React.FC = () => {
    const modules = [
        { name: "Lead Generation", legacy: "124", target: "12", quality: "98% High", color: "#10b981" },
        { name: "Billing & Auth", legacy: "85", target: "18", quality: "72% Medium", color: "#f59e0b" },
        { name: "Generic FAQ", legacy: "211", target: "1 Tool (RAG)", quality: "99% Auto", color: "#3b82f6" }
    ];

    return (
        <div className="efficiency-table-card">
            <div className="card-header">
                <h3>CONVERSION EFFICIENCY BY MODULE</h3>
                <span className="badge-green">TOTAL COMPRESSION: 8.4x</span>
            </div>
            <table className="efficiency-table">
                <thead>
                    <tr>
                        <th>Module Name</th>
                        <th>Legacy Nodes</th>
                        <th>Target Goals</th>
                        <th>Conversion Quality</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {modules.map((m, idx) => (
                        <tr key={idx}>
                            <td className="module-name">{m.name}</td>
                            <td>{m.legacy} Pages</td>
                            <td>{m.target} Goals</td>
                            <td>
                                <span className="quality-badge" style={{ color: m.color, backgroundColor: `${m.color}15` }}>
                                    {m.quality}
                                </span>
                            </td>
                            <td className="actions-cell">
                                <button className="action-btn">Review Mindmap</button>
                                <button className="action-btn ghost">Download JSON</button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default ConversionEfficiencyTable;
