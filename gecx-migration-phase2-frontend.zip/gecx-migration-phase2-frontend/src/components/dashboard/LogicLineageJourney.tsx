import React from 'react';

const LogicLineageJourney: React.FC = () => {
    const legacy = [
        "CheckAccountBalance",
        "UpdateContactInfo",
        "SubmitInsuranceClaim",
        "GeneralFAQ"
    ];

    const target = [
        { name: "Account Management", color: "#eef2ff", textColor: "#4338ca", border: "#c7d2fe" },
        { name: "Claims Processing", color: "#f5f3ff", textColor: "#7c3aed", border: "#ddd6fe" },
        { name: "Knowledge Base (RAG)", color: "#ecfdf5", textColor: "#059669", border: "#a7f3d0" }
    ];

    return (
        <div className="logic-lineage-card">
            <div className="lineage-header">
                <h3>Logic Lineage Journey</h3>
                <span className="card-subtitle subtitle-right">Map of Dialogflow Intents to Gemini Goals</span>
            </div>
            <div className="lineage-container">
                <div className="lineage-column">
                    {legacy.map((item, idx) => (
                        <div key={idx} className="lineage-node legacy-node">
                            {item}
                        </div>
                    ))}
                </div>
                
                <div className="lineage-column">
                    {target.map((item, idx) => (
                        <div key={idx} className="lineage-node target-node" style={{ 
                            backgroundColor: item.color, 
                            color: item.textColor,
                            borderColor: item.border
                        }}>
                            {item.name}
                        </div>
                    ))}
                </div>
            </div>
            <div className="card-footer">
                <div className="legend">
                    <span className="legend-item"><span className="dot dot-legacy"></span> Legacy</span>
                    <span className="legend-item"><span className="dot dot-target"></span> Target</span>
                </div>
                <button className="view-link-btn">View Detailed Trace Matrix</button>
            </div>
        </div>
    );
};

export default LogicLineageJourney;
