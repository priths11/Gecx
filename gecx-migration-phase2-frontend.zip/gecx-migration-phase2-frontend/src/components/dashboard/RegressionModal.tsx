import React from 'react';

interface RegressionModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const RegressionModal: React.FC<RegressionModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="dashboard-modal-overlay" onClick={onClose}>
      <div className="dashboard-modal-container" onClick={e => e.stopPropagation()}>
        <div className="dashboard-modal-header">
           <div className="header-title">
             <span className="modal-icon green">📈</span>
             <h3>Regression Pass Logic</h3>
           </div>
           <button className="close-btn" onClick={onClose}>&times;</button>
        </div>
        <div className="dashboard-modal-body">
          <div className="regression-banner">
            <div className="regression-value">92.4%</div>
            <div className="regression-subtitle">PASS ACCURACY</div>
          </div>
          
          <div className="regression-breakdown">
            <div className="regression-item">
              <span className="item-label">Total "Golden Rule" Cases</span>
              <span className="item-value">500</span>
            </div>
            <div className="regression-item">
              <span className="item-label">Perfect Intent Matches</span>
              <span className="item-value green-text">462</span>
            </div>
            <div className="regression-item">
              <span className="item-label">Semantic Drift Failures</span>
              <span className="item-value red-text">38</span>
            </div>
          </div>
        </div>
        <div className="dashboard-modal-footer">
           <button className="btn-close-modal" onClick={onClose}>Close</button>
        </div>
      </div>
    </div>
  );
};

export default RegressionModal;
