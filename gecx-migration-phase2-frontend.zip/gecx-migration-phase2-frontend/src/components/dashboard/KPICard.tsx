import React from 'react';

interface KPICardProps {
  label: string;
  value: string;
  subValue?: string;
  trend?: string;
  icon?: React.ReactNode;
  onClickView?: () => void;
  color?: string;
}

const KPICard: React.FC<KPICardProps> = ({ label, value, subValue, trend, icon, onClickView, color }) => {
  return (
    <div className="kpi-card" onClick={onClickView} style={{ cursor: onClickView ? 'pointer' : 'default' }}>
      <div className="kpi-header">
        <span className="kpi-label">{label}</span>
        {icon && <div className="kpi-icon" style={{ backgroundColor: `${color}15`, color: color }}>{icon}</div>}
      </div>
      <div className="kpi-value-container">
        <div className="kpi-value">{value}</div>
        {subValue && <div className="kpi-subvalue">{subValue}</div>}
      </div>
      <div className="kpi-footer">
        {onClickView && (
          <button className="kpi-view-btn" onClick={onClickView} style={{ color: color }}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
              <circle cx="12" cy="12" r="3"></circle>
            </svg>
            View Logic
          </button>
        )}
        {trend && <div className="kpi-trend" style={{ color: trend.startsWith('+') ? '#10b981' : '#f59e0b' }}>{trend}</div>}
      </div>
    </div>
  );
};

export default KPICard;
