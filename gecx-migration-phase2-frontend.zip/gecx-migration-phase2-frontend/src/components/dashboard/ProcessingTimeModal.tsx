import React from 'react';

interface ProcessingTimeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const ProcessingTimeModal: React.FC<ProcessingTimeModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const breakdown = [
    { name: "Discovery Agent (Parsing)", time: "45s", percentage: 45 },
    { name: "Conversion Agent (Synthesis)", time: "82s", percentage: 82 },
    { name: "GCS Sync & Encryption", time: "15s", percentage: 15 }
  ];

  return (
    <div className="dashboard-modal-overlay" onClick={onClose}>
      <div className="dashboard-modal-container" onClick={e => e.stopPropagation()}>
        <div className="dashboard-modal-header">
           <div className="header-title">
             <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
               <circle cx="12" cy="12" r="10"></circle>
               <polyline points="12 6 12 12 16 14"></polyline>
             </svg>
             <h3>Avg. Processing Time Logic</h3>
           </div>
           <button className="close-btn" onClick={onClose}>&times;</button>
        </div>
        <div className="dashboard-modal-body">
          <div className="pipeline-section">
            <span className="pipeline-label">PIPELINE EXECUTION BREAKDOWN</span>
            {breakdown.map((item, idx) => (
              <div key={idx} className="pipeline-item">
                <div className="pipeline-info">
                  <span className="item-name">{item.name}</span>
                  <span className="item-time">{item.time}</span>
                </div>
                <div className="progress-bar-container">
                  <div className="progress-bar" style={{ width: `${item.percentage}%` }}></div>
                </div>
              </div>
            ))}
          </div>
          <div className="total-time-footer">
            <span className="total-label">TOTAL WALL TIME</span>
            <div className="total-value">142.0s</div>
          </div>
        </div>
        <div className="dashboard-modal-footer">
           <button className="btn-close-modal" onClick={onClose}>Close</button>
        </div>
      </div>
    </div>
  );
};

export default ProcessingTimeModal;
