import React from 'react';
import './SessionBanner.css';

interface SessionBannerProps {
  sessionId?: string | null;
  lastModified?: string | null;
  onResume?: () => void;
  onStartFresh?: () => void;
}

/**
 * Persistent banner shown between the app header and the workflow stepper
 * whenever a BigQuery saved session is detected.
 */
const SessionBanner: React.FC<SessionBannerProps> = ({
  sessionId,
  lastModified,
  onResume,
  onStartFresh,
}) => {
  if (!sessionId) return null;

  return (
    <div className="session-banner" role="status" aria-label="BigQuery session state">
      <div className="session-banner-left">
        <div className="session-banner-icon" aria-hidden="true">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <ellipse cx="12" cy="5" rx="9" ry="3" />
            <path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3" />
            <path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5" />
          </svg>
        </div>
        <div className="session-banner-copy">
          <span className="session-banner-title">BIGQUERY SESSION STATE PERSISTENCE FOUND</span>
          <span className="session-banner-sub">
            Saved Session:{' '}
            <span className="session-id">{sessionId}</span>
            {lastModified && <> &nbsp;|&nbsp; Last modified {lastModified}</>}
          </span>
        </div>
      </div>
      <div className="session-banner-actions">
        <button className="session-btn session-btn--resume" onClick={onResume} type="button">
          ↺ Resume Saved Session
        </button>
        <button className="session-btn session-btn--fresh" onClick={onStartFresh} type="button">
          Start Fresh Scan
        </button>
      </div>
    </div>
  );
};

export default SessionBanner;
