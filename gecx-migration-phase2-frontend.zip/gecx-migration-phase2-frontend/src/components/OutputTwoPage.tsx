import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { jsonToHtml, htmlToJson, knowledgeBaseToHtml, htmlToKnowledgeBase, toolIntegrationToHtml, htmlToToolIntegration, toolSectionToHtml, toTitleCase, toSentenceCase } from '../utils/artifactRenderer';
import { approveCxSummary, proxyFetch } from '../api/migrationApi';
import DataChartsModal from './DataChartsModal';
import './css/OutputTwoPage.css';

// ─── Component ────────────────────────────────────────────────────────────────

function OutputTwoPage({ activeTab, onTabChange, tabs, gecxData, gecxId, localEdits, onEditsChange, user, bucketName, projectNames = [], activeProjectName, onProjectChange, onBack, onProceed, onViewReporting, isFetchingReport }: {
  activeTab: string;
  onTabChange: (tab: string) => void;
  tabs: string[];
  gecxData: any;
  gecxId: any;
  localEdits: Record<string, string>;
  onEditsChange: React.Dispatch<React.SetStateAction<Record<string, string>>>;
  user: any;
  // 5-step workflow additions
  bucketName?: string;
  projectNames?: string[];
  activeProjectName?: string;
  onProjectChange?: (name: string) => void;
  onBack?: () => void;
  onProceed?: () => void;
  onViewReporting?: (jobId?: number | string) => Promise<void> | void;
  isFetchingReport?: boolean;
}) {
  const [isSyncing, setIsSyncing]           = useState(false);
  const [syncError, setSyncError]           = useState('');
  const [syncDone, setSyncDone]             = useState(false);
  const [isDownloading, setIsDownloading]   = useState(false);
  const [activeToolSubTab, setActiveToolSubTab] = useState('Overview');
  const editableRef = useRef<HTMLDivElement>(null);

  const [isCreateAgentOpen, setIsCreateAgentOpen] = useState(false);
  const [agentName, setAgentName] = useState('');
  const [isAgentCreating, setIsAgentCreating] = useState(false);
  const [agentCreateSuccess, setAgentCreateSuccess] = useState('');
  const [agentCreateError, setAgentCreateError] = useState('');

  const [isChartModalOpen, setIsChartModalOpen] = useState(false);

  // Derive sub-tabs for Tools Integration: Overview + one tab per section (label = part after ':')
  const toolSubTabs: { key: string; label: string; section: any }[] = useMemo(() => {
    const sections: any[] = gecxData?.tool_integration?.sections ?? [];
    return [
      { key: 'Overview', label: 'Overview', section: null },
      ...sections.map((s: any) => ({
        key: `tool_section_${s.index}`,
        label: (s.title ?? '').split(':').pop()?.trim() || s.title,
        section: s,
      })),
    ];
  }, [gecxData]);

  // Build content map from gecxData whenever it changes
  const contentMap = useMemo(() => {
    if (!gecxData) return null;
    const map: Record<string, string> = {
      'Agent Goal':          jsonToHtml(gecxData.goal || {}),
      'System Instructions': knowledgeBaseToHtml(gecxData.knowledge_base || {}),
      'Tools Integration':   toolIntegrationToHtml(gecxData.tool_integration || {}),
    };
    (gecxData?.tool_integration?.sections ?? []).forEach((s: any) => {
      map[`tool_section_${s.index}`] = toolSectionToHtml(s);
    });
    return map;
  }, [gecxData]);

  // Active content key: for Tools sub-tabs use section key, else use main tab
  const activeKey = activeTab === 'Tools Integration' && activeToolSubTab !== 'Overview'
    ? activeToolSubTab
    : activeTab;

  // Reset sub-tab when main tab changes
  useEffect(() => { setActiveToolSubTab('Overview'); }, [activeTab]);

  // Always set innerHTML synchronously before paint to avoid first-load flicker
  useLayoutEffect(() => {
    if (!editableRef.current) return;
    const html = localEdits[activeKey] ?? contentMap?.[activeKey] ?? '';
    editableRef.current.innerHTML = html;
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeKey, contentMap]);

  const handleInput = useCallback(() => {
    if (editableRef.current) {
      onEditsChange((prev: Record<string, string>) => ({ ...prev, [activeKey]: editableRef.current!.innerHTML }));
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeKey, onEditsChange]);

  // ── Sync to GCS (API 3) ──
  const handleSyncToGcs = async () => {
    if (isSyncing || !gecxId) return;
    setSyncError('');
    setSyncDone(false);
    setIsSyncing(true);
    try {
      const currentEdits = { ...localEdits };
      if (editableRef.current) {
        currentEdits[activeTab] = editableRef.current.innerHTML;
      }

      // Convert "Agent Goal" HTML → goal JSON
      const goalHtml = currentEdits['Agent Goal'] ?? contentMap?.['Agent Goal'] ?? '';
      const goalContainer = document.createElement('div');
      goalContainer.innerHTML = goalHtml;
      const goalRoot = goalContainer.firstElementChild;
      const goalJson = goalRoot ? htmlToJson(goalRoot) : {};

      // Convert "System Instructions" HTML → knowledge_base JSON
      const sysHtml = currentEdits['System Instructions'] ?? contentMap?.['System Instructions'] ?? '';
      const sysContainer = document.createElement('div');
      sysContainer.innerHTML = sysHtml;
      const sysRoot = sysContainer.querySelector('.kb-doc');
      const kbJson = sysRoot ? htmlToKnowledgeBase(sysRoot) : {};

      // Convert "Tools Integration" HTML → tool_integration JSON
      const toolsHtml = currentEdits['Tools Integration'] ?? contentMap?.['Tools Integration'] ?? '';
      const toolsContainer = document.createElement('div');
      toolsContainer.innerHTML = toolsHtml;
      const toolsRoot = toolsContainer.querySelector('.kb-doc');
      const toolsJson = toolsRoot ? htmlToToolIntegration(toolsRoot) : {};

      await approveCxSummary(gecxId, { goal: goalJson, knowledge_base: kbJson, tool_integration: toolsJson }, user?.email || "");
      setSyncDone(true);
    } catch (err: any) {
      setSyncError(err?.message || 'Sync to GCS failed.');
    } finally {
      setIsSyncing(false);
    }
  };

  // ── Create Agent (API) ──
  const handleCreateAgent = async () => {
    if (!agentName.trim() || !gecxId) return;
    setIsAgentCreating(true);
    setAgentCreateError('');
    setAgentCreateSuccess('');

    try {
      const response = await proxyFetch('/api/v1/build_cx_studio_agent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: Number(gecxId),
          user_email: user?.email || "",
          app_name: agentName.trim()
        })
      }, 'agent_builder');

      const data = await response.json();

      if (data.status === 'success') {
        const appNameFromRes = data.data?.app_name || agentName.trim();
        setAgentCreateSuccess(`${data.message || 'CX Studio build request processed successfully.'} "${appNameFromRes}" has been created.`);
        setIsCreateAgentOpen(false);
        setAgentName('');
      } else {
        setAgentCreateError(data.message || 'Failed to create agent');
      }
    } catch (err: any) {
      setAgentCreateError(err.message || 'Error occurred while creating agent');
    } finally {
      setIsAgentCreating(false);
    }
  };

  // ── Download PDF — all tabs using jsPDF + autoTable ──
  const handleDownload = () => {
    if (isDownloading) return;
    setIsDownloading(true);
    setTimeout(() => {
      try {
        const pdf = new jsPDF({ unit: 'mm', format: 'a4', orientation: 'portrait' });
        const margin = 14;
        const pageW = pdf.internal.pageSize.getWidth();
        const pageH = pdf.internal.pageSize.getHeight();
        let cursorY = margin;

        const checkPage = (needed = 10) => {
          if (cursorY > pageH - margin - needed) { pdf.addPage(); cursorY = margin; }
        };

        const addTabHeader = (title: string) => {
          checkPage(20);
          if (cursorY > margin + 5) cursorY += 10;
          pdf.setFontSize(13);
          pdf.setFont('helvetica', 'bold');
          pdf.setTextColor(37, 99, 235);
          pdf.text(toSentenceCase(title), margin, cursorY);
          cursorY += 1.5;
          pdf.setDrawColor(37, 99, 235);
          pdf.setLineWidth(0.5);
          pdf.line(margin, cursorY, pageW - margin, cursorY);
          cursorY += 8;
          pdf.setTextColor(0, 0, 0);
        };

        const addSectionHeader = (title: string) => {
          checkPage(15);
          cursorY += 3;
          pdf.setFontSize(11);
          pdf.setFont('helvetica', 'bold');
          pdf.setTextColor(15, 23, 42);
          pdf.text(title, margin, cursorY);
          cursorY += 6;
          pdf.setTextColor(0, 0, 0);
        };

        const addSubHeader = (num: any, title: string) => {
          checkPage(12);
          cursorY += 2;
          pdf.setFontSize(9);
          pdf.setFont('helvetica', 'bold');
          pdf.setTextColor(37, 99, 235);
          pdf.text(String(num ?? ''), margin + 2, cursorY);
          pdf.setTextColor(30, 41, 59);
          pdf.text(title, margin + 8, cursorY);
          cursorY += 5;
          pdf.setTextColor(0, 0, 0);
        };

        const addText = (text: string, indent = 0) => {
          if (!text.trim()) return;
          pdf.setFontSize(9);
          pdf.setFont('helvetica', 'normal');
          pdf.setTextColor(71, 85, 105);
          const lines = pdf.splitTextToSize(toSentenceCase(text), pageW - margin * 2 - indent);
          lines.forEach((line: string) => { checkPage(6); pdf.text(line, margin + indent, cursorY); cursorY += 5; });
          pdf.setTextColor(0, 0, 0);
        };

        const addKeyValue = (label: string, value: string, indent = 4) => {
          if (!value.trim()) return;
          checkPage(6);
          pdf.setFontSize(9);
          pdf.setFont('helvetica', 'bold');
          pdf.setTextColor(55, 65, 81);
          const labelText = `${label}: `;
          const labelW = pdf.getTextWidth(labelText);
          pdf.text(labelText, margin + indent, cursorY);
          pdf.setFont('helvetica', 'normal');
          pdf.setTextColor(30, 41, 59);
          const lines = pdf.splitTextToSize(toSentenceCase(value), pageW - margin * 2 - indent - labelW);
          pdf.text(lines, margin + indent + labelW, cursorY);
          cursorY += 5 * lines.length;
          pdf.setTextColor(0, 0, 0);
        };

        const addBulletList = (label: string, items: string[], indent = 4) => {
          if (!items.length) return;
          checkPage(8);
          pdf.setFontSize(9);
          pdf.setFont('helvetica', 'bold');
          pdf.setTextColor(55, 65, 81);
          pdf.text(`${label}:`, margin + indent, cursorY);
          cursorY += 5;
          pdf.setFont('helvetica', 'normal');
          pdf.setTextColor(30, 41, 59);
          items.forEach(item => {
            checkPage(6);
            const lines = pdf.splitTextToSize(`• ${toSentenceCase(item)}`, pageW - margin * 2 - indent - 4);
            pdf.text(lines, margin + indent + 4, cursorY);
            cursorY += 5 * lines.length;
          });
          pdf.setTextColor(0, 0, 0);
        };

        const formatCell = (v: any): string => {
          if (v == null) return '';
          if (typeof v !== 'object') return String(v);
          return JSON.stringify(v).replace(/,(?="|\[|\{)/g, ', ').replace(/:(?="|\[|\{|\d|true|false|null)/g, ': ');
        };

        const addArrayTable = (rows: any[]) => {
          if (!rows.length) return;
          const keys = Object.keys(rows[0]);
          const headers = keys.map(k => toTitleCase(k));
          checkPage(20);
          autoTable(pdf, {
            startY: cursorY,
            head: [headers],
            body: rows.map(row => keys.map(k => formatCell(row[k]))),
            margin: { left: margin, right: margin },
            styles: { fontSize: 7, cellPadding: 2, overflow: 'linebreak', minCellWidth: 20 },
            headStyles: { fillColor: [243, 244, 246], textColor: [30, 41, 59], fontStyle: 'bold' },
            alternateRowStyles: { fillColor: [248, 250, 252] },
            theme: 'grid',
            didDrawPage: () => { cursorY = margin; },
          });
          cursorY = (pdf as any).lastAutoTable.finalY + 6;
        };

        const renderGenericJson = (data: any) => {
          if (Array.isArray(data) && data.length && typeof data[0] === 'object') {
            addArrayTable(data);
          } else if (data && typeof data === 'object') {
            Object.entries(data).forEach(([k, v]) => {
              if (v == null) return;
              const label = toTitleCase(k);
              const val = typeof v === 'object' ? JSON.stringify(v) : String(v).trim();
              addKeyValue(label, val);
            });
          } else {
            addText(String(data ?? '').trim());
          }
        };

        const renderKnowledgeBase = (kb: any) => {
          if (!kb || typeof kb !== 'object') return;
          (kb.sections ?? []).forEach((section: any) => {
            addSectionHeader(`${section.index}  ${section.title ?? ''}`);
            if (section.description) addText(section.description, 4);
            (section.sections ?? []).forEach((sub: any) => {
              addSubHeader(sub.index, sub.title ?? '');
              if (sub.description) addText(sub.description, 8);
              if (sub.business_goal) addKeyValue('Business Goal', sub.business_goal, 8);
              if (sub.legacy_mapping?.length) addBulletList('Legacy Mapping', sub.legacy_mapping.map((i: any) => i.value ?? ''), 8);
              if (sub.required_logic?.length) addBulletList('Required Logic', sub.required_logic.map((i: any) => i.value ?? ''), 8);
            });
          });
        };

        const renderToolIntegration = (ti: any) => {
          if (!ti || typeof ti !== 'object') return;
          if (ti.description) addText(ti.description, 4);
          (ti.sections ?? []).forEach((s: any) => {
            addSubHeader(s.index, s.title ?? '');
            if (s.description) addText(s.description, 8);
            if (s.business_goal) addKeyValue('Business Goal', s.business_goal, 8);
            if (s.required_logic?.length) addBulletList('Required Logic', s.required_logic.map((i: any) => i.value ?? ''), 8);
          });
        };

        // Flush current DOM edit so all keys reflect latest user edits
        const editsSnapshot = { ...localEdits };
        if (editableRef.current) editsSnapshot[activeKey] = editableRef.current.innerHTML;

        const getHtml = (key: string): string =>
          editsSnapshot[key] ?? contentMap?.[key] ?? '';

        const parseKb = (html: string) => {
          const c = document.createElement('div'); c.innerHTML = html;
          const root = c.querySelector('.kb-doc'); return root ? htmlToKnowledgeBase(root) : null;
        };
        const parseTi = (html: string) => {
          const c = document.createElement('div'); c.innerHTML = html;
          const root = c.querySelector('.kb-doc'); return root ? htmlToToolIntegration(root) : null;
        };
        const parseGoal = (html: string) => {
          const c = document.createElement('div'); c.innerHTML = html;
          const root = c.firstElementChild; return root ? htmlToJson(root) : null;
        };

        // ── Agent Goal ──
        addTabHeader('Agent Goal');
        renderGenericJson(parseGoal(getHtml('Agent Goal')) ?? gecxData?.goal ?? {});

        // ── System Instructions ──
        addTabHeader('System Instructions');
        renderKnowledgeBase(parseKb(getHtml('System Instructions')) ?? gecxData?.knowledge_base ?? {});

        // ── Tools Integration ──
        addTabHeader('Tools Integration');
        renderToolIntegration(parseTi(getHtml('Tools Integration')) ?? gecxData?.tool_integration ?? {});

        pdf.save('gecx_system_instructions.pdf');
      } finally {
        setIsDownloading(false);
      }
    }, 50);
  };

  return (
    <section className="output-two-card">
      <div className="output-card-head">
        <div className="output-card-title">
          <div className="output-card-icon output-card-icon-final" aria-hidden="true">🤖</div>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
              <h2 style={{ margin: 0 }}>Output 2: GECX Ready Files</h2>
              {bucketName && (
                <span style={{ display:'inline-block', padding:'3px 10px', background:'#f1f5f9', border:'1px solid #cbd5e1', borderRadius:6, fontSize:12, fontWeight:700, color:'#475569', fontFamily:'ui-monospace, monospace' }}>
                  Bucket: {bucketName}
                </span>
              )}
            </div>
            {activeProjectName && (
              <p style={{ margin: '4px 0 0', fontSize: 13, color: '#64748b' }}>
                Final Multi-Agent configurations for Gemini Enterprise CX.{' '}
                <strong>{activeProjectName}</strong>
                {bucketName && <> under Bucket <strong>{bucketName}</strong></>}.
              </p>
            )}
          </div>
        </div>
        <div className="output-card-actions" style={{ flexWrap: 'wrap', gap: 8 }}>
          {/* Project selector */}
          {projectNames.length > 0 && (
            <select
              style={{ padding:'7px 10px', border:'1.5px solid #e2e8f0', borderRadius:8, fontSize:13, fontWeight:600, color:'#1e293b', background:'#fff', cursor:'pointer', maxWidth:200 }}
              value={activeProjectName || ''}
              onChange={(e) => onProjectChange?.(e.target.value)}
              aria-label="Select project"
            >
              {projectNames.map((n) => (
                <option key={n} value={n}>{n}</option>
              ))}
            </select>
          )}
          {/* Export PDF */}
          <button className="secondary-action-btn" type="button" onClick={handleDownload} disabled={isDownloading}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ marginRight: 5, verticalAlign:'text-bottom' }}><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            {isDownloading ? 'Generating…' : 'Export PDF Report'}
          </button>
          {/* Bulk Approve GECX */}
          <button
            className="primary-sync-btn"
            style={{ background: 'linear-gradient(135deg,#22c55e,#16a34a)', boxShadow:'0 4px 12px rgba(34,197,94,0.3)' }}
            type="button"
            onClick={handleSyncToGcs}
            disabled={isSyncing || !gecxId}
          >
            {isSyncing ? 'Syncing…' : syncDone ? '✓ Synced' : '✓ Bulk Approve All GECX'}
          </button>
          {/* Sync Artifacts */}
          <button
            className="primary-sync-btn"
            style={{ background:'linear-gradient(135deg,#0891b2,#0e7490)', boxShadow:'0 4px 12px rgba(8,145,178,0.3)' }}
            type="button"
            onClick={handleSyncToGcs}
            disabled={isSyncing || !gecxId}
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ marginRight:5, verticalAlign:'text-bottom' }}><polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/></svg>
            Sync Artifacts to GCS
          </button>
          {/* Provision Agents MCP */}
          <button
            className="primary-sync-btn"
            style={{ background:'linear-gradient(135deg,#7c3aed,#6d28d9)', boxShadow:'0 4px 12px rgba(124,58,237,0.3)' }}
            type="button"
            onClick={() => setIsCreateAgentOpen(true)}
            disabled={!gecxId}
          >
            + Provision Agents in GECX (MCP)
          </button>
          {/* View Reporting */}
          <button
            className="primary-sync-btn"
            style={{ background:'linear-gradient(135deg,#1d4ed8,#2563eb)', boxShadow:'0 4px 12px rgba(37,99,235,0.3)' }}
            type="button"
            onClick={() => {
              if (onViewReporting) {
                onViewReporting(gecxId || 37900977);
              } else {
                onProceed?.();
              }
            }}
            disabled={isFetchingReport}
          >
            {isFetchingReport ? (
              <>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ marginRight: 6, animation: 'spin 1s linear infinite' }}>
                  <path d="M21 12a9 9 0 1 1-6.219-8.56" />
                </svg>
                Fetching Report…
              </>
            ) : (
              'View Reporting →'
            )}
          </button>
        </div>
      </div>

      {syncError && <p style={{ margin: '0', padding: '8px 24px', background: '#fef2f2', color: '#dc2626', fontSize: '13px' }}>{syncError}</p>}
      {agentCreateSuccess && <p style={{ margin: '0', padding: '8px 24px', background: '#ecfdf5', color: '#059669', fontSize: '13px' }}>{agentCreateSuccess}</p>}
      {agentCreateError && <p style={{ margin: '0', padding: '8px 24px', background: '#fef2f2', color: '#dc2626', fontSize: '13px' }}>{agentCreateError}</p>}

      <div className="output-two-tabs" role="tablist" aria-label="Output 2 tabs">
        {tabs.map((tab: string) => {
          let iconSvg = null;
          if (tab === 'Agent Goal') {
            iconSvg = <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg>;
          } else if (tab === 'System Instructions') {
            iconSvg = <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>;
          } else if (tab === 'Tools Integration') {
            iconSvg = <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>;
          }
          return (
            <button
              key={tab}
              className={`output-two-tab${activeTab === tab ? ' active' : ''}`}
              onClick={() => onTabChange(tab)}
              type="button"
            >
              <span style={{ marginRight: '6px', verticalAlign: 'text-bottom' }} aria-hidden="true">{iconSvg}</span>
              {tab}
            </button>
          );
        })}
      </div>

      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', background: '#f8fafc' }}>
        {!gecxData && (
          <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#94a3b8', fontSize: '14px' }}>
            Approve Output 1 to generate GECX files.
          </div>
        )}
        {gecxData && activeTab === 'Tools Integration' ? (
          <div style={{ flex: 1, display: 'flex', flexDirection: 'row', overflow: 'hidden', minHeight: 0 }}>
            <div className="tool-sub-tabs" role="tablist">
              {toolSubTabs.map(t => (
                <button
                  key={t.key}
                  className={`tool-sub-tab${activeToolSubTab === t.key ? ' active' : ''}`}
                  onClick={() => setActiveToolSubTab(t.key)}
                  type="button"
                >
                  {t.label}
                </button>
              ))}
            </div>
            <div
              key={activeKey}
              ref={editableRef}
              contentEditable
              suppressContentEditableWarning
              onInput={handleInput}
              style={{ flex: 1, minWidth: 0, overflowY: 'auto', overflowX: 'hidden', outline: 'none', cursor: 'text', padding: '28px 36px', fontSize: '14px', color: '#1e293b', background: '#f8fafc', minHeight: 0 }}
            />
          </div>
        ) : gecxData ? (
          <div
            key={activeKey}
            ref={editableRef}
            contentEditable
            suppressContentEditableWarning
            onInput={handleInput}
            style={{ flex: 1, overflowY: 'auto', outline: 'none', cursor: 'text', padding: '28px 36px', fontSize: '14px', color: '#1e293b', background: '#f8fafc', minHeight: 0 }}
          />
        ) : null}
      </div>
      {isCreateAgentOpen && (
        <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.4)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <div style={{ background: '#fff', borderRadius: '16px', padding: '24px', width: '400px', boxShadow: '0 4px 20px rgba(0,0,0,0.15)' }}>
            <h3 style={{ margin: '0 0 20px 0', fontSize: '18px', fontWeight: '500', color: '#1e293b' }}>Create agent</h3>
            
            <div style={{ marginBottom: '32px' }}>
              <label style={{ display: 'block', marginBottom: '8px', fontSize: '13px', color: '#475569', fontWeight: '500' }}>Name</label>
              <input 
                type="text" 
                value={agentName} 
                onChange={e => setAgentName(e.target.value)} 
                style={{ width: '100%', padding: '10px 12px', border: '1px solid #cbd5e1', borderRadius: '8px', fontSize: '14px', boxSizing: 'border-box', outline: 'none' }}
                autoFocus
                onFocus={e => (e.target.style.borderColor = '#3b82f6')}
                onBlur={e => (e.target.style.borderColor = '#cbd5e1')}
              />
            </div>

            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '12px' }}>
              <button 
                onClick={() => setIsCreateAgentOpen(false)} 
                style={{ padding: '8px 16px', background: 'transparent', color: '#2563eb', border: 'none', cursor: 'pointer', fontWeight: '600', fontSize: '14px' }}
              >
                Cancel
              </button>
              <button 
                onClick={handleCreateAgent} 
                style={{ padding: '8px 16px', background: agentName.trim() ? '#f1f5f9' : '#f8fafc', color: agentName.trim() ? '#475569' : '#94a3b8', borderRadius: '24px', border: 'none', cursor: agentName.trim() ? 'pointer' : 'not-allowed', fontWeight: '600', fontSize: '14px' }}
                disabled={!agentName.trim()}
              >
                Create
              </button>
            </div>
          </div>
        </div>
      )}

      {isAgentCreating && (
        <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(255, 255, 255, 0.7)', zIndex: 9999, display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column' }}>
          <div style={{ width: '40px', height: '40px', border: '4px solid #f3f3f3', borderTop: '4px solid #2563eb', borderRadius: '50%', animation: 'spin 1s linear infinite' }}></div>
          <div style={{ marginTop: '16px', fontSize: '15px', fontWeight: '600', color: '#1e293b' }}>Creating Agent...</div>
          <style>{`@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }`}</style>
        </div>
      )}

      {gecxData && (
        <DataChartsModal 
          isOpen={isChartModalOpen} 
          onClose={() => setIsChartModalOpen(false)} 
          artifacts={[]}
          gecxData={gecxData} 
        />
      )}

      {/* Footer navigation */}
      <div className="o2-footer-nav">
        <button className="o2-nav-btn o2-nav-btn--back" onClick={onBack} type="button">
          ← Back to HITL SSOT AST Review
        </button>
        <button
          className="o2-nav-btn o2-nav-btn--proceed"
          onClick={() => {
            if (onViewReporting) {
              onViewReporting(gecxId || 37900977);
            } else {
              onProceed?.();
            }
          }}
          disabled={isFetchingReport}
          type="button"
        >
          {isFetchingReport ? 'Fetching Report…' : 'Proceed to Operational Reporting & Analytics →'}
        </button>
      </div>
    </section>
  );
}

export default OutputTwoPage;
