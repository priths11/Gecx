import { createContext, useCallback, useContext, useRef, useState } from 'react';
import type { ReactNode } from 'react';

// ─── Types ────────────────────────────────────────────────────────────────────

type ToastSeverity = 'error' | 'warning' | 'success' | 'info';

interface Toast {
  id: number;
  message: string;
  severity: ToastSeverity;
}

interface ToastContextValue {
  showToast: (message: string, severity?: ToastSeverity) => void;
}

// ─── Context ──────────────────────────────────────────────────────────────────

const ToastContext = createContext<ToastContextValue | null>(null);

const TOAST_DURATION_MS = 5000;

// ─── Provider ─────────────────────────────────────────────────────────────────

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);
  const nextId = useRef(0);

  const dismiss = useCallback((id: number) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  }, []);

  const showToast = useCallback((message: string, severity: ToastSeverity = 'error') => {
    const id = nextId.current++;
    setToasts(prev => [...prev, { id, message, severity }]);
    setTimeout(() => dismiss(id), TOAST_DURATION_MS);
  }, [dismiss]);

  return (
    <ToastContext.Provider value={{ showToast }}>
      {children}
      <div className="toast-container" aria-live="assertive" aria-atomic="false">
        {toasts.map(toast => (
          <div key={toast.id} className={`toast toast--${toast.severity}`} role="alert">
            <span className="toast__icon">{severityIcon(toast.severity)}</span>
            <span className="toast__message">{toast.message}</span>
            <button className="toast__close" onClick={() => dismiss(toast.id)} aria-label="Dismiss">✕</button>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
}

// ─── Hook ─────────────────────────────────────────────────────────────────────

export function useToast(): ToastContextValue {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error('useToast must be used inside <ToastProvider>');
  return ctx;
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function severityIcon(severity: ToastSeverity): string {
  switch (severity) {
    case 'error':   return '✖';
    case 'warning': return '⚠';
    case 'success': return '✔';
    case 'info':    return 'ℹ';
  }
}
