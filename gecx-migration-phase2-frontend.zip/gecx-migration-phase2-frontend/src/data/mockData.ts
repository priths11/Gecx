export const OUTPUT_ONE_ARTIFACTS = [
  {
    name: 'Billing_Flow.md',
    type: 'md',
    content: `# Southstar DFCX AST: Billing_Flow

## Page: Collect_Order_Number
- **Triggers Webhook:** \`VerifyCustomerAPI\`
- **Collects Data (Slots):**
  - \`order_id\` (Type: sys.number, Req: True)
- **Transition Rules:**
  - IF Intent: \`Track_Order\` -> Go to \`Status_Page\`
  - IF Intent: \`Dispute_Charge\` -> Go to \`Dispute_Page\`
  - IF \`$session.params == null\` -> Go to \`Escalation_Page\`

## Page: Dispute_Page
- **Messages:**
  - "I understand you have an issue with order $session.params.order_id."
- **Triggers Webhook:** \`GetDisputeStatusAPI\`
- **Transition Rules:**
  - IF Intent: \`Agent_Transfer\` -> Go to \`Human_Handoff\``,
  },
  { name: 'Auth_Flow.md', type: 'md', content: '# Auth Flow\n\nToken exchange and fallback prompts.' },
  {
    name: 'Support_Escalation.md',
    type: 'md',
    content: '# Support Escalation\n\nEscalation routing, SLAs, and transfer nodes.',
  },
  {
    name: 'Extracted_Webhooks.json',
    type: 'json',
    content: '{\n  "webhooks": ["VerifyCustomerAPI", "GetDisputeStatusAPI"]\n}',
  },
  {
    name: 'Legacy_Intents.json',
    type: 'json',
    content: '{\n  "intents": ["Track_Order", "Dispute_Charge", "Agent_Transfer"]\n}',
  },
];

export const OUTPUT_TWO_TABS = ['Agent Goal', 'System Instructions', 'Tools Integration'];

export const OUTPUT_TWO_CONTENT: Record<string, {fileName: string; content: string}> = {
  'System Instructions': {
    fileName: 'billing_sub_agent.json',
    content: `{
  "agent_name": "Southstar Billing Specialist",
  "agent_type": "Sub-Agent",
  "system_instructions": "You are the Billing Specialist for Southstar. Your goal is to resolve billing disputes and track orders. Always authenticate the user first by extracting their order_id.",
  "guardrails": [
    "Never promise a refund without verifying the policy via the RAG Knowledge Base.",
    "Do not discuss shipping times; politely route to the Support Sub-Agent.",
    "If the user asks to speak to a human, immediately trigger the Escalation tool."
  ],
  "tools": [
    "VerifyCustomerAPI",
    "GetDisputeStatusAPI"
  ]
}`,
  },
  'Tools (OpenAPI)': {
    fileName: 'billing_tools.yaml',
    content: `openapi: 3.0.0
info:
  title: Southstar Billing APIs
  version: 1.0.0
paths:
  /billing/dispute:
    get:
      operationId: GetDisputeStatusAPI
      description: Use this tool ONLY when a user asks about an existing refund or chargeback.
      parameters:
        - name: order_id
          in: query
          required: true
          schema:
            type: string
            pattern: '^ORD[0-9]{5}$'
      responses:
        '200':
          description: Successful retrieval of dispute status
  /billing/verify:
    post:
      operationId: VerifyCustomerAPI
      description: Confirms customer identity before exposing billing information.`,
  },
};

export const DEFAULT_STAGED_FILES = [];
