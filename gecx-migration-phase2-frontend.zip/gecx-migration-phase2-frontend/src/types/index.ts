// ─── Domain Types ─────────────────────────────────────────────────────────────

export type SourceType = 'ZIP Upload' | 'GCP Console';
export type CategorizationStatus = 'Unanalyzed' | 'Simple' | 'Medium' | 'Complex';

/** A project discovered during Portfolio Discovery (Step 1). */
export interface DiscoveredProject {
  id: string;
  name: string;         // e.g. "Support_FAQ_Base"
  agentId: string;      // e.g. "ag-8821-s992" (display only)
  sourceType: SourceType;
  categorizationStatus: CategorizationStatus;
  rawFile?: File;       // only present for ZIP Upload projects
  selected: boolean;
}

/** A project that has been uploaded and received a backend job_id (Step 2). */
export interface SyncedProject {
  name: string;
  jobId: string;
  gcsPath: string;   // e.g. gs://cx-migrator/BUCKET_NAME/ProjectName/JOB_ID/
  bqSink: string;    // e.g. cx_audit_log.BUCKET_NAME.JOB_ID
  rawFile?: File;
}

/** Per-tier quota counters shown in the bucket configuration panel. */
export interface QuotaTier {
  label: string;
  used: number;
  total: number;
}
