import { render, screen } from '@testing-library/react';
import App from './App';

test('renders the login screen', () => {
  render(<App />);
  expect(screen.getByRole('heading', { name: /Next-Generation CX Migration Engine/i })).toBeInTheDocument();
  expect(screen.getByText(/Choose an existing account or use another Google account/i)).toBeInTheDocument();
});
