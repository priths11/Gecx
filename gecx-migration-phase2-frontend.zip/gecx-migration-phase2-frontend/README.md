# CX Migration Engine

This repository contains the CX Migration Engine React UI frontend and Python GCP Token Auth Backend Server.

---

## 🚀 Step-by-Step Setup & Run Instructions

### 1. Set Up & Run Backend Server (Terminal 1)

#### macOS / Linux:
```bash
# Step A: Create Virtual Environment
python3 -m venv .venv

# Step B: Activate Virtual Environment
source .venv/bin/activate

# Step C: Install Requirements
pip install -r requirements.txt

# Step D: Run Backend Server
python3 server.py
```

#### Windows (Command Prompt / PowerShell):
```cmd
:: Step A: Create Virtual Environment
python -m venv .venv

:: Step B: Activate Virtual Environment
.venv\Scripts\activate

:: Step C: Install Requirements
pip install -r requirements.txt

:: Step D: Run Backend Server
python server.py
```

To print python logs execute this statement 
.venv\Scripts\python.exe -u server.py


> **Backend Server runs on**: `http://localhost:8080`

---

### 2. Set Up & Run UI Frontend (Terminal 2)

In a new terminal window:

```bash
# Step A: Install Node Dependencies (first time only)
npm install

# Step B: Start React UI
npm start
```

> **React UI runs on**: `http://localhost:3000`

---

## 🔐 GCP Authentication (One-time setup)

Before running API calls, authenticate with Google Cloud:

```bash
gcloud auth application-default login
```
