import os
import sys

# Auto-re-exec using local .venv if system python lacks dependencies
venv_bin_dir = "Scripts" if os.name == "nt" else "bin"
venv_exe_name = "python.exe" if os.name == "nt" else "python"
venv_python = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".venv", venv_bin_dir, venv_exe_name)

if os.path.exists(venv_python) and sys.executable != os.path.abspath(venv_python):
    try:
        import flask  # type: ignore
    except ImportError:
        os.execv(venv_python, [venv_python] + sys.argv)

from typing import Any
from flask import Flask, jsonify, request, send_from_directory
import google.auth
import google.oauth2.id_token
from google.auth.impersonated_credentials import Credentials as ImpersonatedCredentials, IDTokenCredentials
from google.auth.transport.requests import Request

BUILD_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "build")
BUILD_STATIC_DIR = os.path.join(BUILD_DIR, "static")

DEFAULT_IMPERSONATE_SERVICE_ACCOUNT = (
    "lee-ackerman@tgs-int-genai-vertextai-dev-01.iam.gserviceaccount.com"
)
DEFAULT_AUDIENCE = "https://cx-migration-config-dev-325784336727.us-central1.run.app"

IAP_CLIENT_ID = "325784336727-oq1kno1j5ak88u5vr6ar90o8n6e81v9o.apps.googleusercontent.com"

# Whitelisted upstream Cloud Run services the /internal/proxy route is allowed to forward to.
REMOTE_TARGETS = {
    "config": os.getenv("TARGET_REMOTE_BASE") or DEFAULT_AUDIENCE,
    "migrator": os.getenv(
        "TARGET_MIGRATOR_BASE", "https://cx-migrator-v1-dev-325784336727.us-central1.run.app"
    ),
    "dfcx": os.getenv(
        "TARGET_DFCX_BASE", "https://cx-migration-summary-generator-dev-325784336727.us-central1.run.app"
    ),
    "reporting": os.getenv(
        "TARGET_REPORTING_BASE", "https://cx-migration-reporting-dev-325784336727.us-central1.run.app"
    ),
    "agent_builder": os.getenv(
        "TARGET_AGENT_BUILDER_BASE", "https://cx-agent-builder-dev-325784336727.us-central1.run.app"
    ),
}

app = Flask(__name__, static_folder=BUILD_STATIC_DIR, static_url_path="/static")


@app.after_request
def add_cors(response):
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Headers"] = "Content-Type,Authorization"
    response.headers["Access-Control-Allow-Methods"] = "GET,POST,OPTIONS"
    return response


def _source_credentials():
    credentials, _ = google.auth.default(
        scopes=["https://www.googleapis.com/auth/cloud-platform"]
    )
    credentials.refresh(Request())
    return credentials


def _impersonated_credentials(target_service_account: str) -> ImpersonatedCredentials:
    return ImpersonatedCredentials(
        source_credentials=_source_credentials(),
        target_principal=target_service_account,
        target_scopes=["https://www.googleapis.com/auth/cloud-platform"],
        lifetime=3600,
    )


import json
import subprocess
import urllib.parse
import urllib.request
import shutil
import requests


def _gcloud_executable() -> str | None:
    for candidate in ("gcloud", "gcloud.cmd", "gcloud.exe"):
        resolved = shutil.which(candidate)
        if resolved:
            return resolved
    return None


def _is_localhost_runtime() -> bool:
    """Return True when running on a developer machine rather than GCP runtime."""
    return (
        os.environ.get("K_SERVICE") is None
        and os.environ.get("FUNCTION_TARGET") is None
        and os.environ.get("GAE_ENV") is None
        and os.environ.get("CLOUD_RUN_JOB") is None
        and os.environ.get("CLOUD_RUN_EXECUTION") is None
    )


def fetch_bearer_token_localhost(*, audience: str, service_account: str | None = None) -> str:
    """Localhost-only fallback that impersonates the target service account and
    mints an audience-bound ID token for Cloud Run."""
    target_service_account = (
        service_account
        or os.getenv("IMPERSONATE_SERVICE_ACCOUNT", DEFAULT_IMPERSONATE_SERVICE_ACCOUNT)
    )

    gcloud_exe = _gcloud_executable()
    print("[DEBUG] fetch_bearer_token_localhost called")
    print(f"[DEBUG] audience={audience}")
    print(f"[DEBUG] service_account={target_service_account}")
    print(f"[DEBUG] gcloud_executable={gcloud_exe}")
    print(f"[DEBUG] is_localhost_runtime={_is_localhost_runtime()}")

    if not gcloud_exe:
        raise RuntimeError(
            "gcloud is not installed or not in PATH. Install Google Cloud SDK, then run: "
            "where.exe gcloud; gcloud version; restart the terminal and Python server."
        )

    try:
        cmd = [
            gcloud_exe,
            "auth",
            "print-identity-token",
            f"--audiences={audience}",
            f"--impersonate-service-account={target_service_account}",
        ]
        print(f"[DEBUG] running gcloud command: {' '.join(cmd)}")
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        token = result.stdout.strip()
        if token:
            print("[DEBUG] localhost token minted successfully")
            print(f"[DEBUG] token_prefix={token[:20]}...{token[-20:]}")
            return str(token)
    except Exception as exc:
        print(f"[DEBUG] localhost gcloud token failed: {exc}")
        raise RuntimeError(
            "Localhost identity-token generation failed. Make sure gcloud is installed, authenticated, and on PATH. "
            "Run: where.exe gcloud; gcloud auth login; gcloud auth application-default login; gcloud version. "
            f"Details: {exc}"
        ) from exc

    raise RuntimeError("Localhost fallback could not resolve a valid identity token.")

def fetch_bearer_token(*, audience: str, service_account: str | None = None) -> str:
    """Use Cloud Run runtime identity when deployed; use service-account impersonation locally."""
    print("[DEBUG] fetch_bearer_token called")
    print(f"[DEBUG] audience={audience}")
    print(f"[DEBUG] requested_service_account={service_account}")
    print(f"[DEBUG] localhost_runtime={_is_localhost_runtime()}")

    if _is_localhost_runtime():
        print("[DEBUG] selecting localhost path")
        return fetch_bearer_token_localhost(
            audience=audience,
            service_account=service_account,
        )

    print("[DEBUG] selecting Cloud Run runtime path")
    try:
        token = google.oauth2.id_token.fetch_id_token(Request(), audience)
    except Exception as exc:
        print(f"[DEBUG] Cloud Run fetch_id_token failed: {exc}")
        raise RuntimeError(
            f"Runtime service account did not return an ID token: {exc}"
        ) from exc

    if not token:
        raise RuntimeError("Runtime service account did not return an ID token.")

    print("[DEBUG] Cloud Run token minted successfully")
    print(f"[DEBUG] token_prefix={token[:20]}...{token[-20:]}")
    return str(token)

def fetch_gcp_id_token(*, target_service_account: str, audience: str) -> str:
    last_exc = None
    # 1. Try SA Impersonation
    try:
        impersonated = _impersonated_credentials(target_service_account)
        id_creds = IDTokenCredentials(
            target_credentials=impersonated,
            target_audience=audience,
            include_email=True,
        )
        id_creds.refresh(Request())
        if id_creds.token:
            return str(id_creds.token)
    except Exception as exc:
        last_exc = exc
        print(f"[Auth Notice] Impersonation failed ({exc}). Trying gcloud print-identity-token...")

    # 2. Try gcloud CLI ID token
    try:
        gcloud_exe = _gcloud_executable()
        if gcloud_exe:
            cmd = [gcloud_exe, "auth", "print-identity-token", f"--audiences={audience}"]
            print(f"[DEBUG] gcp_id_token fallback using: {' '.join(cmd)}")
            result = subprocess.run(cmd, capture_output=True, text=True, check=True)
            token = result.stdout.strip()
            if token:
                return token
        else:
            print("[Auth Notice] gcloud not found in PATH; skipping gcloud identity-token attempt.")
    except Exception as exc:
        last_exc = exc
        print(f"[Auth Notice] gcloud print-identity-token failed: {exc}")

    # 3. Direct OAuth2 endpoint refresh_token exchange for id_token using ADC
    try:
        creds, _ = google.auth.default()
        creds.refresh(Request())
        refresh_tok = getattr(creds, "_refresh_token", None) or getattr(creds, "refresh_token", None)
        client_id = getattr(creds, "_client_id", None) or getattr(creds, "client_id", None)
        client_secret = getattr(creds, "_client_secret", None) or getattr(creds, "client_secret", None)

        if refresh_tok:
            token_url = "https://oauth2.googleapis.com/token"
            data = urllib.parse.urlencode({
                "client_id": client_id or "",
                "client_secret": client_secret or "",
                "refresh_token": refresh_tok,
                "grant_type": "refresh_token",
                "target_audience": audience,
            }).encode("utf-8")

            req = urllib.request.Request(token_url, data=data)
            try:
                with urllib.request.urlopen(req) as resp:
                    res = json.loads(resp.read().decode("utf-8"))
                    if "id_token" in res:
                        return str(res["id_token"])
            except Exception as exc:
                last_exc = exc
                raise
    except Exception as exc:
        last_exc = exc
        print(f"[Auth Notice] OAuth2 ADC ID token exchange failed: {exc}")

    # 4. Fallback to access token
    try:
        creds, _ = google.auth.default(
            scopes=["https://www.googleapis.com/auth/cloud-platform"]
        )
        creds.refresh(Request())
        if creds.token:
            return str(creds.token)
    except Exception as exc:
        last_exc = exc
        print(f"[Auth Error] ADC token generation failed: {exc}")
    # Surface underlying error text so callers can give actionable advice.
    raise RuntimeError(f"Failed to obtain GCP authorization token via ADC: {last_exc}")


@app.route("/api/token", methods=["GET", "POST"])
@app.route("/api/v1/token", methods=["GET", "POST"])
def get_token():
    try:
        service_account = request.args.get("service_account") or os.getenv(
            "IMPERSONATE_SERVICE_ACCOUNT", DEFAULT_IMPERSONATE_SERVICE_ACCOUNT
        )
        raw_audience = request.args.get("audience") or os.getenv(
            "TARGET_AUDIENCE", DEFAULT_AUDIENCE
        )

        # Strip path from audience if provided (e.g. https://domain.run.app/api/v1 -> https://domain.run.app)
        audience = raw_audience
        if raw_audience and "://" in raw_audience:
            parts = raw_audience.split("/")
            audience = f"{parts[0]}//{parts[2]}"

        print("[DEBUG] get_token route called")
        print(f"[DEBUG] service_account={service_account}")
        print(f"[DEBUG] audience={audience}")
        token = fetch_bearer_token(
            audience=audience,
            service_account=service_account,
        )
        print("[DEBUG] fetch_bearer_token: Token generated successfully")
        return jsonify(
            {
                "status": "success",
                "token": token,
                "service_account": service_account,
                "audience": audience,
            }
        )
    except Exception as exc:
        err_msg = str(exc)
        if "invalid_grant" in err_msg:
            err_msg = "GCP Application Default Credentials expired. Please run 'gcloud auth application-default login' in terminal."
        print(f"[Token Error] {err_msg}")
        return jsonify({"status": "error", "message": err_msg}), 500



# Only these inbound headers are relayed upstream. Cookie, the IAP assertion, hop-by-hop
# headers and Content-Length are dropped: Cloud Run's auth layer rejects requests carrying
# them, and `requests` recomputes the framing headers for the rewritten body.
FORWARDABLE_REQUEST_HEADERS = frozenset({
    'accept',
    'accept-language',
    'content-type',
    'x-cloud-trace-context',
    'x-request-id',
})


def _forwardable_headers() -> dict:
    return {
        key: value
        for key, value in request.headers.items()
        if key.lower() in FORWARDABLE_REQUEST_HEADERS
    }


@app.route('/internal/proxy', methods=['GET', 'POST', 'OPTIONS'])
def proxy():
    """Proxy requests to a whitelisted Cloud Run target using a fetched token.

    Accepts query param `path` (e.g. /api/v1/get_config) or JSON body {"path":...},
    and an optional `target` param (config|migrator|dfcx, default config) selecting
    which upstream base URL from REMOTE_TARGETS to use.
    Forwards method, headers, and JSON body. Useful to bypass browser CORS.
    """
    # Allow CORS preflight
    if request.method == 'OPTIONS':
        return ('', 204)

    raw_path = request.args.get('path') or (request.get_json(silent=True) or {}).get('path')
    if not raw_path:
        return jsonify({'status': 'error', 'message': 'missing path parameter'}), 400

    target_key = request.args.get('target') or (request.get_json(silent=True) or {}).get('target') or 'config'
    remote_base = REMOTE_TARGETS.get(target_key)
    if not remote_base:
        return jsonify({
            'status': 'error',
            'message': f"unknown target '{target_key}'; expected one of {sorted(REMOTE_TARGETS)}",
        }), 400

    # Strip trailing slash handling
    if remote_base.endswith('/'):
        remote_base = remote_base[:-1]
    url = remote_base + raw_path if raw_path.startswith('/') else remote_base + '/' + raw_path

    # Fetch token
    try:
        print("[DEBUG] proxy() called")
        print(f"[DEBUG] raw_path={raw_path}")
        print(f"[DEBUG] target_key={target_key}")
        print(f"[DEBUG] remote_base={remote_base}")
        token = fetch_bearer_token(
            audience=remote_base,
            service_account=os.getenv('IMPERSONATE_SERVICE_ACCOUNT', DEFAULT_IMPERSONATE_SERVICE_ACCOUNT),
        )
        print("[DEBUG] fetch_bearer_token: Token generated successfully")
    except Exception as exc:
        return jsonify({'status': 'error', 'message': str(exc)}), 500

    headers = _forwardable_headers()
    # Strip any prefix the caller may have included so we don't double-prefix
    headers['Authorization'] = f'Bearer {token.strip().removeprefix("Bearer ")}'

    verify_ssl = os.getenv('ALLOW_INSECURE_REMOTE', 'false').lower() not in ('1', 'true', 'yes')
    print(f"[Proxy DEBUG] ALLOW_INSECURE_REMOTE={os.getenv('ALLOW_INSECURE_REMOTE')} verify_ssl={verify_ssl}")

    # Long-running upstream calls (uploads, migrations) need more than the old 30s default.
    proxy_timeout = int(os.getenv('PROXY_UPSTREAM_TIMEOUT', '280'))

    try:
        if request.method == 'GET':
            # Don't forward our own 'path'/'target' selector params to the upstream request.
            forwarded_params = {k: v for k, v in request.args.items() if k not in ('path', 'target')}
            print(f"[Proxy REQUEST] GET {url} params={forwarded_params}")
            resp = requests.get(url, headers=headers, params=forwarded_params, verify=verify_ssl, timeout=proxy_timeout)
        else:
            # forward JSON or raw data
            data = None
            json_body = None
            try:
                json_body = request.get_json(silent=True)
            except Exception:
                json_body = None
            if json_body is not None:
                print(f"[Proxy REQUEST] {request.method} {url} payload={json_body}")
                resp = requests.request(request.method, url, headers=headers, json=json_body, verify=verify_ssl, timeout=proxy_timeout)
            else:
                raw_data = request.get_data()
                print(f"[Proxy REQUEST] {request.method} {url} raw_bytes={len(raw_data)} content_type={headers.get('Content-Type')}")
                resp = requests.request(request.method, url, headers=headers, data=raw_data, verify=verify_ssl, timeout=proxy_timeout)

        excluded_headers = ['content-encoding', 'content-length', 'transfer-encoding', 'connection']
        response_headers = [(name, value) for (name, value) in resp.headers.items() if name.lower() not in excluded_headers]
        return (resp.content, resp.status_code, response_headers)
    except Exception as exc:
        return jsonify({'status': 'error', 'message': f'proxy request failed: {exc}'}), 502


@app.route('/internal/routes')
def routes():
    rules = []
    for rule in app.url_map.iter_rules():
        rules.append({'rule': str(rule), 'methods': list(rule.methods)})
    return jsonify(rules)


@app.route("/", defaults={"path": ""})
@app.route("/<path:path>")
def serve(path: str):
    target = os.path.join(BUILD_DIR, path)
    if path and os.path.exists(target) and os.path.isfile(target):
        return send_from_directory(BUILD_DIR, path)
    return send_from_directory(BUILD_DIR, "index.html")


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "8080"))
    print(f"Starting Auth Token Server on http://0.0.0.0:{port}")
    print(f"[DEBUG] TARGET_AUDIENCE={os.getenv('TARGET_AUDIENCE', DEFAULT_AUDIENCE)}")
    print(f"[DEBUG] IMPERSONATE_SERVICE_ACCOUNT={os.getenv('IMPERSONATE_SERVICE_ACCOUNT', DEFAULT_IMPERSONATE_SERVICE_ACCOUNT)}")
    app.run(host="0.0.0.0", port=port, debug=True)





